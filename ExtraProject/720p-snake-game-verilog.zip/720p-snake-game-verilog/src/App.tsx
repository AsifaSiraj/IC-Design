import { useState } from "react";
import {
  Cpu,
  MonitorPlay,
  MemoryStick,
  Waves,
  FlaskConical,
  MapPin,
  Terminal,
  Rocket,
  CircuitBoard,
  ChevronRight,
} from "lucide-react";
import CodeBlock from "./components/CodeBlock";
import { verilogFiles } from "./data/verilogFiles";
import { horizontalTiming, verticalTiming, pinTable, memoryMap } from "./data/timingData";

const navItems = [
  { id: "overview", label: "Overview", icon: Cpu },
  { id: "timing", label: "720p Timing Spec", icon: MonitorPlay },
  { id: "memory", label: "DDR3 Memory Map", icon: MemoryStick },
  { id: "code", label: "Verilog RTL Modules", icon: Waves },
  { id: "sim", label: "Simulation (Phase A)", icon: FlaskConical },
  { id: "pins", label: "Pin Planning (Phase B)", icon: MapPin },
  { id: "capp", label: "HPS C Application", icon: Terminal },
  { id: "deploy", label: "Deployment Pipeline", icon: Rocket },
];

function SectionHeading({
  icon: Icon,
  eyebrow,
  title,
}: {
  icon: any;
  eyebrow: string;
  title: string;
}) {
  return (
    <div className="mb-6 flex items-center gap-3">
      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-emerald-800/50 bg-emerald-950/40 text-emerald-400">
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-emerald-500">{eyebrow}</p>
        <h2 className="text-2xl font-bold text-slate-100">{title}</h2>
      </div>
    </div>
  );
}

export default function App() {
  const [activeFile, setActiveFile] = useState(verilogFiles[0].id);
  const currentFile = verilogFiles.find((f) => f.id === activeFile)!;

  return (
    <div className="min-h-screen bg-[#080c0b] text-slate-200">
      {/* Background grid / circuit texture */}
      <div
        className="pointer-events-none fixed inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(16,185,129,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(16,185,129,0.5) 1px, transparent 1px)",
          backgroundSize: "36px 36px",
        }}
      />

      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-emerald-900/40 bg-[#080c0b]/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-teal-700 shadow-lg shadow-emerald-900/50">
              <Cpu className="h-5 w-5 text-emerald-950" />
            </div>
            <div>
              <h1 className="text-lg font-bold leading-tight text-white">720p SoC‑FPGA Snake</h1>
              <p className="text-xs text-emerald-500">Verilog RTL Reference · DE1‑SoC</p>
            </div>
          </div>
          <a
            href="#code"
            className="hidden items-center gap-2 rounded-lg border border-emerald-700/60 bg-emerald-900/30 px-4 py-2 text-sm font-medium text-emerald-300 transition hover:bg-emerald-800/40 sm:flex"
          >
            Jump to RTL <ChevronRight className="h-4 w-4" />
          </a>
        </div>
      </header>

      <div className="mx-auto flex max-w-7xl gap-8 px-6 py-10">
        {/* Sidebar */}
        <aside className="sticky top-24 hidden h-fit w-64 shrink-0 lg:block">
          <nav className="space-y-1 rounded-xl border border-emerald-900/40 bg-emerald-950/10 p-3">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-slate-300 transition hover:bg-emerald-500/10 hover:text-emerald-300"
                >
                  <Icon className="h-4 w-4 text-emerald-500" />
                  {item.label}
                </a>
              );
            })}
          </nav>
          <div className="mt-4 rounded-xl border border-amber-800/40 bg-amber-950/10 p-4 text-xs text-amber-300/90">
            <p className="font-semibold text-amber-400">Address note</p>
            <p className="mt-1 leading-relaxed">
              The lab spec targets DDR3 base <code className="text-amber-200">0x38000000</code> via
              <code className="text-amber-200"> f2h_sdram_master</code>. Your provided C file used the
              classic lightweight bridge demo addresses (<code className="text-amber-200">0xC8000000</code>/
              <code className="text-amber-200">0xC9000000</code>) — see the C App section for how to adapt it.
            </p>
          </div>
        </aside>

        {/* Main content */}
        <main className="min-w-0 flex-1 space-y-16">
          {/* Overview */}
          <section id="overview" className="scroll-mt-24">
            <SectionHeading icon={Cpu} eyebrow="Part I + II" title="Hardware / Software Co‑Design Overview" />
            <p className="leading-relaxed text-slate-300">
              This reference implements the FPGA-side Verilog logic requested by the lab manual: a VESA
              720p timing generator, an autonomous Avalon‑MM read master that DMAs pixel bytes straight out
              of DDR3, a clock-domain-crossing FIFO, and a top-level wrapper that expands the packed
              8‑bit (3‑3‑2) color byte into the DE1‑SoC's 8‑bit‑per‑channel VGA DAC bus. It is designed to sit
              behind your <code className="rounded bg-emerald-900/40 px-1 py-0.5 text-emerald-300">f2h_sdram_master</code> bridge
              in Platform Designer, exactly as described in Phase C.
            </p>
            <div className="mt-6 grid gap-4 sm:grid-cols-3">
              {[
                { k: "Pixel Clock", v: "74.25 MHz", d: "PLL-synthesized, drives all timing + DMA output" },
                { k: "Resolution", v: "1280 × 720", d: "60 Hz VESA 720p, positive sync polarity" },
                { k: "Frame Buffer", v: "921,600 B", d: "8bpp @ 0x38000000 via Avalon‑MM master" },
              ].map((c) => (
                <div key={c.k} className="rounded-xl border border-emerald-900/40 bg-emerald-950/20 p-4">
                  <p className="text-xs uppercase tracking-wide text-emerald-500">{c.k}</p>
                  <p className="mt-1 text-xl font-bold text-white">{c.v}</p>
                  <p className="mt-1 text-xs text-slate-400">{c.d}</p>
                </div>
              ))}
            </div>

            {/* Simple architecture diagram */}
            <div className="mt-8 overflow-x-auto rounded-xl border border-emerald-900/40 bg-emerald-950/10 p-6">
              <div className="flex min-w-[720px] items-center justify-between gap-3 text-center text-xs font-medium">
                <div className="flex-1 rounded-lg border border-emerald-700/50 bg-emerald-900/30 p-3 text-emerald-200">
                  HPS / ARM Cores
                  <div className="mt-1 text-[10px] text-emerald-400/80">snake.c via /dev/mem mmap()</div>
                </div>
                <ChevronRight className="h-5 w-5 shrink-0 text-emerald-600" />
                <div className="flex-1 rounded-lg border border-emerald-700/50 bg-emerald-900/30 p-3 text-emerald-200">
                  DDR3 Memory
                  <div className="mt-1 text-[10px] text-emerald-400/80">0x38000000 frame buffer</div>
                </div>
                <ChevronRight className="h-5 w-5 shrink-0 text-emerald-600" />
                <div className="flex-1 rounded-lg border border-emerald-700/50 bg-emerald-900/30 p-3 text-emerald-200">
                  f2h_sdram_master
                  <div className="mt-1 text-[10px] text-emerald-400/80">Avalon‑MM bridge</div>
                </div>
                <ChevronRight className="h-5 w-5 shrink-0 text-emerald-600" />
                <div className="flex-1 rounded-lg border border-teal-600/60 bg-teal-900/30 p-3 text-teal-200">
                  vga_dma_master.v
                  <div className="mt-1 text-[10px] text-teal-400/80">FSM + async_fifo.v</div>
                </div>
                <ChevronRight className="h-5 w-5 shrink-0 text-emerald-600" />
                <div className="flex-1 rounded-lg border border-teal-600/60 bg-teal-900/30 p-3 text-teal-200">
                  vga_controller.v
                  <div className="mt-1 text-[10px] text-teal-400/80">720p timing @ 74.25MHz</div>
                </div>
                <ChevronRight className="h-5 w-5 shrink-0 text-emerald-600" />
                <div className="flex-1 rounded-lg border border-amber-600/60 bg-amber-900/30 p-3 text-amber-200">
                  ADV7123 DAC
                  <div className="mt-1 text-[10px] text-amber-400/80">VGA_R/G/B[7:0]</div>
                </div>
              </div>
            </div>
          </section>

          {/* Timing */}
          <section id="timing" className="scroll-mt-24">
            <SectionHeading icon={MonitorPlay} eyebrow="Task 1" title="720p VESA Timing Specification" />
            <p className="mb-5 text-slate-300">
              Both counters run on the isolated 74.25 MHz pixel clock. Per the lab's{" "}
              <b className="text-amber-300">critical polarity requirement</b>, HSYNC and VSYNC are driven{" "}
              <b className="text-amber-300">active-HIGH</b> during their pulse windows (opposite of 480p).
            </p>
            <div className="grid gap-6 md:grid-cols-2">
              <div className="rounded-xl border border-emerald-900/40 bg-emerald-950/10 p-5">
                <h3 className="mb-3 text-sm font-semibold text-emerald-400">Horizontal Axis (pixel clocks)</h3>
                <table className="w-full text-sm">
                  <tbody>
                    {horizontalTiming.map((r) => (
                      <tr key={r.label} className="border-b border-emerald-900/30 last:border-0">
                        <td className="py-2 text-slate-400">{r.label}</td>
                        <td className="py-2 text-right font-mono text-slate-100">{r.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="rounded-xl border border-emerald-900/40 bg-emerald-950/10 p-5">
                <h3 className="mb-3 text-sm font-semibold text-emerald-400">Vertical Axis (lines)</h3>
                <table className="w-full text-sm">
                  <tbody>
                    {verticalTiming.map((r) => (
                      <tr key={r.label} className="border-b border-emerald-900/30 last:border-0">
                        <td className="py-2 text-slate-400">{r.label}</td>
                        <td className="py-2 text-right font-mono text-slate-100">{r.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          {/* Memory map */}
          <section id="memory" className="scroll-mt-24">
            <SectionHeading icon={MemoryStick} eyebrow="Task 2" title="DDR3 Frame Buffer & DMA Behavior" />
            <div className="grid gap-6 md:grid-cols-2">
              <div className="rounded-xl border border-emerald-900/40 bg-emerald-950/10 p-5">
                <table className="w-full text-sm">
                  <tbody>
                    {memoryMap.map((r) => (
                      <tr key={r.field} className="border-b border-emerald-900/30 last:border-0">
                        <td className="py-2 pr-4 text-slate-400">{r.field}</td>
                        <td className="py-2 text-right font-mono text-emerald-200">{r.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="rounded-xl border border-emerald-900/40 bg-emerald-950/10 p-5 text-sm leading-relaxed text-slate-300">
                <p className="mb-2 font-semibold text-emerald-400">DMA FSM behavior implemented in vga_dma_master.v</p>
                <ul className="list-inside list-disc space-y-1.5">
                  <li><code className="text-emerald-300">am_read</code> asserts only when the FIFO has free space.</li>
                  <li>Address & control lines hold steady while <code className="text-emerald-300">am_waitrequest</code> is high.</li>
                  <li>Pixel bytes latch only on <code className="text-emerald-300">am_readdatavalid</code> pulses.</li>
                  <li>Address pointer +4 bytes/read, wraps at <code className="text-emerald-300">0x38000000 + 921,596</code>.</li>
                  <li>VGA RGB forced to <code className="text-emerald-300">8'h00</code> during all blanking intervals.</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Code viewer */}
          <section id="code" className="scroll-mt-24">
            <SectionHeading icon={Waves} eyebrow="Deliverable" title="Verilog RTL Modules" />
            <div className="flex flex-wrap gap-2 border-b border-emerald-900/40 pb-4">
              {verilogFiles.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setActiveFile(f.id)}
                  className={`rounded-lg border px-3.5 py-2 text-xs font-semibold transition ${
                    activeFile === f.id
                      ? "border-emerald-500 bg-emerald-500/20 text-emerald-200"
                      : "border-emerald-900/50 bg-emerald-950/20 text-slate-400 hover:border-emerald-700 hover:text-emerald-300"
                  }`}
                >
                  {f.filename}
                </button>
              ))}
            </div>
            <div className="mt-5">
              <div className="mb-3 flex items-center gap-2">
                <span className="rounded-full border border-emerald-700/50 bg-emerald-900/30 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-emerald-300">
                  {currentFile.tag}
                </span>
                <span className="font-mono text-sm text-slate-300">{currentFile.filename}</span>
              </div>
              <p className="mb-4 text-sm leading-relaxed text-slate-400">{currentFile.description}</p>
              <CodeBlock code={currentFile.code} />
            </div>
          </section>

          {/* Simulation */}
          <section id="sim" className="scroll-mt-24">
            <SectionHeading icon={FlaskConical} eyebrow="Phase A" title="ModelSim / QuestaSim Verification" />
            <div className="rounded-xl border border-emerald-900/40 bg-emerald-950/10 p-5 text-sm leading-relaxed text-slate-300">
              <p className="mb-3">Compile & simulate the DMA master + FIFO before synthesis:</p>
              <pre className="mb-4 overflow-x-auto rounded-lg bg-black/40 p-3 font-mono text-xs text-emerald-300">
{`vlib work
vlog async_fifo.v vga_dma_master.v tb_vga_dma_master.v
vsim tb_vga_dma_master
run -all`}
              </pre>
              <p className="mb-2 font-semibold text-emerald-400">Waveform checkpoints to prove:</p>
              <ul className="list-inside list-disc space-y-1.5">
                <li><code className="text-emerald-300">am_addr</code> increments by exactly 4 only when <code className="text-emerald-300">am_waitrequest</code> is low AND <code className="text-emerald-300">am_read</code> is high.</li>
                <li><code className="text-emerald-300">am_read</code> drops low the clock cycle immediately following a successful handshake.</li>
                <li>Address/control lines stay frozen for the entire duration <code className="text-emerald-300">am_waitrequest</code> is asserted.</li>
              </ul>
              <p className="mt-4 text-xs text-slate-500">See the <code>tb_vga_dma_master.v</code> tab above — it includes a bus-functional slave model that injects a wait-state and drives <code>am_readdatavalid</code>.</p>
            </div>
          </section>

          {/* Pins */}
          <section id="pins" className="scroll-mt-24">
            <SectionHeading icon={MapPin} eyebrow="Phase B" title="Quartus Pin Planning (5CSEMA5F31C6)" />
            <div className="overflow-x-auto rounded-xl border border-emerald-900/40 bg-emerald-950/10 p-5">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-emerald-900/40 text-left text-xs uppercase tracking-wide text-emerald-500">
                    <th className="pb-2">Signal</th>
                    <th className="pb-2">Pin</th>
                    <th className="pb-2">Note</th>
                  </tr>
                </thead>
                <tbody>
                  {pinTable.map((r) => (
                    <tr key={r.signal} className="border-b border-emerald-900/20 last:border-0">
                      <td className="py-2 font-mono text-slate-100">{r.signal}</td>
                      <td className="py-2 font-mono text-emerald-300">{r.pin}</td>
                      <td className="py-2 text-slate-400">{r.note}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="mt-4 text-xs text-slate-500">
                Full VGA_R[7:0] / VGA_G[7:0] / VGA_B[7:0] → PIN_A13…PIN_J14 mapping is provided in the{" "}
                <button onClick={() => setActiveFile("qsf")} className="text-emerald-400 underline underline-offset-2">
                  de1_soc_pins.qsf
                </button>{" "}
                tab above (all 3.3‑V LVTTL).
              </p>
            </div>
          </section>

          {/* C App */}
          <section id="capp" className="scroll-mt-24">
            <SectionHeading icon={Terminal} eyebrow="Part II" title="How the Verilog Maps to Your snake.c" />
            <div className="grid gap-4 text-sm leading-relaxed text-slate-300 md:grid-cols-2">
              <div className="rounded-xl border border-emerald-900/40 bg-emerald-950/10 p-5">
                <h3 className="mb-2 font-semibold text-emerald-400">What your C file already does right</h3>
                <ul className="list-inside list-disc space-y-1.5">
                  <li><code className="text-emerald-300">open("/dev/mem", O_RDWR | O_SYNC)</code> + <code className="text-emerald-300">mmap()</code> to reach the physical frame buffer.</li>
                  <li><code className="text-emerald-300">termios</code> reconfiguration (<code>ICANON</code>/<code>ECHO</code> cleared) + <code className="text-emerald-300">fcntl(O_NONBLOCK)</code> for W/A/S/D polling.</li>
                  <li>Per-cell tail/segment redraw logic instead of clearing the whole buffer every frame.</li>
                </ul>
              </div>
              <div className="rounded-xl border border-amber-800/40 bg-amber-950/10 p-5">
                <h3 className="mb-2 font-semibold text-amber-400">Adjust to match this RTL's memory map</h3>
                <ul className="list-inside list-disc space-y-1.5">
                  <li>Change <code className="text-amber-200">PIXEL_BUF_BASE</code> from <code>0xC8000000</code> to <code className="text-amber-200">0x38000000</code>, span to <code className="text-amber-200">921600</code> (this design has no separate character/text overlay buffer, so drop <code>CHAR_BUF_*</code> or render score with pixel blocks).</li>
                  <li>Pixel format is <b>8-bit</b> (3‑3‑2), not RGB565 — replace <code className="text-amber-200">short pixel_buffer[]</code> writes with a <code className="text-amber-200">volatile unsigned char *</code> and pack colors as <code>(r&lt;&lt;5)|(g&lt;&lt;2)|b</code>.</li>
                  <li>Stride is 1280 bytes/row (not 320×2): <code className="text-amber-200">pixel = base + y*1280 + x</code>.</li>
                  <li>Bump <code className="text-amber-200">CELL_SIZE</code>/<code className="text-amber-200">SCREEN_WIDTH/HEIGHT</code> to <b>20</b> / <b>1280 × 720</b> per the lab's BLOCK_SIZE spec.</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Deployment */}
          <section id="deploy" className="scroll-mt-24">
            <SectionHeading icon={Rocket} eyebrow="Phase C" title="Interconnect, Compile & Flash" />
            <ol className="space-y-3 text-sm leading-relaxed text-slate-300">
              {[
                "Open Platform Designer (QSYS), add the Hard Processor System (HPS) component and configure DDR3 memory parameters.",
                "Add vga_top.v / vga_dma_master.v as a custom component and connect its Avalon-MM master port to the f2h_sdram_master slave.",
                "Add a PLL IP producing the 74.25 MHz pixel clock from CLOCK_50, and route clk_avalon from the HPS fabric clock.",
                "Generate the QSYS system, apply de1_soc_pins.qsf pin assignments, then compile with Ctrl+L in Quartus Prime and confirm timing closure.",
                "Program the FPGA fabric via USB-Blaster using soc_system.sof in the Quartus Programmer.",
                "Transfer snake.c (adapted per the C App section above) to the DE1-SoC Linux target and build/run it as root.",
              ].map((step, i) => (
                <li key={i} className="flex gap-3 rounded-lg border border-emerald-900/30 bg-emerald-950/10 p-3">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-500/20 text-xs font-bold text-emerald-300">
                    {i + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
            <div className="mt-5 rounded-xl border border-emerald-900/40 bg-emerald-950/10 p-5">
              <p className="mb-2 text-sm font-semibold text-emerald-400">Build & run on target</p>
              <pre className="overflow-x-auto rounded-lg bg-black/40 p-3 font-mono text-xs text-emerald-300">
{`gcc -O2 -o snake snake.c
sudo ./snake`}
              </pre>
            </div>
          </section>

          <footer className="flex items-center justify-between border-t border-emerald-900/40 pt-6 text-xs text-slate-500">
            <span>SoC-FPGA 720p Snake Game — RTL Reference Documentation</span>
            <span className="flex items-center gap-1.5">
              <CircuitBoard className="h-3.5 w-3.5" /> Verilog-2001 · Quartus Prime · DE1-SoC
            </span>
          </footer>
        </main>
      </div>
    </div>
  );
}
