export const horizontalTiming = [
  { label: "Active", value: "1280 clocks" },
  { label: "Front Porch", value: "110 clocks" },
  { label: "Sync Pulse", value: "40 clocks" },
  { label: "Back Porch", value: "220 clocks" },
  { label: "Total", value: "1650 clocks" },
];

export const verticalTiming = [
  { label: "Active", value: "720 lines" },
  { label: "Front Porch", value: "5 lines" },
  { label: "Sync Pulse", value: "5 lines" },
  { label: "Back Porch", value: "20 lines" },
  { label: "Total", value: "750 lines" },
];

export const pinTable = [
  { signal: "CLOCK_50", pin: "PIN_AF14", note: "50 MHz onboard oscillator" },
  { signal: "KEY[0]", pin: "PIN_AA14", note: "Active-low master reset" },
  { signal: "VGA_HS", pin: "PIN_B11", note: "Positive polarity" },
  { signal: "VGA_VS", pin: "PIN_D11", note: "Positive polarity" },
  { signal: "VGA_BLANK_N", pin: "PIN_F10", note: "High during active video" },
  { signal: "VGA_SYNC_N", pin: "PIN_C10", note: "Tied low (unused)" },
  { signal: "VGA_CLK", pin: "PIN_A11", note: "74.25 MHz pixel clock out" },
];

export const memoryMap = [
  { field: "DDR3 base address", value: "0x38000000" },
  { field: "Resolution", value: "1280 × 720 (visible)" },
  { field: "Color depth", value: "8 bpp — R[7:5] G[4:2] B[1:0]" },
  { field: "Frame size", value: "1280 × 720 × 1 = 921,600 bytes" },
  { field: "Last read address", value: "0x38000000 + 921,596" },
  { field: "Pixel clock", value: "74.25 MHz (PLL synthesized)" },
];
