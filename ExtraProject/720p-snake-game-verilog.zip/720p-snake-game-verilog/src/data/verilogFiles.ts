export interface VerilogFile {
  id: string;
  filename: string;
  tag: string;
  description: string;
  code: string;
}

export const verilogFiles: VerilogFile[] = [
  {
    id: "timing",
    filename: "vga_controller.v",
    tag: "Task 1 — Video Timing",
    description:
      "VESA 1280×720@60Hz timing generator running on the 74.25MHz pixel clock. Drives POSITIVE polarity HSYNC/VSYNC and generates pixel_x/pixel_y coordinates plus a video_active strobe.",
    code: `// ============================================================
// vga_controller.v
// 720p (1280x720 @ 60Hz) VESA timing generator
// Pixel clock: 74.25 MHz (from PLL)
// Polarity   : POSITIVE (active-HIGH) HSYNC/VSYNC  <-- 720p requirement
// ============================================================
module vga_controller (
    input  wire        clk_pix,      // 74.25 MHz pixel clock
    input  wire        rst_n,        // active-low reset (KEY[0])

    output reg          VGA_HS,
    output reg          VGA_VS,
    output reg          VGA_BLANK_N,
    output wire         VGA_SYNC_N,
    output wire         VGA_CLK,

    output reg  [10:0]  pixel_x,     // 0..1279 valid during active video
    output reg  [9:0]   pixel_y,     // 0..719  valid during active video
    output wire         video_active // high during visible 1280x720 window
);

    // ---------------- 720p VESA horizontal timing (pixel clocks) --------
    localparam H_ACTIVE = 11'd1280;
    localparam H_FP     = 11'd110;
    localparam H_SYNC   = 11'd40;
    localparam H_BP     = 11'd220;
    localparam H_TOTAL  = H_ACTIVE + H_FP + H_SYNC + H_BP; // 1650

    // ---------------- 720p VESA vertical timing (lines) ------------------
    localparam V_ACTIVE = 10'd720;
    localparam V_FP     = 10'd5;
    localparam V_SYNC   = 10'd5;
    localparam V_BP     = 10'd20;
    localparam V_TOTAL  = V_ACTIVE + V_FP + V_SYNC + V_BP;  // 750

    reg [10:0] h_count; // 0 .. H_TOTAL-1
    reg [9:0]  v_count; // 0 .. V_TOTAL-1

    wire h_end = (h_count == H_TOTAL - 1'b1);
    wire v_end = (v_count == V_TOTAL - 1'b1);

    // ---------------- Horizontal counter ---------------------------------
    always @(posedge clk_pix or negedge rst_n) begin
        if (!rst_n)
            h_count <= 11'd0;
        else if (h_end)
            h_count <= 11'd0;
        else
            h_count <= h_count + 11'd1;
    end

    // ---------------- Vertical counter (advances once per line) ----------
    always @(posedge clk_pix or negedge rst_n) begin
        if (!rst_n)
            v_count <= 10'd0;
        else if (h_end) begin
            if (v_end)
                v_count <= 10'd0;
            else
                v_count <= v_count + 10'd1;
        end
    end

    // ---------------- Sync pulse windows (combinational) ------------------
    wire hsync_window = (h_count >= (H_ACTIVE + H_FP)) &&
                         (h_count <  (H_ACTIVE + H_FP + H_SYNC));

    wire vsync_window = (v_count >= (V_ACTIVE + V_FP)) &&
                         (v_count <  (V_ACTIVE + V_FP + V_SYNC));

    wire video_on = (h_count < H_ACTIVE) && (v_count < V_ACTIVE);

    assign video_active = video_on;

    // ---------------- Registered outputs (POSITIVE polarity!) ------------
    always @(posedge clk_pix or negedge rst_n) begin
        if (!rst_n) begin
            VGA_HS      <= 1'b0;
            VGA_VS      <= 1'b0;
            VGA_BLANK_N <= 1'b0;
        end else begin
            VGA_HS      <= hsync_window; // active-HIGH pulse (720p spec)
            VGA_VS      <= vsync_window; // active-HIGH pulse (720p spec)
            VGA_BLANK_N <= video_on;     // high only inside active area
        end
    end

    // Pixel coordinate outputs (registered, same latency as HS/VS/BLANK)
    always @(posedge clk_pix or negedge rst_n) begin
        if (!rst_n) begin
            pixel_x <= 11'd0;
            pixel_y <= 10'd0;
        end else begin
            pixel_x <= (h_count < H_ACTIVE) ? h_count : 11'd0;
            pixel_y <= (v_count < V_ACTIVE) ? v_count : 10'd0;
        end
    end

    // DE1-SoC ADV7123 DAC does not use composite sync -> tie low
    assign VGA_SYNC_N = 1'b0;
    assign VGA_CLK    = clk_pix;

endmodule
`,
  },
  {
    id: "fifo",
    filename: "async_fifo.v",
    tag: "Support — Clock Domain Crossing",
    description:
      "Gray-code, dual-clock FIFO used to safely move 32-bit DDR3 words from the Avalon-MM (fabric) clock domain into the 74.25MHz pixel clock domain.",
    code: `// ============================================================
// async_fifo.v
// Dual clock (asynchronous) FIFO - Gray code pointer CDC
// Used to cross pixel words from the Avalon/HPS fabric clock
// domain into the 74.25 MHz VGA pixel clock domain.
// Read is "show-ahead": rd_data is valid combinationally
// whenever !rd_empty, pulse rd_en to advance to next word.
// ============================================================
module async_fifo #(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 9              // depth = 2^ADDR_WIDTH words
)(
    // Write (Avalon-MM / fabric clock) domain
    input  wire                     wr_clk,
    input  wire                     wr_rst,
    input  wire                     wr_en,
    input  wire [DATA_WIDTH-1:0]    wr_data,
    output wire                     wr_full,

    // Read (pixel clock) domain
    input  wire                     rd_clk,
    input  wire                     rd_rst,
    input  wire                     rd_en,
    output wire [DATA_WIDTH-1:0]    rd_data,
    output wire                     rd_empty
);

    localparam DEPTH = (1 << ADDR_WIDTH);

    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];

    reg [ADDR_WIDTH:0] wr_ptr_bin,  wr_ptr_gray;
    reg [ADDR_WIDTH:0] rd_ptr_bin,  rd_ptr_gray;
    reg [ADDR_WIDTH:0] rd_ptr_gray_wrclk_d1, rd_ptr_gray_wrclk_d2;
    reg [ADDR_WIDTH:0] wr_ptr_gray_rdclk_d1, wr_ptr_gray_rdclk_d2;

    function [ADDR_WIDTH:0] bin2gray(input [ADDR_WIDTH:0] b);
        bin2gray = (b >> 1) ^ b;
    endfunction

    // ------------------- Write side -------------------
    always @(posedge wr_clk or posedge wr_rst) begin
        if (wr_rst) begin
            wr_ptr_bin  <= {(ADDR_WIDTH+1){1'b0}};
            wr_ptr_gray <= {(ADDR_WIDTH+1){1'b0}};
        end else if (wr_en && !wr_full) begin
            mem[wr_ptr_bin[ADDR_WIDTH-1:0]] <= wr_data;
            wr_ptr_bin  <= wr_ptr_bin + 1'b1;
            wr_ptr_gray <= bin2gray(wr_ptr_bin + 1'b1);
        end
    end

    // synchronize read pointer into write clock domain (2 flop synchronizer)
    always @(posedge wr_clk or posedge wr_rst) begin
        if (wr_rst) begin
            rd_ptr_gray_wrclk_d1 <= 0;
            rd_ptr_gray_wrclk_d2 <= 0;
        end else begin
            rd_ptr_gray_wrclk_d1 <= rd_ptr_gray;
            rd_ptr_gray_wrclk_d2 <= rd_ptr_gray_wrclk_d1;
        end
    end

    assign wr_full = (wr_ptr_gray == {~rd_ptr_gray_wrclk_d2[ADDR_WIDTH:ADDR_WIDTH-1],
                                        rd_ptr_gray_wrclk_d2[ADDR_WIDTH-2:0]});

    // ------------------- Read side (show-ahead / FWFT) -------------------
    assign rd_data = mem[rd_ptr_bin[ADDR_WIDTH-1:0]];

    always @(posedge rd_clk or posedge rd_rst) begin
        if (rd_rst) begin
            rd_ptr_bin  <= {(ADDR_WIDTH+1){1'b0}};
            rd_ptr_gray <= {(ADDR_WIDTH+1){1'b0}};
        end else if (rd_en && !rd_empty) begin
            rd_ptr_bin  <= rd_ptr_bin + 1'b1;
            rd_ptr_gray <= bin2gray(rd_ptr_bin + 1'b1);
        end
    end

    // synchronize write pointer into read clock domain (2 flop synchronizer)
    always @(posedge rd_clk or posedge rd_rst) begin
        if (rd_rst) begin
            wr_ptr_gray_rdclk_d1 <= 0;
            wr_ptr_gray_rdclk_d2 <= 0;
        end else begin
            wr_ptr_gray_rdclk_d1 <= wr_ptr_gray;
            wr_ptr_gray_rdclk_d2 <= wr_ptr_gray_rdclk_d1;
        end
    end

    assign rd_empty = (rd_ptr_gray == wr_ptr_gray_rdclk_d2);

endmodule
`,
  },
  {
    id: "dma",
    filename: "vga_dma_master.v",
    tag: "Task 2 — Avalon-MM DMA Master",
    description:
      "Autonomous Avalon-MM read master that streams the frame buffer out of DDR3 (base 0x38000000, 921,600 bytes) into the FIFO, wraps the address at the frame boundary, and hands single pixel bytes to the video path.",
    code: `// ============================================================
// vga_dma_master.v
// Autonomous Avalon-MM READ MASTER for the f2h_sdram_master bridge.
// Streams the 1280x720x1Byte frame buffer out of DDR3 and exposes
// it one pixel-byte at a time to the pixel-clock domain.
//
// DDR3 frame buffer partition:
//   BASE_ADDR   = 0x3800_0000
//   FRAME_BYTES = 1280 * 720 * 1 = 921,600  (0xE1000)
//   last legal read address       = BASE_ADDR + 921,596 (921600-4)
// ============================================================
module vga_dma_master #(
    parameter BASE_ADDR   = 32'h3800_0000,
    parameter FRAME_BYTES = 32'd921_600,
    parameter FIFO_AWIDTH = 9                 // 512 x 32-bit word FIFO
)(
    // ---------------- Avalon-MM master port / fabric clock domain -------
    input  wire        am_clk,
    input  wire        am_reset,

    output reg  [31:0] am_address,
    output reg         am_read,
    input  wire        am_waitrequest,
    input  wire [31:0] am_readdata,
    input  wire        am_readdatavalid,

    // ---------------- Pixel side / 74.25MHz pixel clock domain ----------
    input  wire         pix_clk,
    input  wire         pix_reset,
    input  wire         pixel_request,   // pulse once per active pixel
    output wire [7:0]   pixel_data,      // 3-3-2 packed RGB byte
    output wire         pixel_valid
);

    localparam LAST_ADDR = BASE_ADDR + FRAME_BYTES - 32'd4; // 0x38000000+921596

    // ---------------- FSM states -----------------------------------------
    localparam S_IDLE      = 2'd0;  // no outstanding request
    localparam S_REQUEST   = 2'd1;  // am_read asserted, waiting out am_waitrequest
    localparam S_WAIT_DATA = 2'd2;  // address accepted, waiting for readdatavalid

    reg [1:0]  state;
    reg [31:0] addr_reg;               // next address to issue

    // ---------------- FIFO instance (CDC into pixel domain) --------------
    wire        fifo_wr_en   = am_readdatavalid;
    wire [31:0] fifo_wr_data = am_readdata;
    wire        fifo_full;
    wire        fifo_empty;
    wire [31:0] fifo_rd_data;
    wire        fifo_rd_en;

    async_fifo #(
        .DATA_WIDTH(32),
        .ADDR_WIDTH(FIFO_AWIDTH)
    ) u_pixel_fifo (
        .wr_clk   (am_clk),
        .wr_rst   (am_reset),
        .wr_en    (fifo_wr_en),
        .wr_data  (fifo_wr_data),
        .wr_full  (fifo_full),

        .rd_clk   (pix_clk),
        .rd_rst   (pix_reset),
        .rd_en    (fifo_rd_en),
        .rd_data  (fifo_rd_data),
        .rd_empty (fifo_empty)
    );

    // "space available inside the domain-crossing buffer queue"
    wire space_avail = !fifo_full;

    // ---------------- Avalon-MM master FSM --------------------------------
    always @(posedge am_clk or posedge am_reset) begin
        if (am_reset) begin
            state      <= S_IDLE;
            addr_reg   <= BASE_ADDR;
            am_address <= BASE_ADDR;
            am_read    <= 1'b0;
        end else begin
            case (state)

                // Only start a new request when the FIFO has room
                S_IDLE: begin
                    am_read <= 1'b0;
                    if (space_avail) begin
                        am_address <= addr_reg;
                        am_read    <= 1'b1;
                        state      <= S_REQUEST;
                    end
                end

                // am_read stays HIGH and am_address/addr_reg are held stable
                // for as long as am_waitrequest == 1 (bus stall)
                S_REQUEST: begin
                    if (!am_waitrequest) begin
                        // Handshake succeeded THIS cycle:
                        //   -> am_read drops LOW on the very next clock edge
                        //   -> address pointer advances by exactly 4 bytes
                        am_read <= 1'b0;

                        if (addr_reg >= LAST_ADDR)
                            addr_reg <= BASE_ADDR;             // wrap frame
                        else
                            addr_reg <= addr_reg + 32'd4;

                        state <= S_WAIT_DATA;
                    end
                    // else: stall - address/read/addr_reg all held
                end

                // Wait for the pipelined read data to actually arrive
                S_WAIT_DATA: begin
                    if (am_readdatavalid)
                        state <= S_IDLE;   // go request the next word
                end

                default: state <= S_IDLE;
            endcase
        end
    end

    // ---------------- Pixel-side byte de-multiplexer ----------------------
    // Each 32-bit DDR3 word packs 4 consecutive 8-bit pixels (byte0 = first
    // pixel in memory order). fifo_rd_data is "show ahead": valid whenever
    // !fifo_empty without needing to assert fifo_rd_en first.
    reg [1:0] byte_sel;

    always @(posedge pix_clk or posedge pix_reset) begin
        if (pix_reset)
            byte_sel <= 2'd0;
        else if (pixel_request && !fifo_empty)
            byte_sel <= byte_sel + 2'd1;   // wraps 0->1->2->3->0
    end

    // Pop the FIFO exactly when the last byte (byte 3) of the current word
    // is being consumed, so the NEXT word is ready for byte_sel==0
    assign fifo_rd_en = pixel_request && !fifo_empty && (byte_sel == 2'd3);

    assign pixel_data  = (byte_sel == 2'd0) ? fifo_rd_data[7:0]   :
                          (byte_sel == 2'd1) ? fifo_rd_data[15:8]  :
                          (byte_sel == 2'd2) ? fifo_rd_data[23:16] :
                                                fifo_rd_data[31:24];

    assign pixel_valid = pixel_request && !fifo_empty;

endmodule
`,
  },
  {
    id: "top",
    filename: "vga_top.v",
    tag: "Integration — Top Level",
    description:
      "Wraps the timing generator + DMA master together, expands the packed 3-3-2 byte into the 8-bit-per-channel VGA DAC bus, and forces RGB to 0x00 during every blanking interval.",
    code: `// ============================================================
// vga_top.v
// Top-level glue: timing generator + Avalon-MM DMA master + color
// expansion for the DE1-SoC ADV7123 VGA DAC.
//
// Color format read from DDR3 (8 bits/pixel):
//    bit [7:5] = Red   (3 bits)
//    bit [4:2] = Green (3 bits)
//    bit [1:0] = Blue  (2 bits)
// ============================================================
module vga_top (
    input  wire        CLOCK_50,
    input  wire        KEY0,          // active-low push button reset

    input  wire        clk_pixel,     // 74.25 MHz from PLL (Platform Designer)
    input  wire        clk_avalon,    // Avalon-MM fabric clock (f2h_sdram_master)

    // ---------------- Avalon-MM master -> f2h_sdram_master ---------------
    output wire [31:0] am_address,
    output wire        am_read,
    input  wire        am_waitrequest,
    input  wire [31:0] am_readdata,
    input  wire        am_readdatavalid,

    // ---------------- Physical VGA (ADV7123 DAC) --------------------------
    output wire        VGA_HS,
    output wire        VGA_VS,
    output wire        VGA_BLANK_N,
    output wire        VGA_SYNC_N,
    output wire        VGA_CLK,
    output wire [7:0]  VGA_R,
    output wire [7:0]  VGA_G,
    output wire [7:0]  VGA_B
);

    wire rst_n = KEY0;

    wire        video_active;
    wire [10:0] pixel_x;
    wire [9:0]  pixel_y;

    wire [7:0]  pixel_byte;
    wire        pixel_valid;

    // Consume exactly one pixel byte per pixel clock while inside the
    // 1280x720 active window
    wire pixel_request = video_active;

    // ---------------- 720p timing generator --------------------------------
    vga_controller u_timing (
        .clk_pix      (clk_pixel),
        .rst_n        (rst_n),
        .VGA_HS       (VGA_HS),
        .VGA_VS       (VGA_VS),
        .VGA_BLANK_N  (VGA_BLANK_N),
        .VGA_SYNC_N   (VGA_SYNC_N),
        .VGA_CLK      (VGA_CLK),
        .pixel_x      (pixel_x),
        .pixel_y      (pixel_y),
        .video_active (video_active)
    );

    // ---------------- Avalon-MM DMA read master -----------------------------
    vga_dma_master #(
        .BASE_ADDR   (32'h3800_0000),
        .FRAME_BYTES (32'd921_600),
        .FIFO_AWIDTH (9)
    ) u_dma (
        .am_clk           (clk_avalon),
        .am_reset         (~rst_n),
        .am_address       (am_address),
        .am_read          (am_read),
        .am_waitrequest   (am_waitrequest),
        .am_readdata      (am_readdata),
        .am_readdatavalid (am_readdatavalid),

        .pix_clk        (clk_pixel),
        .pix_reset      (~rst_n),
        .pixel_request  (pixel_request),
        .pixel_data     (pixel_byte),
        .pixel_valid    (pixel_valid)
    );

    // ---------------- 3-3-2 -> 8/8/8 bit expansion for the VGA DAC ----------
    wire [2:0] red3 = pixel_byte[7:5];
    wire [2:0] grn3 = pixel_byte[4:2];
    wire [1:0] blu2 = pixel_byte[1:0];

    // Simple bit-replication expansion (keeps full black->white range)
    wire [7:0] red8 = {red3, red3, red3[2:1]};
    wire [7:0] grn8 = {grn3, grn3, grn3[2:1]};
    wire [7:0] blu8 = {blu2, blu2, blu2, blu2};

    // ELECTRICAL SAFETY REQUIREMENT:
    // force RGB to 8'h00 during front porch / sync / back porch (blanking)
    assign VGA_R = video_active ? red8 : 8'h00;
    assign VGA_G = video_active ? grn8 : 8'h00;
    assign VGA_B = video_active ? blu8 : 8'h00;

endmodule
`,
  },
  {
    id: "tb",
    filename: "tb_vga_dma_master.v",
    tag: "Phase A — ModelSim Testbench",
    description:
      "Bus-functional testbench that toggles am_waitrequest to prove the FSM stalls correctly, that am_address only advances by 4 bytes on a successful handshake, and that am_read drops the cycle after the handshake.",
    code: `\`timescale 1ns / 1ps
// ============================================================
// tb_vga_dma_master.v
// Bus functional model of the f2h_sdram_master slave.
// Run with:
//   vlib work
//   vlog async_fifo.v vga_dma_master.v tb_vga_dma_master.v
//   vsim tb_vga_dma_master
//   run -all
// ============================================================
module tb_vga_dma_master;

    reg         am_clk = 0;
    reg         am_reset = 1;
    reg         am_waitrequest = 0;
    reg  [31:0] am_readdata = 32'h0;
    reg         am_readdatavalid = 0;
    wire [31:0] am_address;
    wire        am_read;

    reg         pix_clk = 0;
    reg         pix_reset = 1;
    reg         pixel_request = 0;
    wire [7:0]  pixel_data;
    wire        pixel_valid;

    // 100 MHz-ish avalon/fabric clock
    always #5   am_clk  = ~am_clk;
    // ~74.25 MHz pixel clock
    always #6.734 pix_clk = ~pix_clk;

    vga_dma_master #(
        .BASE_ADDR   (32'h3800_0000),
        .FRAME_BYTES (32'd921_600),
        .FIFO_AWIDTH (5)              // small FIFO for fast simulation
    ) dut (
        .am_clk           (am_clk),
        .am_reset         (am_reset),
        .am_address       (am_address),
        .am_read          (am_read),
        .am_waitrequest   (am_waitrequest),
        .am_readdata      (am_readdata),
        .am_readdatavalid (am_readdatavalid),

        .pix_clk       (pix_clk),
        .pix_reset     (pix_reset),
        .pixel_request (pixel_request),
        .pixel_data    (pixel_data),
        .pixel_valid   (pixel_valid)
    );

    // Simple slave BFM: injects a wait-state, then returns data 2 cycles later
    reg [31:0] pending_addr;
    always @(posedge am_clk) begin
        if (am_reset) begin
            am_waitrequest   <= 1'b0;
            am_readdatavalid <= 1'b0;
        end else begin
            am_readdatavalid <= 1'b0;

            // stall the FIRST read of every test burst for 2 cycles
            if (am_read && am_waitrequest == 1'b0 && $time > 100 && $time < 140)
                am_waitrequest <= 1'b1;
            else
                am_waitrequest <= 1'b0;

            if (am_read && !am_waitrequest) begin
                pending_addr     <= am_address;
                am_readdata      <= {24'h000000, am_address[7:0]}; // fake pixel pattern
                am_readdatavalid <= 1'b1;
            end
        end
    end

    initial begin
        am_reset = 1; pix_reset = 1;
        #40 am_reset = 0; pix_reset = 0;

        $display("time  am_address  am_read waitreq readdatavalid");
        $monitor("%0t     %h   %b       %b        %b", $time, am_address, am_read, am_waitrequest, am_readdatavalid);

        // let the master free-run and issue several reads
        #2000;

        // consume some pixels to exercise the byte de-mux / fifo pop logic
        repeat (16) begin
            @(posedge pix_clk);
            pixel_request = 1;
            @(posedge pix_clk);
            pixel_request = 0;
        end

        #500;
        $display("TESTBENCH CHECK: am_address must only ever step by 4 while am_read was high and am_waitrequest was low.");
        $finish;
    end

endmodule
`,
  },
  {
    id: "qsf",
    filename: "de1_soc_pins.qsf",
    tag: "Phase B — Quartus Pin Constraints",
    description:
      "Quartus Settings File fragment assigning CLOCK_50, KEY[0], and the full VGA_HS/VS/BLANK_N/SYNC_N/CLK + VGA_R[7:0]/VGA_G[7:0]/VGA_B[7:0] bus to their physical DE1-SoC pins.",
    code: `# ============================================================
# de1_soc_pins.qsf  (append into soc_system top-level .qsf)
# Cyclone V SoC: 5CSEMA5F31C6  (DE1-SoC)
# ============================================================

set_location_assignment PIN_AF14 -to CLOCK_50
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to CLOCK_50

set_location_assignment PIN_AA14 -to KEY[0]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to KEY[0]

# --------------------- VGA control signals ---------------------
set_location_assignment PIN_B11 -to VGA_HS
set_location_assignment PIN_D11 -to VGA_VS
set_location_assignment PIN_F10 -to VGA_BLANK_N
set_location_assignment PIN_C10 -to VGA_SYNC_N
set_location_assignment PIN_A11 -to VGA_CLK

set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to VGA_HS
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to VGA_VS
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to VGA_BLANK_N
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to VGA_SYNC_N
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to VGA_CLK

# --------------------- VGA_R[7:0] --------------------------------
set_location_assignment PIN_A13 -to VGA_R[0]
set_location_assignment PIN_C13 -to VGA_R[1]
set_location_assignment PIN_E13 -to VGA_R[2]
set_location_assignment PIN_B12 -to VGA_R[3]
set_location_assignment PIN_C12 -to VGA_R[4]
set_location_assignment PIN_D12 -to VGA_R[5]
set_location_assignment PIN_E12 -to VGA_R[6]
set_location_assignment PIN_F13 -to VGA_R[7]

# --------------------- VGA_G[7:0] --------------------------------
set_location_assignment PIN_J9  -to VGA_G[0]
set_location_assignment PIN_J10 -to VGA_G[1]
set_location_assignment PIN_H12 -to VGA_G[2]
set_location_assignment PIN_G10 -to VGA_G[3]
set_location_assignment PIN_G11 -to VGA_G[4]
set_location_assignment PIN_G12 -to VGA_G[5]
set_location_assignment PIN_F11 -to VGA_G[6]
set_location_assignment PIN_E11 -to VGA_G[7]

# --------------------- VGA_B[7:0] --------------------------------
set_location_assignment PIN_B13 -to VGA_B[0]
set_location_assignment PIN_G13 -to VGA_B[1]
set_location_assignment PIN_H13 -to VGA_B[2]
set_location_assignment PIN_F14 -to VGA_B[3]
set_location_assignment PIN_H14 -to VGA_B[4]
set_location_assignment PIN_F15 -to VGA_B[5]
set_location_assignment PIN_G15 -to VGA_B[6]
set_location_assignment PIN_J14 -to VGA_B[7]

# Apply the LVTTL standard to the full RGB buses in one shot
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to VGA_R[*]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to VGA_G[*]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to VGA_B[*]
`,
  },
];
