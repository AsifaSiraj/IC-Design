import { useState } from "react";
import { Check, Copy } from "lucide-react";

export default function CodeBlock({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // ignore clipboard failures silently
    }
  };

  const lines = code.replace(/\n$/, "").split("\n");

  return (
    <div className="relative overflow-hidden rounded-xl border border-emerald-900/40 bg-[#0b1210] shadow-[0_0_30px_-15px_rgba(16,185,129,0.4)]">
      <div className="flex items-center justify-between border-b border-emerald-900/40 bg-emerald-950/30 px-4 py-2">
        <div className="flex gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-red-500/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-yellow-500/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-green-500/70" />
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 rounded-md border border-emerald-800/60 bg-emerald-900/30 px-2.5 py-1 text-xs font-medium text-emerald-300 transition hover:bg-emerald-800/50"
        >
          {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <div className="max-h-[620px] overflow-auto">
        <table className="w-full border-collapse font-mono text-[12.5px] leading-relaxed">
          <tbody>
            {lines.map((line, i) => (
              <tr key={i} className="hover:bg-emerald-500/5">
                <td className="select-none border-r border-emerald-900/30 px-3 py-0 text-right text-emerald-700/70">
                  {i + 1}
                </td>
                <td className="whitespace-pre px-4 py-0 text-emerald-100/90">{line || " "}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
