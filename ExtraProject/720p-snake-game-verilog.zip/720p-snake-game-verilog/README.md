# 720p SoC-FPGA Snake — Verilog RTL Reference

An interactive, single-page documentation website that presents a complete Verilog-2001
RTL reference for a 720p VGA frame-buffer pipeline on the Terasic **DE1-SoC**
(Cyclone V SoC `5CSEMA5F31C6`).

The site is the *specification document* for a lab assignment. It walks through the
hardware/software co-design of a snake game whose frame buffer lives in DDR3 and is
scanned out directly by FPGA fabric — no CPU involvement per pixel.

> This repository contains **no `.v` files on disk**. The complete source of all six
> Verilog modules plus the Quartus pin constraints is embedded as tagged template
> literals in `src/data/verilogFiles.ts` and rendered in the browser with a
> copy-to-clipboard code viewer.

---

## Table of contents

- [Quick start](#quick-start)
- [Tech stack](#tech-stack)
- [Complete file listing](#complete-file-listing)
- [Architecture](#architecture)
- [720p VESA timing specification](#720p-vesa-timing-specification)
- [DDR3 frame buffer & DMA behaviour](#ddr3-frame-buffer--dma-behaviour)
- [The embedded Verilog modules](#the-embedded-verilog-modules)
- [Page sections](#page-sections)
- [Pin assignments](#pin-assignments)
- [HPS C application integration](#hps-c-application-integration)
- [Deployment pipeline](#deployment-pipeline)
- [Simulation (Phase A)](#simulation-phase-a)
- [Regenerating `image.hex` or adding your own module](#regenerating-imagehex-or-adding-your-own-module)
- [Design notes and conventions](#design-notes-and-conventions)

---

## Quick start

```bash
npm install
npm run dev          # Vite dev server → http://localhost:5173
```

| Script | Command | Purpose |
|--------|---------|---------|
| `npm run dev` | `vite` | Start the dev server with hot module replacement. |
| `npm run build` | `vite build` | Production build into `dist/`. |
| `npm run preview` | `vite preview` | Serve the built `dist/` locally. |

Requires Node.js 18+ and npm 9+.

**Build output is a single self-contained HTML file.** `vite-plugin-singlefile` inlines
the JS and CSS into `dist/index.html`, so the built site can be opened straight from
disk or emailed as one attachment.

---

## Tech stack

| Layer | Choice | Version | Why |
|-------|--------|---------|-----|
| Build tool | Vite | 7.3.2 | Instant HMR, native ESM, TS config out of the box. |
| UI framework | React | 19.2.6 | `createRoot` + StrictMode. |
| Language | TypeScript | 5.9.3 | `strict`, `noUnusedLocals`, `noUnusedParameters` all on. |
| Styling | Tailwind CSS | 4.1.17 | Via `@tailwindcss/vite` — no `tailwind.config.js` needed (v4 CSS-first). |
| Class merging | `clsx` + `tailwind-merge` | 2.1.1 / 3.4.0 | `cn()` utility resolves conflicting Tailwind classes. |
| Icons | `lucide-react` | ^1.24.0 | 11 tree-shaken icons. |
| Single-file bundling | `vite-plugin-singlefile` | 2.3.0 | Inlines everything into one `.html`. |
| React plugin | `@vitejs/plugin-react` | 5.1.1 | Fast Refresh + automatic JSX runtime. |
| Node types | `@types/node` | 22.19.17 | Needed for `path`/`url` in `vite.config.ts`. |

---

## Complete file listing

12 files. Everything else (`node_modules/`, `dist/`) is generated.

```
720p-snake-game-verilog/
├── index.html                        332 B   Vite HTML entry point
├── package.json                      660 B   name, scripts, dependency pins
├── package-lock.json               85 KB     exact transitive dependency tree
├── tsconfig.json                     681 B   strict TS compiler options
├── vite.config.ts                   538 B   plugin chain + "@" → "src" alias
├── README.md                               ← you are here
└── src/
    ├── main.tsx                     230 B   React root mount
    ├── App.tsx                    22.6 KB    the entire page (393 lines)
    ├── index.css                     23 B   Tailwind import only
    ├── components/
    │   └── CodeBlock.tsx           2.1 KB   line-numbered code viewer + copy button
    ├── data/
    │   ├── verilogFiles.ts         24.2 KB    6 embedded RTL/constraint sources
    │   └── timingData.ts           1.5 KB   timing / memory / pin tables
    └── utils/
        └── cn.ts                    169 B   clsx + tailwind-merge helper
```

### `index.html` — 332 bytes

Minimal Vite shell. No fonts, no CDN links, no meta SEO beyond the viewport tag.

* `<title>` is `720p SoC-FPGA Snake — Verilog RTL Reference`.
* Contains a single `<div id="root">` mount point.
* Loads `/src/main.tsx` as `type="module"`.

### `package.json` — 660 bytes

Package is named `react-vite-tailwind` (kept from the template) but `private: true`, so
it is never published. `"type": "module"` makes every `.ts` config file ESM.

Note the unusual pinned versions — React `19.2.6` and Tailwind `3.4.0` of
`tailwind-merge` are exact pins, not ranges.

### `package-lock.json` — 85 KB

npm lockfile, lockfileVersion 3. Regenerate with `npm ci` for a reproducible install.

### `tsconfig.json` — 681 bytes

| Option | Value | Effect |
|--------|-------|--------|
| `target` | `ES2020` | Modern browsers. |
| `lib` | `["ES2020","DOM","DOM.Iterable"]` | Browser globals. |
| `module` | `ESNext` | Vite handles transpilation. |
| `moduleResolution` | `bundler` | Honours `exports` maps, no extension guessing. |
| `allowImportingTsExtensions` | `true` | Allows `./foo.ts` style imports. |
| `resolveJsonModule` | `true` | JSON imports allowed. |
| `isolatedModules` | `true` | Each file transpiles independently (required by Vite). |
| `noEmit` | `true` | Type-check only; Vite does the emitting. |
| `jsx` | `react-jsx` | Automatic JSX runtime, no `import React` needed. |
| `baseUrl` / `paths` | `"."` / `"@/*": ["src/*"]` | Matches the Vite alias. |
| `strict` | `true` | Full strict-family checks. |
| `noUnusedLocals` | `true` | Unused variables are errors. |
| `noUnusedParameters` | `true` | Unused function params are errors. |
| `noFallthroughCasesInSwitch` | `true` | Catches missing `break`. |
| `include` | `["src", "vite.config.ts"]` | Also type-checks the build config. |

### `vite.config.ts` — 538 bytes

```ts
plugins: [react(), tailwindcss(), viteSingleFile()]
resolve.alias: { "@": path.resolve(__dirname, "src") }
```

Plugin order matters: `react()` first (JSX transform), `tailwindcss()` second (PostCSS
step), `viteSingleFile()` last (inlining must happen after everything else is bundled).
`__dirname` is reconstructed from `import.meta.url` because the file is ESM.

### `src/main.tsx` — 230 bytes, 10 lines

```tsx
createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
```

Imports `./index.css` before `App` so Tailwind's base layer is registered first. The
non-null assertion on `getElementById` is safe because `index.html` hardcodes the
element.

### `src/index.css` — 23 bytes

A single line: `@import "tailwindcss";`. Everything else is Tailwind utility classes in
the TSX.

### `src/App.tsx` — 22.6 KB, 393 lines

The entire single-page application. Structure:

| Part | Lines | Contents |
|------|------:|----------|
| Imports | 1–16 | `useState`, 11 `lucide-react` icons, `CodeBlock`, the two data modules. |
| `navItems` | 18–27 | Sidebar definition: 8 entries, each with an id, label, and icon. |
| `SectionHeading` | 29–49 | Reusable heading — coloured icon tile, uppercase eyebrow, title. |
| `App()` | 51–393 | The page. One piece of state: `activeFile`. |

**State.** Exactly one `useState`:

```tsx
const [activeFile, setActiveFile] = useState(verilogFiles[0].id);
const currentFile = verilogFiles.find((f) => f.id === activeFile)!;
```

Everything else is static markup driven by the data modules. There is no router — the
eight sections are plain `<section id="...">` anchors, and the sidebar links are
`<a href="#id">`.

**Layout.** Fixed full-page grid texture (36 px emerald grid at 7 % opacity) → sticky
header → two-column body (`w-64` sticky sidebar + `flex-1` main) → footer.

**Colour system.** Background `#080c0b`, code panels `#0b1210`, emerald accent scale
for interactive elements, amber for "adjust this" warnings. Chosen to read as an
oscilloscope/EDA-tool aesthetic rather than a generic docs template.

**Inline arrays.** Three lists of literal objects are defined inline in JSX rather than
in a data module:

* the three overview stat cards (pixel clock / resolution / frame buffer),
* the seven `Phase C` deployment steps (numbered `<ol>`),
* the address-note callout in the sidebar.

### `src/components/CodeBlock.tsx` — 2.1 KB, 51 lines

A self-contained code viewer. Props: `{ code: string }`.

| Behaviour | Implementation |
|-----------|----------------|
| **Line numbers** | `code.replace(/\n$/,"").split("\n")`, rendered as a `<table>` where the first `<td>` is `i+1`. Using a table rather than CSS counters keeps the gutter aligned with wrapped lines. |
| **Copy button** | `navigator.clipboard.writeText(code)`; shows `Check` + "Copied" for 1 800 ms after success. |
| **Clipboard errors** | Silently swallowed in a `try/catch` — no error UI. |
| **Scrolling** | Body capped at `max-h-[620px]` with `overflow-auto`; header stays fixed. |
| **Whitespace** | `whitespace-pre` on the code cell preserves indentation. Empty lines render a single space (`{line \|\| " "}`) so the row keeps its height. |
| **Glow** | `shadow-[0_0_30px_-15px_rgba(16,185,129,0.4)]` — a soft emerald halo. |
| **Chrome** | Three fake traffic-light dots (red/yellow/green) for visual affordance. |

The copy state resets via `setTimeout`; there is no cleanup on unmount, which is
acceptable because the component is only rendered once per file switch.

### `src/data/verilogFiles.ts` — 24.2 KB, 657 lines

**The heart of the project.** Defines the `VerilogFile` interface and exports an array
of six entries. This is the entire Verilog design, stored as template literals.

```ts
export interface VerilogFile {
  id: string;          // React key + tab id
  filename: string;    // shown in the tab and header
  tag: string;         // badge above the code, e.g. "Task 1 — Video Timing"
  description: string; // one-paragraph prose shown under the header
  code: string;        // the full file contents
}
```

| `id` | `filename` | `tag` | ~Lines |
|-----|-----------|-------|-------:|
| `timing` | `vga_controller.v` | Task 1 — Video Timing | 103 |
| `fifo` | `async_fifo.v` | Support — Clock Domain Crossing | 93 |
| `dma` | `vga_dma_master.v` | Task 2 — Avalon-MM DMA Master | 147 |
| `top` | `vga_top.v` | Integration — Top Level | 101 |
| `tb` | `tb_vga_dma_master.v` | Phase A — ModelSim Testbench | 99 |
| `qsf` | `de1_soc_pins.qsf` | Phase B — Quartus Pin Constraints | 59 |

To add a module, append one object with a unique `id` and set
`.HEX_FILE`/code as needed. The tab strip, the panel, and the copy button all derive
from the array length — no other file needs to change.

### `src/data/timingData.ts` — 1.5 KB, 34 lines

Four exported arrays of `{label, value}` / `{field, value}` / `{signal, pin, note}`
tuples. Rendered directly as `<table>` bodies.

| Export | Rows | Fields |
|--------|-----:|--------|
| `horizontalTiming` | 5 | `label`, `value` — pixel-clock counts |
| `verticalTiming` | 5 | `label`, `value` — line counts |
| `pinTable` | 7 | `signal`, `pin`, `note` |
| `memoryMap` | 6 | `field`, `value` |

### `src/utils/cn.ts` — 169 bytes, 6 lines

```ts
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

`clsx` handles conditional class logic; `twMerge` resolves Tailwind conflicts so the
*last* conflicting utility wins (important with Tailwind v4's default ordering). Defined
and exported but not currently imported anywhere in `src/` — available for future
use, and `noUnusedLocals` does not flag exported symbols.

---

## Architecture

Rendered as a horizontal flow diagram in the "Overview" section:

```
HPS / ARM Cores          DDR3 Memory           f2h_sdram_master
snake.c via /dev/mem  →  0x38000000 frame  →   Avalon-MM bridge
mmap()                    buffer
                                                    │
                                                    ▼
                                          vga_dma_master.v
                                          FSM + async_fifo.v
                                                    │
                                                    ▼
                                          vga_controller.v
                                          720p timing @ 74.25 MHz
                                                    │
                                                    ▼
                                             ADV7123 DAC
                                             VGA_R/G/B[7:0]
```

The ARM cores never touch individual pixels. `snake.c` only writes the 921 600-byte
frame buffer through `mmap()`; the FPGA DMA master scans it out over Avalon-MM and the
timing generator drives the DAC. That split is the entire point of the assignment.

**Headline constants**

| Metric | Value |
|--------|-------|
| Pixel clock | 74.25 MHz (PLL-synthesised) |
| Resolution | 1280 × 720 @ 60 Hz |
| Frame buffer | 921 600 B, 8 bpp, at `0x38000000` |
| Sync polarity | Positive (active-HIGH) |

---

## 720p VESA timing specification

Both counters run on the isolated 74.25 MHz pixel clock. **HSYNC and VSYNC are
active-HIGH** during their pulse windows — this is called out as the lab's *critical
polarity requirement* and is explicitly opposite to 480p.

### Horizontal (pixel clocks)

| Region | Count |
|--------|------:|
| Active | 1280 |
| Front porch | 110 |
| Sync pulse | 40 |
| Back porch | 220 |
| **Total** | **1650** |

### Vertical (lines)

| Region | Count |
|--------|------:|
| Active | 720 |
| Front porch | 5 |
| Sync pulse | 5 |
| Back porch | 20 |
| **Total** | **750** |

**Sanity check:** 1650 × 750 × 60 Hz = 74.25 MHz exactly. ✔

Derived sync windows (not shown in the UI tables but present in the RTL):
`H_SYNC_START = 1280 + 110 = 1390`, `H_SYNC_END = 1430`;
`V_SYNC_START = 725`, `V_SYNC_END = 730`.

---

## DDR3 frame buffer & DMA behaviour

| Field | Value |
|-------|-------|
| DDR3 base address | `0x38000000` |
| Resolution | 1280 × 720 (visible) |
| Colour depth | 8 bpp — `R[7:5] G[4:2] B[1:0]` |
| Frame size | 1280 × 720 × 1 = 921 600 bytes |
| Last read address | `0x38000000 + 921596` |
| Pixel clock | 74.25 MHz (PLL synthesised) |

### DMA FSM contract (as implemented in `vga_dma_master.v`)

1. `am_read` asserts **only** when the FIFO has free space.
2. Address and control lines are **held steady** for as long as `am_waitrequest` is high
   — no increment, no re-issue.
3. Pixel bytes latch **only** on `am_readdatavalid` pulses.
4. The address pointer advances by exactly 4 bytes per read and wraps at
   `0x38000000 + 921596` back to `0x38000000`.
5. VGA RGB is forced to `8'h00` during every blanking interval.

### FSM states

| State | Encoding | Behaviour |
|-------|---------:|-----------|
| `S_IDLE` | `2'd0` | `am_read` low. Starts a request if `!fifo_full`. |
| `S_REQUEST` | `2'd1` | `am_read` high, all bus signals frozen until `!am_waitrequest`. |
| `S_WAIT_DATA` | `2'd2` | Address accepted; waits for the pipelined `am_readdatavalid`. |

The critical detail is that `am_read` drops **low on the very next clock edge** after a
successful handshake, and `addr_reg` advances on that same edge. A `default` branch
returns to `S_IDLE`.

---

## The embedded Verilog modules

### 1. `vga_controller.v` — VESA 720p timing generator

| Signal | Dir | Width | Notes |
|--------|-----|------:|-------|
| `clk_pix` | in | 1 | 74.25 MHz from the PLL. |
| `rst_n` | in | 1 | Active-low asynchronous reset (KEY[0]). |
| `VGA_HS` | out | reg | Positive-polarity horizontal sync. |
| `VGA_VS` | out | reg | Positive-polarity vertical sync. |
| `VGA_BLANK_N` | out | reg | High only inside the active window. |
| `VGA_SYNC_N` | out | wire | Tied to `1'b0` — ADV7123 uses separate HS/VS. |
| `VGA_CLK` | out | wire | Direct pass-through of `clk_pix`. |
| `pixel_x` | out | reg [10:0] | 0–1279, valid when `video_active`. |
| `pixel_y` | out | reg [9:0] | 0–719, valid when `video_active`. |
| `video_active` | out | wire | High during the visible 1280×720 window. |

Implementation: free-running `h_count` (11 bit, 0–1649) increments every clock;
`v_count` (10 bit, 0–749) increments on `h_end`. Sync windows are combinational
comparisons. Outputs are **registered** in a separate always block, so `VGA_HS`,
`VGA_VS`, `VGA_BLANK_N`, `pixel_x` and `pixel_y` all share one clock of latency.

### 2. `async_fifo.v` — Gray-coded dual-clock FIFO

| Parameter | Default | Meaning |
|-----------|--------:|---------|
| `DATA_WIDTH` | 32 | One Avalon word = four 8-bit pixels. |
| `ADDR_WIDTH` | 9 | Depth = 2⁹ = 512 words. |

Ports split cleanly into write side (`wr_clk`, `wr_rst`, `wr_en`, `wr_data`, `wr_full`)
and read side (`rd_clk`, `rd_rst`, `rd_en`, `rd_data`, `rd_empty`).

**CDC scheme.** Binary and Gray pointers for both domains. Each side synchronises the
*other* side's Gray pointer through a two-flop chain (`rd_ptr_gray_wrclk_d1/d2`,
`wr_ptr_gray_rdclk_d1/d2`). Gray coding guarantees only one bit changes per increment,
so no metastability can produce a spurious full/empty.

`wr_full` inverts the MSB of the synchronised read pointer (standard full-detection
trick); `rd_empty` is a straight equality compare.

**Show-ahead / FWFT read.** `rd_data` is a continuous assign from
`mem[rd_ptr_bin[ADDR_WIDTH-1:0]]`, so it is valid whenever `!rd_empty` **without**
needing `rd_en` asserted first. This is what lets `vga_dma_master` pop the FIFO exactly
when the last byte of the current word is consumed.

`bin2gray` is a Verilog function: `bin2gray = (b >> 1) ^ b;`

### 3. `vga_dma_master.v` — Avalon-MM read master

| Parameter | Default | Meaning |
|-----------|--------:|---------|
| `BASE_ADDR` | `32'h3800_0000` | DDR3 frame buffer base. |
| `FRAME_BYTES` | `32'd921_600` | 1280 × 720 × 1 byte. |
| `FIFO_AWIDTH` | 9 | 512 × 32-bit FIFO. |

Instantiates `async_fifo` internally (`u_pixel_fifo`) — you do **not** need a separate
FIFO IP.

`am_readdatavalid` drives `fifo_wr_en` directly, so the FIFO write port needs no extra
gating. The write side runs on `am_clk` (the Avalon fabric clock); the read side runs
on `pix_clk`.

**Pixel-side byte de-multiplexer.** A 2-bit `byte_sel` cycles 0→1→2→3→0, one step per
`pixel_request` when the FIFO is non-empty. The active byte is selected with a 4-way
multiplexer:

```verilog
assign pixel_data = (byte_sel == 2'd0) ? fifo_rd_data[7:0]   :
                     (byte_sel == 2'd1) ? fifo_rd_data[15:8]  :
                     (byte_sel == 2'd2) ? fifo_rd_data[23:16] :
                                           fifo_rd_data[31:24];
```

**Pop timing.** `fifo_rd_en` fires when `byte_sel == 2'd3` is being consumed — i.e. the
next word is requested one pixel *before* it is needed, hiding the show-ahead latency
entirely. `pixel_valid = pixel_request && !fifo_empty`.

### 4. `vga_top.v` — integration wrapper

| Port | Dir | Width | Source |
|------|-----|------:|--------|
| `CLOCK_50` | in | 1 | Onboard oscillator. |
| `KEY0` | in | 1 | Active-low reset. |
| `clk_pixel` | in | 1 | 74.25 MHz from the Platform Designer PLL. |
| `clk_avalon` | in | 1 | HPS fabric clock for the Avalon-MM domain. |
| `am_address` | out | [31:0] | → `f2h_sdram_master` slave port. |
| `am_read` | out | 1 | → `f2h_sdram_master`. |
| `am_waitrequest` | in | 1 | ← `f2h_sdram_master`. |
| `am_readdata` | in | [31:0] | ← `f2h_sdram_master`. |
| `am_readdatavalid` | in | 1 | ← `f2h_sdram_master`. |
| `VGA_HS`/`VGA_VS` | out | 1 | From `vga_controller`. |
| `VGA_BLANK_N`/`VGA_SYNC_N` | out | 1 | From `vga_controller`. |
| `VGA_CLK` | out | 1 | = `clk_pixel`. |
| `VGA_R`/`VGA_G`/`VGA_B` | out | [7:0] | Expanded colour. |

`rst_n = KEY0`. `pixel_request = video_active` — exactly one pixel byte is consumed per
pixel clock while inside the 1280×720 window.

**3-3-2 → 8/8/8 expansion** by bit replication, which preserves the full black→white
range with no LUT:

```verilog
wire [7:0] red8 = {red3, red3, red3[2:1]};
wire [7:0] grn8 = {grn3, grn3, grn3[2:1]};
wire [7:0] blu8 = {blu2, blu2, blu2, blu2};
```

**Electrical safety.** RGB is gated to `8'h00` whenever `video_active` is low, so the
DAC sees black through the whole front-porch/sync/back-porch region:

```verilog
assign VGA_R = video_active ? red8 : 8'h00;
```

### 5. `tb_vga_dma_master.v` — ModelSim testbench

Self-contained bus-functional model of the `f2h_sdram_master` slave.

| Element | Detail |
|---------|--------|
| `am_clk` | `#5` half-period → 100 MHz. |
| `pix_clk` | `#6.734` half-period → ≈74.25 MHz. |
| `FIFO_AWIDTH` | Overridden to `5` (32 words) for fast simulation. |
| Reset | Held high for 40 ns, then released. |
| Stall injection | `am_waitrequest` forced high for the first read between t=100 and t=140. |
| Read data | `{24'h000000, am_address[7:0]}` — an easily recognisable fake pattern. |
| Instrumentation | `$monitor` prints time, address, read, waitrequest, readdatavalid. |
| Pixel consumption | 16 `pixel_request` pulses to exercise the byte de-mux and FIFO pop. |
| Finish | `$finish` after `#500` with a summary `$display`. |

### 6. `de1_soc_pins.qsf` — Quartus pin constraints

Fragment to be **appended** into the `soc_system` top-level `.qsf`. All I/O standard is
`3.3-V LVTTL`.

Assignments covered: `CLOCK_50` (PIN_AF14), `KEY[0]` (PIN_AA14), `VGA_HS` (PIN_B11),
`VGA_VS` (PIN_D11), `VGA_BLANK_N` (PIN_F10), `VGA_SYNC_N` (PIN_C10), `VGA_CLK`
(PIN_A11), and the full `VGA_R[7:0]` / `VGA_G[7:0]` / `VGA_B[7:0]` buses. The three RGB
buses get their LVTTL standard applied in one shot via wildcard `-to VGA_R[*]`.

---

## Page sections

The sidebar defines eight anchors. Each maps to one `<section>` with a `scroll-mt-24`
offset so the sticky header does not cover the heading.

| Anchor | Eyebrow | Heading |
|--------|---------|---------|
| `overview` | Part I + II | Hardware / Software Co-Design Overview |
| `timing` | Task 1 | 720p VESA Timing Specification |
| `memory` | Task 2 | DDR3 Frame Buffer & DMA Behavior |
| `code` | Deliverable | Verilog RTL Modules |
| `sim` | Phase A | ModelSim / QuestaSim Verification |
| `pins` | Phase B | Quartus Pin Planning (5CSEMA5F31C6) |
| `capp` | Part II | How the Verilog Maps to Your snake.c |
| `deploy` | Phase C | Interconnect, Compile & Flash |

**Sidebar extras.** Below the nav list sits an amber "Address note" callout warning that
the lab spec targets `0x38000000` via `f2h_sdram_master`, whereas the user's original C
file used the classic lightweight-bridge demo addresses `0xC8000000` / `0xC9000000`.

The header carries a "Jump to RTL" button (`href="#code"`), hidden below the `sm`
breakpoint.

---

## Pin assignments

| Signal | Pin | Note |
|--------|-----|------|
| `CLOCK_50` | PIN_AF14 | 50 MHz onboard oscillator |
| `KEY[0]` | PIN_AA14 | Active-low master reset |
| `VGA_HS` | PIN_B11 | Positive polarity |
| `VGA_VS` | PIN_D11 | Positive polarity |
| `VGA_BLANK_N` | PIN_F10 | High during active video |
| `VGA_SYNC_N` | PIN_C10 | Tied low (unused) |
| `VGA_CLK` | PIN_A11 | 74.25 MHz pixel clock out |

The full 24-bit RGB bus map (`PIN_A13` … `PIN_J14`) lives in the `de1_soc_pins.qsf` tab.
The "Phase B" section links directly to that tab via a button that calls
`setActiveFile("qsf")` — an in-page cross-reference rather than a route change.

---

## HPS C application integration

The section splits into "what your C file already does right" and "what to change".

### Already correct in the provided `snake.c`

* `open("/dev/mem", O_RDWR | O_SYNC)` + `mmap()` to reach the physical frame buffer.
* `termios` reconfiguration clearing `ICANON` / `ECHO`, plus `fcntl(O_NONBLOCK)` for
  W/A/S/D polling.
* Per-cell tail/segment redraw logic instead of clearing the whole buffer each frame.

### Required changes to match this RTL

| Change | From | To |
|--------|------|-----|
| Pixel buffer base | `0xC8000000` | `0x38000000` |
| Span | bridge-demo value | `921600` |
| Pixel type | `short pixel_buffer[]` (RGB565) | `volatile unsigned char *` |
| Colour packing | RGB565 | `(r<<5) \| (g<<2) \| b` |
| Stride | `320*2` bytes/row | `1280` bytes/row |
| Addressing | — | `pixel = base + y*1280 + x` |
| `CELL_SIZE` / screen | 320 × 720-ish | **20** / **1280 × 720** |
| Text overlay | `CHAR_BUF_*` buffer | Drop it, or render the score with pixel blocks — this design has no character/text plane. |

---

## Deployment pipeline

Seven numbered steps in the "Phase C" section:

1. Open Platform Designer (QSYS); add the HPS component; configure the DDR3 parameters.
2. Add `vga_top.v` / `vga_dma_master.v` as a custom component; connect its Avalon-MM
   master port to the `f2h_sdram_master` slave port.
3. Add a PLL IP producing 74.25 MHz from `CLOCK_50`; route `clk_avalon` from the HPS
   fabric clock.
4. Generate the QSYS system; apply `de1_soc_pins.qsf`; compile with `Ctrl+L` in Quartus
   Prime; confirm timing closure.
5. Program the fabric over USB-Blaster using `soc_system.sof`.
6. Transfer `snake.c` to the DE1-SoC Linux target.

Plus the on-target build commands:

```bash
gcc -O2 -o snake snake.c
sudo ./snake
```

---

## Simulation (Phase A)

```tcl
vlib work
vlog async_fifo.v vga_dma_master.v tb_vga_dma_master.v
vsim tb_vga_dma_master
run -all
```

Waveform checkpoints to verify:

* `am_addr` increments by exactly 4 only when `am_waitrequest` is **low** *and*
  `am_read` is **high**.
* `am_read` drops low the clock cycle immediately after a successful handshake.
* Address/control lines stay frozen for the entire duration `am_waitrequest` is
  asserted.

The site cross-references the `tb_vga_dma_master.v` tab from this section.

---

## Regenerating `image.hex` or adding your own module

The site ships no image file. To add one, append an object to `verilogFiles`:

```ts
{
  id: "my_module",
  filename: "my_module.v",
  tag: "Custom — My Module",
  description: "One paragraph describing what it does and how it hooks in.",
  code: `module my_module (...);\n...\nendmodule\n`,
}
```

Nothing else needs editing — the tab strip, the active panel, and the copy button all
iterate over the array. Keep `id` unique; `filename` must match the real file you will
add to your Quartus project.

Because the code lives in template literals, **backticks (`` ` ``) and `${` must be
escaped** (`\``, `\${`) inside any Verilog you add.

---

## Design notes and conventions

* **Verilog-2001 only.** No SystemVerilog. Ports are ANSI-style, storage is
  `reg`/`wire`, all sequential logic is `always @(posedge clk or negedge rst_n)` (or
  `posedge reset`) — no `always_ff`, `always_comb`, `logic`, or `typedef`.
* **Reset polarity is inconsistent by design**, because the modules come from different
  phases of the lab: `vga_controller` and `async_fifo` use asynchronous active-low
  `rst_n`; `vga_dma_master` uses asynchronous active-high `*_reset` (matching the
  Avalon convention).
* **One clock domain per module**, except the two that deliberately straddle a boundary
  (`vga_dma_master`, `async_fifo`). There is no third clock.
* **Registered outputs** in `vga_controller` ensure all timing and coordinate signals
  share one clock of latency, so they never disagree by a cycle.
* **Colour expansion is bit replication, not a LUT.** `{red3, red3, red3[2:1]}` maps
  000→000, 001→001, …, 111→111 exactly; no lost or duplicated levels.
* **Blanking forces black** rather than leaving the DAC input floating — an explicit
  electrical-safety requirement of the assignment.
* **The UI has one piece of state.** Everything else is derived from the two data
  modules. No routing library, no state management library, no CSS-in-JS.

### Accessibility and UX details

* Sidebar is `hidden lg:block` — on smaller screens the content stacks full-width.
* The "Jump to RTL" button is `hidden sm:flex`.
* Anchor sections use `scroll-mt-24` to clear the sticky header.
* Code panels scroll internally at 620 px, so the page never becomes unreadably long.
