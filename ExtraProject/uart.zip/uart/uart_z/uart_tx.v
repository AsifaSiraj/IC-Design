module uart_tx #(
    parameter integer CLK_FREQ_HZ = 50_000_000,
    parameter integer BAUD_RATE   = 115200
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] tx_data,
    input  wire       tx_start,
    output reg        tx,
    output reg        tx_busy,
    output reg        tx_done
);

    localparam integer CLKS_PER_BIT = CLK_FREQ_HZ / BAUD_RATE;

    reg [15:0] clk_count;
    reg [3:0]  bit_index;
    reg [9:0]  shifter;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx        <= 1'b1;
            tx_busy   <= 1'b0;
            tx_done   <= 1'b0;
            clk_count <= 16'd0;
            bit_index <= 4'd0;
            shifter   <= 10'h3FF;
        end else begin
            tx_done <= 1'b0;

            if (!tx_busy) begin
                tx <= 1'b1;
                if (tx_start) begin
                    // Frame: start(0), 8 data bits (LSB first), stop(1)
                    shifter   <= {1'b1, tx_data, 1'b0};
                    tx_busy   <= 1'b1;
                    clk_count <= 16'd0;
                    bit_index <= 4'd0;
                end
            end else begin
                tx <= shifter[bit_index];

                if (clk_count == CLKS_PER_BIT - 1) begin
                    clk_count <= 16'd0;
                    if (bit_index == 4'd9) begin
                        tx_busy   <= 1'b0;
                        bit_index <= 4'd0;
                        tx_done   <= 1'b1;
                        tx        <= 1'b1;
                    end else begin
                        bit_index <= bit_index + 1'b1;
                    end
                end else begin
                    clk_count <= clk_count + 1'b1;
                end
            end
        end
    end

endmodule