#=====================================================================
# SDC Constraints File for Cyclone V GX UART Project
# Project: uart_top_de1soc
# Board: Terasic Cyclone V GX Starter Kit
#=====================================================================

# Define the clock input - 50MHz
create_clock -period 20 -name {CLOCK_50} [get_ports {CLOCK_50}]

# Automatically generated input and output delays
derive_pll_clocks
derive_clock_uncertainty

# Set false paths for async reset - it is asynchronous by design
set_false_path -from [get_ports {KEY[*]}] -to *

# UART signals - no strict timing constraints needed for 115200 baud
# These are relatively slow speed signals
set_input_delay -clock CLOCK_50 -max 5 [get_ports {UART_RXD}]
set_input_delay -clock CLOCK_50 -min 0 [get_ports {UART_RXD}]
set_output_delay -clock CLOCK_50 -max 5 [get_ports {UART_TXD}]
set_output_delay -clock CLOCK_50 -min 0 [get_ports {UART_TXD}]

# LED outputs - relaxed timing constraints
set_output_delay -clock CLOCK_50 -max 10 [get_ports {LEDR[*]}]
set_output_delay -clock CLOCK_50 -min 0 [get_ports {LEDR[*]}]

# Allow implementation tools to optimize timing for UART datapath
# Critical path is the UART sampling and majority voting logic
# No specific MCO constraints for 115.2kbps operation

#=====================================================================
# End of SDC file
#=====================================================================
