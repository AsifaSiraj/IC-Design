module uart_top_de1soc (
    input  wire       CLOCK_50,
    input  wire [3:0] KEY,
    input  wire       UART_RXD,
    output wire       UART_TXD,
    output wire [9:0] LEDR
);

    // KEY[0] is active-low on DE1-SoC; use as reset button.
    wire rst_n = KEY[0];

    wire [7:0] rx_data;
    wire       rx_done;
    reg  [7:0] tx_data;
    reg        tx_start;
    wire       tx_busy;

    reg [7:0] latched_data;
    reg       have_byte;

    uart_rx #(
        .CLK_FREQ_HZ(50_000_000),
        .BAUD_RATE(115200)
    ) u_rx (
        .clk(CLOCK_50),
        .rst_n(rst_n),
        .rx(UART_RXD),
        .rx_data(rx_data),
        .rx_done(rx_done)
    );

    uart_tx #(
        .CLK_FREQ_HZ(50_000_000),
        .BAUD_RATE(115200)
    ) u_tx (
        .clk(CLOCK_50),
        .rst_n(rst_n),
        .tx_data(tx_data),
        .tx_start(tx_start),
        .tx(UART_TXD),
        .tx_busy(tx_busy),
        .tx_done()
    );

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            tx_data      <= 8'd0;
            tx_start     <= 1'b0;
            latched_data <= 8'd0;
            have_byte    <= 1'b0;
        end else begin
            tx_start <= 1'b0;

            // Buffer incoming byte then transmit when TX is available.
            if (rx_done) begin
                latched_data <= rx_data;
                have_byte    <= 1'b1;
            end

            if (have_byte && !tx_busy) begin
                tx_data   <= latched_data;
                tx_start  <= 1'b1;
                have_byte <= 1'b0;
            end
        end
    end

    // Status LEDs for quick hardware debug.
    assign LEDR[7:0] = latched_data;
    assign LEDR[8]   = tx_busy;
    assign LEDR[9]   = have_byte;

endmodule