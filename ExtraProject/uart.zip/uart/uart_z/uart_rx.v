module uart_rx #(
    parameter integer CLK_FREQ_HZ = 50_000_000,
    parameter integer BAUD_RATE   = 115200
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       rx,
    output reg  [7:0] rx_data,
    output reg        rx_done
);
    localparam integer CLKS_PER_BIT = CLK_FREQ_HZ / BAUD_RATE;
    localparam integer HALF_BIT     = CLKS_PER_BIT / 2;

    localparam [1:0] IDLE=2'd0, START=2'd1, DATA=2'd2, STOP=2'd3;

    reg [1:0]  state;
    reg [15:0] clk_count;
    reg [2:0]  bit_index;
    reg [7:0]  data_reg;

    // 2-FF synchronizer for async rx line
    reg rx_s1, rx_s2;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin rx_s1 <= 1'b1; rx_s2 <= 1'b1; end
        else        begin rx_s1 <= rx;   rx_s2 <= rx_s1; end
    end
    wire rx_s = rx_s2;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state     <= IDLE;
            clk_count <= 0;
            bit_index <= 0;
            data_reg  <= 0;
            rx_data   <= 0;
            rx_done   <= 1'b0;
        end else begin
            rx_done <= 1'b0;

            case (state)
                IDLE: begin
                    clk_count <= 0;
                    bit_index <= 0;
                    if (rx_s == 1'b0) state <= START;   // start-bit edge
                end

                // Advance to middle of start bit, then confirm it's still low
                START: begin
                    if (clk_count == HALF_BIT - 1) begin
                        clk_count <= 0;
                        if (rx_s == 1'b0) state <= DATA;
                        else              state <= IDLE;   // false start
                    end else
                        clk_count <= clk_count + 1'b1;
                end

                // Sample every CLKS_PER_BIT (which lands on the middle of each data bit
                // because we started counting from the middle of the start bit)
                DATA: begin
                    if (clk_count == CLKS_PER_BIT - 1) begin
                        clk_count           <= 0;
                        data_reg[bit_index] <= rx_s;
                        if (bit_index == 3'd7) begin
                            bit_index <= 0;
                            state     <= STOP;
                        end else
                            bit_index <= bit_index + 1'b1;
                    end else
                        clk_count <= clk_count + 1'b1;
                end

                // Sample stop bit in its middle, latch data if it's high
                STOP: begin
                    if (clk_count == CLKS_PER_BIT - 1) begin
                        clk_count <= 0;
                        if (rx_s == 1'b1) begin
                            rx_data <= data_reg;
                            rx_done <= 1'b1;
                        end
                        state <= IDLE;
                    end else
                        clk_count <= clk_count + 1'b1;
                end

                default: state <= IDLE;
            endcase
        end
    end
endmodule