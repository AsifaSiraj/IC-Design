# UART Project — `uart_z`

This directory is a complete, compiling **Intel Quartus Prime** project implementing a
115200-baud UART loopback on a Cyclone V FPGA.

Top-level entity: **`uart_top_de1soc`**
Device: **`5CGXFC5C6F27C7`** (Cyclone V GX)
Last successful compile: **Mon Jul 20 12:21:50 2026**

For the project overview, design rationale, and known issues, see the
[parent README](../README.md).

---

## Directory contents

10 files in the root plus 4 tool-generated sub-directories. **112 files, 12.68 MB.**

```
uart_z/
├── README.md                    ← you are here
├── UART.qpf                     Quartus project file
├── UART.qsf                     settings + pin assignments + file list
├── UART.qws                     GUI workspace state (binary)
├── pins.qsf                     Cyclone V GX Starter Kit reference pins
├── timing.sdc                   TimeQuest SDC constraints
│
├── uart_top_de1soc.v            TOP LEVEL — 73 lines
├── uart_rx.v                    receiver — 89 lines
├── uart_rx.v.bak               superseded 16× oversampling receiver — 183 lines
├── uart_tx.v                    transmitter — 60 lines
├── c5_pin_model_dump.txt        Quartus I/O pin-model index dump
│
├── db/                          91 files — post-fit internal databases
├── incremental_db/              21 files — incremental-compilation cache
├── output_files/                14 files — human-readable reports + UART.sof
└── simulation/modelsim/          3 files — EDA simulation outputs
```

---

## Root files

### `UART.qpf` — 1279 bytes

Minimal Quartus Project File.

| Field | Value |
|-------|-------|
| `QUARTUS_VERSION` | `18.1` |
| `DATE` | `13:35:53  July 16, 2026` |
| `PROJECT_REVISION` | `UART` |

The first 23 lines are the standard Intel licence header. The file is auto-generated and
should not be hand-edited.

### `UART.qsf` — 4186 bytes

The main settings file. Same 36-line licence header, then:

**Global assignments**

| Assignment | Value |
|------------|-------|
| `FAMILY` | `Cyclone V` |
| `DEVICE` | `5CGXFC5C6F27C7` |
| `TOP_LEVEL_ENTITY` | `uart_top_de1soc` |
| `PROJECT_OUTPUT_DIRECTORY` | `output_files` |
| `MIN_CORE_JUNCTION_TEMP` | 0 |
| `MAX_CORE_JUNCTION_TEMP` | 85 |
| `ERROR_CHECK_FREQUENCY_DIVISOR` | 256 |
| `EDA_SIMULATION_TOOL` | `ModelSim-Altera (Verilog)` |
| `EDA_TIME_SCALE` | `1 ps` |
| `EDA_OUTPUT_DATA_FORMAT` | `VERILOG HDL` |

**File list** (lines 52–57)

```
VERILOG_FILE  tb_uart_loopback.v     ← NOT PRESENT on disk
VERILOG_FILE  uart_rx.v
VERILOG_FILE  uart_top_de1soc.v
VERILOG_FILE  uart_tx.v
SOURCE_FILE   pins.qsf
SOURCE_FILE   uart_top_de1soc.qsf_pins.qsf   ← NOT PRESENT on disk
```

> Two referenced files are missing: `tb_uart_loopback.v` and
> `uart_top_de1soc.qsf_pins.qsf`. Both produce warnings, neither blocks bitstream
> generation. `uart_top_de1soc.qsf_pins.qsf` is almost certainly a Terasic board-script
> export that was never committed.

**SDC files** (lines 80–81) — `timings.sdc` *and* `timing.sdc`. Only the singular
version exists on disk.

**Partition** — `PARTITION_NETLIST_TYPE SOURCE`, `PARTITION_FITTER_PRESERVATION_LEVEL
PLACEMENT_AND_ROUTING`, `PARTITION_COLOR 16764057`, hierarchy `root_partition`.

**Pin locations** (lines 61–79) — 17 assignments for `CLOCK_50`, `KEY[0..3]`,
`LEDR[0..9]`, `UART_RXD`, `UART_TXD`. `KEY[0..3]` get `IO_STANDARD "1.2 V"`.

### `UART.qws` — 2373 bytes, **binary**

Quartus GUI workspace state — window geometry, dock positions, open editors, tab
selections. **Machine-specific and per-user.** Safe to delete; Quartus recreates it.

### `pins.qsf` — 1920 bytes

Header comment: *"Cyclone V GX Starter Kit — Quartus Pin Assignment File (.qsf)"*.

Assigns `CLOCK_50` (`PIN_R20`, 3.3-V LVTTL), `KEY[0..3]` (1.2 V), `LEDR[0..9]` (2.5 V),
and **`UART_RX` / `UART_TX`** (`PIN_M9` / `PIN_L9`, 2.5 V).

> ⚠ The UART port names here (`UART_RX`, `UART_TX`) do **not** match the top-level
> entity's ports (`UART_RXD`, `UART_TXD`). These two assignments are therefore inert —
> the effective assignments are the `UART_RXD`/`UART_TXD` lines inside `UART.qsf`.

### `timing.sdc` — 1446 bytes

34 lines, fully commented. Header: *"SDC Constraints File for Cyclone V GX UART
Project / Project: uart_top_de1soc / Board: Terasic Cyclone V GX Starter Kit"*.

```tcl
create_clock -period 20 -name {CLOCK_50} [get_ports {CLOCK_50}]
derive_pll_clocks
derive_clock_uncertainty
set_false_path -from [get_ports {KEY[*]}] -to *
set_input_delay  -clock CLOCK_50 -max 5  [get_ports {UART_RXD}]
set_input_delay  -clock CLOCK_50 -min 0  [get_ports {UART_RXD}]
set_output_delay -clock CLOCK_50 -max 5  [get_ports {UART_TXD}]
set_output_delay -clock CLOCK_50 -min 0  [get_ports {UART_TXD}]
set_output_delay -clock CLOCK_50 -max 10 [get_ports {LEDR[*]}]
set_output_delay -clock CLOCK_50 -min 0  [get_ports {LEDR[*]}]
```

The trailing comment notes there are deliberately no MCO constraints, since 115.2 kbps
is far too slow to need them.

### `c5_pin_model_dump.txt` — 3697 bytes

Generated pin-model index dump. ~100 lines of

```
io_4iomodule_c5_index: 61gpio_index: 2
io_4iomodule_c5_index: 40gpio_index: 6
```

Maps each of the 64 `io_4iomodule` instances in the Cyclone V device to its global GPIO
index. Quartus uses this internally when resolving pin assignments. Meaningless to read
by hand; **safe to delete and regenerate**.

---

## RTL sources

### `uart_top_de1soc.v` — 1753 bytes, 73 lines — **TOP LEVEL**

```verilog
module uart_top_de1soc (
    input  wire       CLOCK_50,
    input  wire [3:0] KEY,
    input  wire       UART_RXD,
    output wire       UART_TXD,
    output wire [9:0] LEDR
);
    wire rst_n = KEY[0];
```

**Ports**

| Port | Dir | Width | Notes |
|------|-----|------:|-------|
| `CLOCK_50` | in | 1 | 50 MHz oscillator |
| `KEY` | in | [3:0] | Only `KEY[0]` is used, as active-low reset |
| `UART_RXD` | in | 1 | Serial data in, active-low idle |
| `UART_TXD` | out | 1 | Serial data out |
| `LEDR` | out | [9:0] | Status/debug display |

**Internals**

| Signal | Type | Purpose |
|--------|------|---------|
| `rst_n` | wire | `= KEY[0]`, active-low |
| `rx_data` | wire [7:0] | From `uart_rx` |
| `rx_done` | wire | 1-cycle strobe when a byte is valid |
| `tx_data` | reg [7:0] | Into `uart_tx` |
| `tx_start` | reg | 1-cycle request strobe |
| `tx_busy` | wire | From `uart_tx`; `tx_done` left unconnected |
| `latched_data` | reg [7:0] | Single-byte buffer holding the received byte |
| `have_byte` | reg | Buffer-valid flag |

**Buffering logic** (lines 45–66) — a single always block on
`posedge CLOCK_50 or negedge rst_n`:

1. `tx_start <= 1'b0` every cycle by default (auto-clearing strobe).
2. On `rx_done`: `latched_data <= rx_data; have_byte <= 1'b1;`
3. On `have_byte && !tx_busy`: `tx_data <= latched_data; tx_start <= 1'b1; have_byte <= 1'b0;`

Because the buffer is single-entry, a byte arriving while a previous one is still being
transmitted will overwrite `latched_data`. At 115200 baud with identical RX/TX rates this
cannot happen in loopback — but if you add any buffering delay, upgrade this to a proper
FIFO.

**LED status map** (lines 69–71)

| LED | Meaning |
|-----|---------|
| `LEDR[7:0]` | `latched_data` — the most recently received byte |
| `LEDR[8]` | `tx_busy` |
| `LEDR[9]` | `have_byte` |

### `uart_rx.v` — 3173 bytes, 89 lines

**Parameters**

| Name | Type | Default |
|------|------|--------:|
| `CLK_FREQ_HZ` | integer | `50_000_000` |
| `BAUD_RATE` | integer | `115200` |

**Ports** — `clk`, `rst_n`, `rx` in; `rx_data` [7:0], `rx_done` out.

**Derived constants**

```verilog
localparam integer CLKS_PER_BIT = CLK_FREQ_HZ / BAUD_RATE;   // 434
localparam integer HALF_BIT     = CLKS_PER_BIT / 2;          // 217
```

**States** — `IDLE=2'd0`, `START=2'd1`, `DATA=2'd2`, `STOP=2'd3`.

**Input synchroniser** (lines 22–27) — 2-flop chain, both stages reset to `1'b1`:

```verilog
reg rx_s1, rx_s2;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin rx_s1 <= 1'b1; rx_s2 <= 1'b1; end
    else        begin rx_s1 <= rx;   rx_s2 <= rx_s1; end
end
wire rx_s = rx_s2;
```

**FSM detail**

* `IDLE` — clears `clk_count` and `bit_index`; transitions to `START` on `rx_s == 1'b0`.
* `START` — waits `HALF_BIT` clocks, then re-samples. Low → `DATA` (real start bit);
  high → `IDLE` (false start, e.g. glitch or noise).
* `DATA` — samples once every `CLKS_PER_BIT` clocks into `data_reg[bit_index]`.
  `bit_index` runs 0→7, then `STOP`. Because counting started at mid-start-bit, each
  sample lands at the centre of its own bit.
* `STOP` — waits `CLKS_PER_BIT` clocks, samples the middle of the stop bit. If high,
  latches `rx_data <= data_reg` and pulses `rx_done <= 1'b1`. Returns to `IDLE` either way.
* `default` — returns to `IDLE` (defensive; unreachable in `2`-bit encoding).

`rx_done` is cleared at the top of every cycle, so it is a clean single-cycle pulse.

### `uart_rx.v.bak` — 7528 bytes, 183 lines

The **superseded** receiver. Retained as a record of the 16×-oversampling approach that
was abandoned. Its extensive comments explain why.

**What it added**

| Feature | Detail |
|---------|--------|
| `OVERSAMPLE` parameter | `16` |
| `SAMPLE_POINT` | `CLKS_PER_BIT / 16` = 27 clocks |
| `CENTER_OFFSET` | `CLKS_PER_BIT >> 1` = 217 |
| `rx_samples[15:0]` | 16-sample capture register |
| Population count | Manual sum of all 16 bits → `ones_count[4:0]` |
| Majority vote | `rx_sample = (ones_count >= 5'd8)` |
| `bit_start` | Running adder replacing a `bit_index * CLKS_PER_BIT` multiply |

**The recorded timing failure** — quoted verbatim from the file:

> `// ===== FIX =====`
> `// Running "start of current bit" marker, updated with a single small`
> `// adder (+CLKS_PER_BIT) instead of recomputing bit_index * CLKS_PER_BIT`
> `// (a multiplier) every clock cycle. This was the source of the huge`
> `// combinational path (bit_index -> multiplier -> adders -> comparators`
> `// -> rx_samples) that was failing setup timing by ~9 ns.`

and again in the `DATA` state:

> `// Center point: bit_start + CENTER_OFFSET, where bit_start`
> `// is incremented by CLKS_PER_BIT each time we move to the`
> `// next bit (cheap adder) instead of being recomputed as`
> `// bit_index * CLKS_PER_BIT every cycle (expensive`
> `// multiplier that blew the timing budget).`

**If you ever re-enable oversampling, keep the `bit_start` adder.** Do not reintroduce
the multiply.

> This file is **not** in the `UART.qsf` file list and is **not** compiled.

### `uart_tx.v` — 1795 bytes, 60 lines

**Parameters** — `CLK_FREQ_HZ` (50 MHz), `BAUD_RATE` (115200).
**Derived** — `CLKS_PER_BIT = CLK_FREQ_HZ / BAUD_RATE` = 434.

**Ports** — in: `clk`, `rst_n`, `tx_data[7:0]`, `tx_start`; out: `tx`, `tx_busy`,
`tx_done`.

**Registers**

| Signal | Width | Purpose |
|--------|------:|---------|
| `clk_count` | [15:0] | Bit-period countdown |
| `bit_index` | [3:0] | Current position 0..9 |
| `shifter` | [9:0] | Preloaded frame |

**Frame preload** (line 35) — the clever bit:

```verilog
shifter <= {1'b1, tx_data, 1'b0};
//          stop  data[7:0]  start
```

Index 0 is the start bit, 1–8 are the data bits LSB-first, 9 is the stop bit. Walking
`shifter[bit_index]` upward produces a correct 8-N-1 frame with no special-casing.

**Behaviour**

* Idle (`!tx_busy`): `tx` held high; a `tx_start` pulse loads the shifter, sets
  `tx_busy`, and zeroes the counters.
* Busy: `tx <= shifter[bit_index]`, `clk_count` free-runs. When
  `clk_count == CLKS_PER_BIT - 1`, either advance `bit_index` or, at `bit_index == 9`,
  drop `tx_busy`, reset `bit_index`, pulse `tx_done`, and force `tx` high.
* `tx_done` is cleared at the top of each cycle, so it is a single-cycle pulse.

---

## `output_files/` — 14 files

| File | Size | Contents |
|------|-----:|----------|
| `UART.sof` | 3 993 969 | **The bitstream.** Program this. |
| `UART.done` | 26 | Stage-completion marker |
| `UART.flow.rpt` | 8 738 | End-to-end compilation log (all stages) |
| `UART.map.rpt` | 32 026 | Analysis & Synthesis report |
| `UART.map.summary` | 522 | Condensed map results |
| `UART.fit.rpt` | 235 368 | Fitter placement/routing report |
| `UART.fit.smsg` | 482 | Fitter warning/error summary |
| `UART.fit.summary` | 732 | **Resource utilisation table** |
| `UART.sta.rpt` | 76 616 | TimeQuest timing report |
| `UART.sta.summary` | 1 219 | **Timing slack per corner** |
| `UART.asm.rpt` | 4 096 | Assembler report |
| `UART.eda.rpt` | 6 117 | ModelSim invocation log |
| `UART.pin` | 80 681 | Post-fit pin assignment table |
| `UART.jdi` | 225 | JTAG debug metadata |
| `UART.sld` | 21 | Minimal Platform Designer descriptor |

### `UART.fit.summary` — verified resource utilisation

```
Fitter Status : Successful - Mon Jul 20 12:21:50 2026
Quartus Prime Version : 18.1.0 Build 625 09/12/2018 SJ Lite Edition
Top-level Entity Name : uart_top_de1soc
Device : 5CGXFC5C6F27C7
```

| Metric | Used / Available | % |
|--------|------------------:|---:|
| Logic (ALMs) | 56 / 29 080 | < 1 % |
| Total registers | 112 | — |
| Total pins | 17 / 364 | 5 % |
| Block memory bits | 0 / 4 567 040 | 0 % |
| RAM blocks | 0 / 446 | 0 % |
| DSP blocks | 0 / 150 | 0 % |
| PLLs | 0 / 12 | 0 % |
| DLLs | 0 / 4 | 0 % |

### `UART.sta.summary` — verified timing closure

| Corner | Setup | Hold | Min pulse width |
|--------|------:|-----:|----------------:|
| Slow 1100 mV 85 °C | +1.442 ns | +0.234 ns | +9.093 ns |
| Slow 1100 mV 0 °C | +1.414 ns | +0.213 ns | +8.999 ns |
| Fast 1100 mV 85 °C | +5.446 ns | +0.127 ns | +9.412 ns |
| Fast 1100 mV 0 °C | +5.663 ns | +0.115 ns | +9.398 ns |

**TNS = 0.000 in all four corners.** No timing violations.

### `UART.map.summary`

`Analysis & Synthesis Status : Successful - Mon Jul 20 12:20:56 2026`, 91 registers,
17 pins, no memory or DSP. (The fitter later reports 112 registers after optimisation.)

---

## `db/` — 91 files

Post-fit internal relational databases. Regenerated on every compile; safe to delete
(but the next compile will be slower).

| File pattern | Count | What it holds |
|--------------|------:|---------------|
| `UART.(0..2).cnf.{cdb,hdb}` | 6 | Per-partition pin-location and I/O-buffer databases |
| `UART.{map,fit,asm,eda,sta}.qmsg` | 5 | Stage message databases |
| `UART.{asm,fit,map,sta,routing}.rdb` | 5 | Routed/analysis databases |
| `UART.cbx.xml` | 1 | Component-box GUI state |
| `UART.{cmp,map}.{cdb,hdb,bpm,logdb,rdb,kpt}` | ~13 | Circuit & logic-element databases |
| `UART.cmp.idb` | 1 | Index database |
| `UART.cyclonev_io_sim_cache.*.hsd` | 4 | I/O simulation caches (fast/slow, 0 °C/85 °C) |
| `UART.db_info` | 1 | Database version manifest |
| `UART.hier_info`, `UART.hif` | 2 | Design hierarchy |
| `UART.lpc.{html,rdb,txt}` | 3 | Logic Partitioning Connectivity analysis |
| `UART.map.ammdb`, `UART.vpr.ammdb` | 2 | Memory/metastability analysis |
| `UART.pre_map.hdb` | 1 | Pre-mapping heap database |
| `UART.root_partition.map.reg_db.cdb` | 1 | Partition register database |
| `UART.rtlv*.{hdb,cdb}` | 3 | Retiming / swap-netlist variants |
| `UART.sld_design_entry*.sci` | 2 | Qsys component metadata |
| `UART.smart_action.txt` | 1 | Fitter "smart action" recommendations |
| `UART.smp_dump.txt` | 1 | Partitioning dump |
| `UART.sta_cmp.7_H6_slow_1100mv_85c.tdb` | 1 | Setup-slack comparison vs previous run |
| `UART.tiscmp.*.ddb` (8) | 8 | Per-corner timing analysis databases |
| `UART.tis_db_list.ddb` | 1 | Timing-analysis DB manifest |
| `UART.tmw_info` | 1 | TimeQuest metadata |
| `UART_partition_pins.json` | 1 | Partition pin manifest |
| `.cmp.kpt`, `.cmp_merge.kpt` | 2 | Internal key-path indices |

---

## `incremental_db/` — 21 files

Incremental-compilation cache. Ships with its own `README` (the only documentation file
inside any `db/` tree in this repository):

> "This folder contains data for incremental compilation.
> The `compiled_partitions` sub-folder contains previous compilation results for each
> partition. As long as this folder is preserved, incremental compilation results from
> earlier compiles can be re-used. To perform a clean compilation from source files for
> all partitions, both the `db` and `incremental_db` folder should be removed."

Files are `<entity>.<partition>.{map,cmp}.{cdb,hdb,kpt,dpi,dfp}` variants plus
`UART.{rrp.hdb,rrs.cdb}` (routing-preservation and routing-snapshot records).

---

## `simulation/modelsim/` — 3 files

| File | Size | Contents |
|------|-----:|----------|
| `UART.vo` | 154 789 | Precompiled ModelSim-Altera simulation library for this design |
| `UART.sft` | 43 | Signal Flow Trace file (post-fit timing intermediate) |
| `UART_modelsim.xrf` | 17 945 | Cross-reference file mapping simulation hierarchy → RTL names |

> The `.do` run-script is absent because the referenced testbench
> `tb_uart_loopback.v` is missing. See known issue #3 in the [parent README](../README.md).

---

## Build & program

```bash
# Compile
quartus_sh --flow compile uart_z

# Program the DE1-SoC / Cyclone V GX board over USB-Blaster
quartus_pgm -m jtag -o "p;uart_z/output_files/UART.sof"
```

### Simulation

```tcl
vlib work
vlog uart_rx.v uart_tx.v
vlog <your testbench>          # tb_uart_loopback.v is missing
vsim <your testbench>
run -all
```

---

## Cleanup checklist

Safe to delete without losing any source:

```
uart_z/UART.qws          # per-user GUI state
uart_z/c5_pin_model_dump.txt
uart_z/db/
uart_z/incremental_db/
uart_z/output_files/     # regenerates on compile — but contains UART.sof
```

Do **not** delete without a backup: `UART.qpf`, `UART.qsf`, `pins.qsf`, `timing.sdc`,
`uart_rx.v`, `uart_tx.v`, `uart_top_de1soc.v`.
