# UART

A parameterised, hand-written 115200-baud UART for Cyclone V FPGAs, wired as a
**loopback**: every byte received on `UART_RXD` is echoed back out `UART_TXD`, with
internal state exposed on the LEDs for hardware debugging.

Everything lives in the [`uart_z/`](uart_z/) sub-directory, which is the actual Quartus
project. See [`uart_z/README.md`](uart_z/README.md) for the file-by-file breakdown.

---

## Contents

| Path | What it is |
|------|-----------|
| [`uart_z/`](uart_z/) | The Quartus project (`UART.qpf` / `UART.qsf`). **[→ detailed README](uart_z/README.md)** |
| [`uart_z/uart_rx.v`](uart_z/uart_rx.v) | Asynchronous receiver, 4-state FSM with middle-of-bit sampling |
| [`uart_z/uart_rx.v.bak`](uart_z/uart_rx.v.bak) | Superseded 16× oversampling receiver (kept for reference — see below) |
| [`uart_z/uart_tx.v`](uart_z/uart_tx.v) | Transmitter, 10-bit shift register |
| [`uart_z/uart_top_de1soc.v`](uart_z/uart_top_de1soc.v) | Top level: instantiates both, loops RX → TX, drives LEDs |

**112 files, 12.68 MB total** — 10 hand-maintained files in the project root plus the
tool-generated `db/`, `incremental_db/`, `output_files/`, and `simulation/` trees.

---

## Specification

| Parameter | Value |
|-----------|-------|
| Clock | 50 MHz (`CLOCK_50`) |
| Baud rate | 115 200 (8-N-1) |
| `CLKS_PER_BIT` | `50_000_000 / 115_200` = **434** |
| `HALF_BIT` | **217** |
| Data bits | 8, LSB first |
| Parity | None |
| Stop bits | 1 |
| Reset | Asynchronous, active-low, from `KEY[0]` |

Bit period ≈ 8.68 µs. One byte ≈ 86.8 µs on the wire.

---

## Architecture

```
              ┌──────────────┐        ┌──────────────┐
  UART_RXD ──▶│              │        │              │──▶ UART_TXD
        (pin) │   uart_rx    │        │   uart_tx    │    (pin)
              │              │        │              │
              └──────┬───────┘        └───────▲──────┘
                     │  rx_data                 │  tx_data / tx_start
                     │  rx_done (1-cycle strobe)│
                     ▼                         │
              ┌─────────────────────────────────────┐
              │   latched_data  /  have_byte        │
              │   (single-entry buffer, top level)  │
              └─────────────────────────────────────┘
                     │
                     ▼
              LEDR[9:0]  ← latched_data[7:0], tx_busy, have_byte
```

`uart_top_de1soc` inserts a **single-byte buffer** between the two modules: on `rx_done`
the received byte is latched and `have_byte` is set; when `!tx_busy`, `have_byte` is
consumed and `tx_start` pulses. This decouples the RX frame rate from the TX frame rate
so a partially-completed transmit is never corrupted by a new arrival.

### Receiver FSM

| State | Enc. | Behaviour |
|-------|-----:|-----------|
| `IDLE` | `2'd0` | Waits for a low level on `rx_s`. Resets counters. |
| `START` | `2'd1` | Counts `HALF_BIT` clocks, then re-checks: still low → `DATA`, else false start → `IDLE`. |
| `DATA` | `2'd2` | Samples one bit every `CLKS_PER_BIT` clocks into `data_reg[bit_index]`, `bit_index` 0→7. |
| `STOP` | `2'd3` | Samples the middle of the stop bit; if high, latches `rx_data` and pulses `rx_done`. |

Because counting restarts from the *middle* of the start bit, every subsequent sample
lands in the middle of its own bit — no bit-by-bit re-alignment is needed.

### Transmitter

`tx` is driven directly from `shifter[bit_index]` with a free-running `clk_count`. The
frame is preloaded as `{1'b1, tx_data, 1'b0}` — stop bit, data (LSB at bit 0), start
bit — so the shift register walks out start → data[0..7] → stop with no special
casing. `tx_busy` is high for the whole 10-bit frame; `tx_done` pulses on completion.

### Input synchronisation

The asynchronous `rx` line passes through a **2-flop synchroniser** (`rx_s1`, `rx_s2`)
before being used, both reset to `1'b1` (idle-high). `wire rx_s = rx_s2;` is the only
signal the FSM ever samples.

---

## Pin assignment

Two different pin sets are present in this project. **The `UART.qsf` assignments are the
ones that get compiled.**

| Signal | `UART.qsf` (active) | `pins.qsf` (Cyclone V GX Starter Kit) | Note |
|--------|----------------------|--------------------------------------|------|
| `CLOCK_50` | PIN_R20 | PIN_R20 | 50 MHz oscillator |
| `KEY[0]` | PIN_P11 | PIN_P11 | Active-low reset |
| `KEY[1]` | PIN_P12 | PIN_R11 | Unused |
| `KEY[2]` | PIN_Y15 | PIN_T10 | Unused |
| `KEY[3]` | PIN_Y16 | PIN_T11 | Unused |
| `UART_RXD` | PIN_M9 | PIN_M9 (`UART_RX`) | `pins.qsf` uses the un-suffixed name |
| `UART_TXD` | PIN_L9 | PIN_L9 (`UART_TX`) | Same |
| `LEDR[0..9]` | PIN_F7, F6, G6, G7, J8, J7, K10, K8, H7, J10 | identical | Status/debug |

> **Naming mismatch to be aware of.** `pins.qsf` assigns `UART_RX` / `UART_TX`, while
> `uart_top_de1soc.v` declares ports named `UART_RXD` / `UART_TXD`. The top-level entity
> therefore matches the `UART.qsf` names, and the `pins.qsf` names remain unassigned
> (Quartus reports them as unmatched, harmlessly). `pins.qsf` also carries `IO_STANDARD`
> `3.3-V LVTTL` / `1.2 V` / `2.5 V` entries that differ from the `1.2 V` used in
> `UART.qsf` for the KEY pins.

**Device.** `UART.qsf` targets **`5CGXFC5C6F27C7`** (Cyclone V GX Starter Kit), not the
`5CSEMA5F31C6` used by the VGA project, despite the module name
`uart_top_de1soc`.

---

## Timing constraints

`timing.sdc` (34 lines):

| Constraint | Value | Rationale |
|------------|-------|-----------|
| `create_clock` | `-period 20` on `CLOCK_50` | 50 MHz |
| `derive_pll_clocks` / `derive_clock_uncertainty` | — | Standard boilerplate |
| `set_false_path` | `-from [get_ports {KEY[*]}] -to *` | The button reset is asynchronous by design; timing-analyse it as a false path |
| `set_input_delay` on `UART_RXD` | `-max 5`, `-min 0` | 115200 baud is slow; 5 ns is a generous budget |
| `set_output_delay` on `UART_TXD` | `-max 5`, `-min 0` | Matches the receive budget |
| `set_output_delay` on `LEDR[*]` | `-max 10`, `-min 0` | LEDs are relaxed debug outputs |

> `UART.qsf` references **both** `timings.sdc` and `timing.sdc`. Only `timing.sdc` is on
> disk; Quartus silently skips the missing one (it will emit a "file not found"
> warning during Analysis & Synthesis).

---

## Build & program

```bash
# 1. Open the project
quartus_sh --mode=project uart_z/UART.qpf      # or open the .qpf in the GUI

# 2. Compile
quartus_sh --flow compile uart_z               # produces uart_z/output_files/UART.sof

# 3. Program over USB-Blaster
quartus_pgm -m jtag -o "p;uart_z/output_files/UART.sof"
```

The `.qsf` EDA settings point at **ModelSim-Altera (Verilog)** with a `1 ps` timescale,
and the project also lists a `tb_uart_loopback.v` testbench — **this file is not present
in the repository.** Remove that `VERILOG_FILE` line from `UART.qsf` or add the
testbench back before running an EDA simulation.

---

## Verified results

Compilation completed successfully (`Mon Jul 20 12:21:50 2026`).

### Resource utilisation

| Metric | Used / Available | % |
|--------|------------------:|---:|
| Logic (ALMs) | 56 / 29 080 | < 1 % |
| Total registers | 112 | — |
| Total pins | 17 / 364 | 5 % |
| Block memory bits | 0 / 4 567 040 | 0 % |
| RAM blocks | 0 / 446 | 0 % |
| DSP blocks | 0 / 150 | 0 % |
| PLLs | 0 / 12 | 0 % |
| DLLs | 0 / 4 | 0 % |

Analysis & Synthesis reported 91 registers; the fitter reports 112 after optimisation
and register duplication.

### Timing closure — all four corner models clean

| Corner | Setup slack | Hold slack | Min pulse width |
|--------|------------:|-----------:|----------------:|
| Slow 1100 mV 85 °C | +1.442 ns | +0.234 ns | +9.093 ns |
| Slow 1100 mV 0 °C | +1.414 ns | +0.213 ns | +8.999 ns |
| Fast 1100 mV 85 °C | +5.446 ns | +0.127 ns | +9.412 ns |
| Fast 1100 mV 0 °C | +5.663 ns | +0.115 ns | +9.398 ns |

**Total negative slack is 0.000 in every corner.** The design closes timing cleanly at
115200 baud.

---

## Known issues

### 1. The current `uart_rx.v` is a *simplification* of the `.bak` version

`uart_rx.v.bak` implements **16× oversampling with majority voting**:

* `OVERSAMPLE = 16`, `SAMPLE_POINT = CLKS_PER_BIT / 16` = 27 clocks.
* A window `CENTER_OFFSET ± SAMPLE_POINT/2` around each bit's centre collects 16
  samples into `rx_samples[15:0]`.
* A population count adds all 16 bits; `rx_sample = (ones_count >= 8)`.
* It **re-synchronises the input** with a 2-flop chain (`rx_s1`/`rx_s2`).

`uart_rx.v` (the active file) dropped all of that for a single middle-of-bit sample.
This is a deliberate simplification, and it was made *because* of an issue recorded in
the `.bak` file's own comments:

> "This was the source of the huge combinational path (`bit_index` → multiplier → adders
> → comparators → `rx_samples`) that was failing setup timing by ~9 ns."

The fix that was tried in the `.bak` revision was to replace the
`bit_index * CLKS_PER_BIT` multiplier with a running `bit_start` adder
(`bit_start <= bit_start + CLKS_PER_BIT`). **If you re-enable oversampling, keep that
adder — do not reintroduce the multiply.**

### 2. `pins.qsf` port-name mismatch

See the pin-assignment table above. The `UART_RX` / `UART_TX` names in `pins.qsf` do not
match the `UART_RXD` / `UART_TXD` ports in the top-level entity, so those assignments
are inert. Fix by renaming the pins or the ports.

### 3. Missing testbench file

`UART.qsf` line 52 references `tb_uart_loopback.v`, which is not in the repository.
This produces a missing-file warning on compile; it does not block bitstream generation.

### 4. Duplicate SDC reference

`UART.qsf` lines 80–81 list `timings.sdc` *and* `timing.sdc`. Only `timing.sdc` exists.

---

## File-type reference

| File | What it is |
|------|-----------|
| `UART.qpf` | Quartus Project File. Revision name `UART`, Quartus 18.1. |
| `UART.qsf` | Settings File: device, top entity, file list, pin locations, EDA tool, SDC. |
| `UART.qws` | Per-user GUI workspace state. **Binary.** Not portable; safe to delete. |
| `pins.qsf` | Cyclone V GX Starter Kit reference pin assignments (see mismatch note above). |
| `timing.sdc` | TimeQuest SDC constraints. |
| `c5_pin_model_dump.txt` | Quartus I/O pin-model index dump. Format: `io_4iomodule_c5_index: <n>gpio_index: <m>` pairs mapping the device's `io_4iomodule` instances to global GPIO indices. Used internally by the pin planner. Generated. |
| `uart_rx.v.bak` | Previous revision of `uart_rx.v`. Not compiled. |
| `db/` (91 files) | Post-fit internal databases — placement, routing, timing graph, I/O buffers, per-corner timing analysis. Generated; safe to delete. |
| `incremental_db/` (21 files) | Incremental-compilation cache. Its own `README` explains that deleting both `db/` and `incremental_db/` forces a clean compile. |
| `output_files/` (14 files) | Human-readable compilation artifacts — the ones you actually read. |
| `simulation/modelsim/` | EDA simulation outputs. |
