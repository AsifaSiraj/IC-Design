// =====================================================================
// reset_sync.v
//
// Synchronizes an asynchronous reset source (board KEY press OR the
// PLL's "not locked" state) into a clean, synchronous active-high
// reset inside the destination clock domain. Asserts immediately,
// de-asserts only after two clean clock edges once the source clears.
// =====================================================================
module reset_sync (
    input  wire clk,          // destination clock domain (e.g. clk_pixel)
    input  wire async_rst_n,  // asynchronous, active-LOW (e.g. KEY[0] & pll_locked)
    output reg  reset          // synchronous, active-HIGH, safe to use as 'reset' elsewhere
);

    reg stage1;

    always @(posedge clk or negedge async_rst_n) begin
        if (!async_rst_n) begin
            stage1 <= 1'b1;
            reset  <= 1'b1;
        end else begin
            stage1 <= 1'b0;
            reset  <= stage1;
        end
    end

endmodule