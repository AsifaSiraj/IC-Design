// =====================================================================
// de1soc_vga720p_onchip_top.v
//
// Same PLL / reset_sync / vga_timing chain you already verified on
// hardware with the color-bar test pattern -- only the TEST PATTERN
// GENERATOR block is replaced with a read from image_rom (on-chip
// Block RAM), no HPS / DDR3 / Avalon-MM master involved at all.
//
// A small IMG_WIDTH x IMG_HEIGHT image is centered inside the full
// 1280x720 active display area; everywhere else is forced black.
// =====================================================================
module de1soc_vga720p_onchip_top (
    input  wire        CLOCK_50,
    input  wire [0:0]  KEY_N,        // KEY_N[0], active-LOW master reset

    output wire         VGA_HS,
    output wire         VGA_VS,
    output wire         VGA_BLANK_N,
    output wire         VGA_SYNC_N,
    output wire         VGA_CLK,
    output wire [7:0]   VGA_R,
    output wire [7:0]   VGA_G,
    output wire [7:0]   VGA_B
);

    localparam IMG_WIDTH  = 320;
    localparam IMG_HEIGHT = 240;
    localparam ADDR_WIDTH = 17;

    // centered placement inside the 1280x720 active window
    localparam OFF_X = (1280 - IMG_WIDTH)  / 2;   // 480
    localparam OFF_Y = (720  - IMG_HEIGHT) / 2;   // 240

    // ------------------------------------------------------------
    // 74.25 MHz pixel clock -- unchanged from your working Task 1 file.
    // ------------------------------------------------------------
    wire clk_pixel;
    wire pll_locked;

    pll_74p25 u_pll (
        .refclk   (CLOCK_50),
        .rst      (~KEY_N[0]),
        .outclk_0 (clk_pixel),
        .locked   (pll_locked)
    );

    wire async_rst_n = KEY_N[0] & pll_locked;
    wire reset;

    reset_sync u_reset_sync (
        .clk          (clk_pixel),
        .async_rst_n  (async_rst_n),
        .reset        (reset)
    );

    // ------------------------------------------------------------
    // Task 1: VESA 720p timing generator -- unchanged
    // ------------------------------------------------------------
    wire        hsync_i, vsync_i;
    wire        video_on;
    wire        blank_n;
    wire [10:0] pixel_x;
    wire [9:0]  pixel_y;

    vga_timing u_timing (
        .clk        (clk_pixel),
        .reset      (reset),
        .hsync      (hsync_i),
        .vsync      (vsync_i),
        .video_on   (video_on),
        .blank_n    (blank_n),
        .sync_n     (VGA_SYNC_N),
        .pixel_x    (pixel_x),
        .pixel_y    (pixel_y),
        .frame_tick ()
    );

    // ------------------------------------------------------------
    // Is the current pixel inside the small centered image box?
    // ------------------------------------------------------------
    wire in_image_now = video_on &&
                         (pixel_x >= OFF_X) && (pixel_x < OFF_X + IMG_WIDTH) &&
                         (pixel_y >= OFF_Y) && (pixel_y < OFF_Y + IMG_HEIGHT);

    wire [10:0] img_x = pixel_x - OFF_X;
    wire [9:0]  img_y = pixel_y - OFF_Y;

    wire [ADDR_WIDTH-1:0] rom_addr = img_y * IMG_WIDTH + img_x;

    wire [7:0] rom_data;

    image_rom #(
        .IMG_WIDTH  (IMG_WIDTH),
        .IMG_HEIGHT (IMG_HEIGHT),
        .ADDR_WIDTH (ADDR_WIDTH),
        .HEX_FILE   ("image.hex")
    ) u_rom (
        .clk  (clk_pixel),
        .addr (rom_addr),
        .data (rom_data)
    );

    // ------------------------------------------------------------
    // PIPELINE ALIGNMENT: image_rom has a 1-clock synchronous read
    // latency (address presented this cycle -> data valid next
    // cycle). Delay hsync/vsync/blank_n/in_image by exactly one
    // clock too, so everything lines back up together.
    // ------------------------------------------------------------
    reg hsync_d, vsync_d, blank_n_d, in_image_d;

    always @(posedge clk_pixel) begin
        hsync_d    <= hsync_i;
        vsync_d    <= vsync_i;
        blank_n_d  <= blank_n;
        in_image_d <= in_image_now;
    end

    assign VGA_HS      = hsync_d;
    assign VGA_VS      = vsync_d;
    assign VGA_BLANK_N = blank_n_d;
    assign VGA_CLK     = clk_pixel;

    // ------------------------------------------------------------
    // RGB332 (from ROM) -> 8-bit-per-channel DAC expansion
    // ------------------------------------------------------------
    wire [2:0] r3 = rom_data[7:5];
    wire [2:0] g3 = rom_data[4:2];
    wire [1:0] b2 = rom_data[1:0];

    wire [7:0] r8 = {r3, r3[2:0], r3[2]};
    wire [7:0] g8 = {g3, g3[2:0], g3[2]};
    wire [7:0] b8 = {b2, b2, b2, b2};

    // ELECTRICAL SAFETY REQUIREMENT + only show the ROM pixel while
    // inside the small centered image box; everything else is black.
    wire show_pixel = blank_n_d && in_image_d;
    assign VGA_R = show_pixel ? r8 : 8'h00;
    assign VGA_G = show_pixel ? g8 : 8'h00;
    assign VGA_B = show_pixel ? b8 : 8'h00;

endmodule
