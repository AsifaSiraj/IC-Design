transcript on
if ![file isdirectory vga_controller_iputf_libs] {
	file mkdir vga_controller_iputf_libs
}

if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

###### Libraries for IPUTF cores 
###### End libraries for IPUTF cores 
###### MIF file copy and HDL compilation commands for IPUTF cores 


vlog "C:/projects/MyFolders/USTP/RDV/vga_controller/pll_74p25_sim/pll_74p25.vo"

vlog  -work work +incdir+C:/projects/MyFolders/USTP/RDV/vga_controller {C:/projects/MyFolders/USTP/RDV/vga_controller/vga_timing.v}
vlog  -work work +incdir+C:/projects/MyFolders/USTP/RDV/vga_controller {C:/projects/MyFolders/USTP/RDV/vga_controller/de1soc_vga720p_top.v}
vlog  -work work +incdir+C:/projects/MyFolders/USTP/RDV/vga_controller {C:/projects/MyFolders/USTP/RDV/vga_controller/reset_sync.v}
vlog  -work work +incdir+C:/projects/MyFolders/USTP/RDV/vga_controller {C:/projects/MyFolders/USTP/RDV/vga_controller/video_fifo.v}
vlog  -work work +incdir+C:/projects/MyFolders/USTP/RDV/vga_controller {C:/projects/MyFolders/USTP/RDV/vga_controller/avalon_dma_master.v}
vlog  -work work +incdir+C:/projects/MyFolders/USTP/RDV/vga_controller {C:/projects/MyFolders/USTP/RDV/vga_controller/pixel_unpacker.v}

vlog  -work work +incdir+C:/projects/MyFolders/USTP/RDV/vga_controller {C:/projects/MyFolders/USTP/RDV/vga_controller/tb_avalon_dma_master.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cyclonev_ver -L cyclonev_hssi_ver -L cyclonev_pcie_hip_ver -L rtl_work -L work -voptargs="+acc"  tb_avalon_dma_master

add wave *
view structure
view signals
run -all
