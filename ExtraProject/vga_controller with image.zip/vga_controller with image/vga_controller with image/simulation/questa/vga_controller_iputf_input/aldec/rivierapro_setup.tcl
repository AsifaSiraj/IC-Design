

vlog -v2k5 "C:/projects/MyFolders/USTP/RDV/vga_controller/pll_74p25_sim/pll_74p25.vo"
