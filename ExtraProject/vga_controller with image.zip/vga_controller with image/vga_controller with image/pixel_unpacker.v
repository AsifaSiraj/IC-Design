// =====================================================================
// pixel_unpacker.v  (finalized for video_fifo.v: showahead=OFF,
// no almost-empty/usedw ports available)
// =====================================================================
module pixel_unpacker (
    input  wire        clk_pixel,
    input  wire        reset,
    input  wire        video_on,

    // Read side of video_fifo (pixel-clock domain)
    output reg          fifo_rreq,     // -> video_fifo.rdreq
    input  wire [31:0]  fifo_rdata,    // <- video_fifo.q
    input  wire         fifo_rempty,   // <- video_fifo.rdempty

    output reg [7:0] pixel_r,
    output reg [7:0] pixel_g,
    output reg [7:0] pixel_b
);

    reg [31:0] word_latch;
    reg [1:0]  byte_sel;      // which of the 4 packed pixels we're on
    reg        rdata_valid;   // tracks: was rdreq asserted last cycle?

    wire [7:0] cur_byte = word_latch[byte_sel*8 +: 8];

    // RGB332 decode: [7:5]=R, [4:2]=G, [1:0]=B
    wire [7:0] decoded_r = {cur_byte[7:5], 5'b00000};
    wire [7:0] decoded_g = {cur_byte[4:2], 5'b00000};
    wire [7:0] decoded_b = {cur_byte[1:0], 6'b000000};

    // ------------------------------------------------------------
    // Pop control: request a new word one cycle *before* byte_sel
    // wraps back to 0, so the fresh word is latched exactly when
    // byte_sel==0 needs it. This hides the 1-cycle FIFO latency
    // instead of stalling.
    // ------------------------------------------------------------
    wire need_word_next_cycle = video_on && (byte_sel == 2'd3);

    always @(posedge clk_pixel) begin
        if (reset) begin
            byte_sel    <= 2'd0;
            fifo_rreq   <= 1'b0;
            rdata_valid <= 1'b0;
            word_latch  <= 32'd0;
        end else begin
            // Issue the pop
            fifo_rreq <= need_word_next_cycle && !fifo_rempty;
            rdata_valid <= fifo_rreq; // q is valid exactly one cycle after rdreq

            if (rdata_valid)
                word_latch <= fifo_rdata;

            if (video_on)
                byte_sel <= byte_sel + 2'd1;
            else
                byte_sel <= 2'd0; // resync at start of each line/blank so we
                                   // don't drift mid-word across frames
        end
    end

    always @(posedge clk_pixel) begin
        pixel_r <= video_on ? decoded_r : 8'h00;
        pixel_g <= video_on ? decoded_g : 8'h00;
        pixel_b <= video_on ? decoded_b : 8'h00;
    end

endmodule