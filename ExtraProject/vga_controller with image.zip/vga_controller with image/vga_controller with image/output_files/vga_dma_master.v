// =====================================================================
// vga_dma_master.v
//
// Part I / Task 2 : Avalon-MM read master.
//
// Autonomously streams the 921,600-byte, 8bpp (RGB332) frame buffer out
// of DDR3 via the high-performance f2h_sdram_master bridge, with no
// CPU/HPS software involvement once started. Read words are pushed into
// an async_fifo so the pixel-clock domain can consume them independently
// of the bus clock domain.
//
// Behaviour matches the lab spec exactly:
//   - am_read is asserted only when the domain-crossing FIFO has space.
//   - If am_waitrequest is high, ALL address/control signals are held
//     stable until the stall clears (no address increment, no re-issue).
//   - Data is captured/pushed into the FIFO only on am_readdatavalid.
//   - The address pointer increments by 4 bytes per beat and wraps from
//     BASE_ADDR + 921596 back to BASE_ADDR.
// =====================================================================
module vga_dma_master #(
    parameter BASE_ADDR   = 32'h3800_0000,
    parameter FRAME_BYTES = 921600,                       // 1280 * 720 * 1 byte
    parameter LAST_ADDR   = BASE_ADDR + FRAME_BYTES - 4    // 0x38000000 + 921596
) (
    input  wire        clk,             // Avalon bus clock (f2h_sdram_master domain)
    input  wire        reset,           // synchronous, active-high

    // ---------------- Avalon-MM master (read-only) ----------------
    output reg  [31:0] am_address,
    output reg         am_read,
    input  wire        am_waitrequest,
    input  wire [31:0] am_readdata,
    input  wire        am_readdatavalid,

    // ---------------- push side of the domain-crossing FIFO ----------------
    output reg  [31:0] fifo_wr_data,
    output reg         fifo_wr_en,
    input  wire        fifo_full
);

    // ------------------------------------------------------------
    // FSM states
    // ------------------------------------------------------------
    localparam S_ISSUE_READ = 2'd0;  // present address, assert am_read, wait out waitrequest
    localparam S_WAIT_DATA  = 2'd1;  // request accepted, waiting for am_readdatavalid
    localparam S_PUSH       = 2'd2;  // push captured word into FIFO, then advance/wrap address

    reg [1:0]  state;
    reg [31:0] captured_data;

    always @(posedge clk) begin
        if (reset) begin
            state         <= S_ISSUE_READ;
            am_address    <= BASE_ADDR;
            am_read       <= 1'b0;
            fifo_wr_en    <= 1'b0;
            fifo_wr_data  <= 32'd0;
            captured_data <= 32'd0;
        end else begin

            // default: no FIFO write unless explicitly asserted this cycle
            fifo_wr_en <= 1'b0;

            case (state)

                // ---------------------------------------------------
                // Only issue a new read once there is room downstream.
                // Address/control lines are held steady for as long as
                // am_waitrequest stays high; the transfer is accepted
                // the cycle am_waitrequest drops while am_read is high.
                // ---------------------------------------------------
                S_ISSUE_READ: begin
                    if (!fifo_full) begin
                        am_read <= 1'b1;          // request stays asserted...
                        if (am_read && !am_waitrequest) begin
                            // transfer accepted this cycle
                            am_read <= 1'b0;
                            state   <= S_WAIT_DATA;
                        end
                        // else: am_waitrequest high (or first cycle asserting
                        // am_read) -> am_address/am_read held, do nothing else
                    end else begin
                        am_read <= 1'b0;          // no downstream space, don't request
                    end
                end

                // ---------------------------------------------------
                // Wait for the read data to come back. Only latch data
                // on the cycle am_readdatavalid pulses high.
                // ---------------------------------------------------
                S_WAIT_DATA: begin
                    if (am_readdatavalid) begin
                        captured_data <= am_readdata;
                        state         <= S_PUSH;
                    end
                end

                // ---------------------------------------------------
                // Push the captured word into the FIFO, advance the
                // read pointer by 4 bytes, wrapping back to BASE_ADDR
                // once the maximum index boundary is reached.
                // ---------------------------------------------------
                S_PUSH: begin
                    fifo_wr_data <= captured_data;
                    fifo_wr_en   <= 1'b1;

                    if (am_address >= LAST_ADDR)
                        am_address <= BASE_ADDR;
                    else
                        am_address <= am_address + 32'd4;

                    state <= S_ISSUE_READ;
                end

                default: state <= S_ISSUE_READ;

            endcase
        end
    end

endmodule