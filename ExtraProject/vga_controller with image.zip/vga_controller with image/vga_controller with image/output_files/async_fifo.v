// =====================================================================
// async_fifo.v
//
// Generic dual-clock (asynchronous) FIFO, Gray-coded pointers.
// Used as the "domain-crossing buffer queue" referenced in Task 2:
// the write side runs on the HPS fabric / f2h_sdram_master clock,
// the read side runs on the 74.25 MHz pixel clock.
//
// DATA_WIDTH = 32   : one Avalon read word holds four 8-bit (RGB332) pixels
// ADDR_WIDTH = 8     : 256-entry FIFO (adjust for desired prefetch depth)
// =====================================================================
module async_fifo #(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 8
) (
    // ---------------- write side (bus / DMA-master clock) ----------------
    input  wire                    wr_clk,
    input  wire                    wr_reset,
    input  wire                    wr_en,
    input  wire [DATA_WIDTH-1:0]   wr_data,
    output wire                    wr_full,

    // ---------------- read side (74.25 MHz pixel clock) ----------------
    input  wire                    rd_clk,
    input  wire                    rd_reset,
    input  wire                    rd_en,
    output reg  [DATA_WIDTH-1:0]   rd_data,
    output wire                    rd_empty
);

    localparam DEPTH = (1 << ADDR_WIDTH);

    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];

    // Binary write/read pointers (one extra MSB for full/empty disambiguation)
    reg [ADDR_WIDTH:0] wr_ptr_bin, rd_ptr_bin;

    // Gray-coded pointers actually crossed between domains
    reg [ADDR_WIDTH:0] wr_ptr_gray, rd_ptr_gray;

    // Synchronizer registers
    reg [ADDR_WIDTH:0] rd_ptr_gray_sync1, rd_ptr_gray_sync2; // read ptr synced into write domain
    reg [ADDR_WIDTH:0] wr_ptr_gray_sync1, wr_ptr_gray_sync2; // write ptr synced into read domain

    function [ADDR_WIDTH:0] bin2gray(input [ADDR_WIDTH:0] bin);
        bin2gray = bin ^ (bin >> 1);
    endfunction

    // ------------------------------------------------------------
    // Write domain
    // ------------------------------------------------------------
    wire do_write = wr_en && !wr_full;

    always @(posedge wr_clk) begin
        if (wr_reset) begin
            wr_ptr_bin  <= 0;
            wr_ptr_gray <= 0;
        end else if (do_write) begin
            mem[wr_ptr_bin[ADDR_WIDTH-1:0]] <= wr_data;
            wr_ptr_bin  <= wr_ptr_bin + 1'b1;
            wr_ptr_gray <= bin2gray(wr_ptr_bin + 1'b1);
        end
    end

    always @(posedge wr_clk) begin
        if (wr_reset) begin
            rd_ptr_gray_sync1 <= 0;
            rd_ptr_gray_sync2 <= 0;
        end else begin
            rd_ptr_gray_sync1 <= rd_ptr_gray;
            rd_ptr_gray_sync2 <= rd_ptr_gray_sync1;
        end
    end

    // Full when next write pointer (gray) equals read pointer with top two bits inverted
    assign wr_full = (wr_ptr_gray == {~rd_ptr_gray_sync2[ADDR_WIDTH:ADDR_WIDTH-1],
                                        rd_ptr_gray_sync2[ADDR_WIDTH-2:0]});

    // ------------------------------------------------------------
    // Read domain
    // ------------------------------------------------------------
    wire do_read = rd_en && !rd_empty;

    always @(posedge rd_clk) begin
        if (rd_reset) begin
            rd_ptr_bin  <= 0;
            rd_ptr_gray <= 0;
            rd_data     <= {DATA_WIDTH{1'b0}};
        end else if (do_read) begin
            rd_data     <= mem[rd_ptr_bin[ADDR_WIDTH-1:0]];
            rd_ptr_bin  <= rd_ptr_bin + 1'b1;
            rd_ptr_gray <= bin2gray(rd_ptr_bin + 1'b1);
        end
    end

    always @(posedge rd_clk) begin
        if (rd_reset) begin
            wr_ptr_gray_sync1 <= 0;
            wr_ptr_gray_sync2 <= 0;
        end else begin
            wr_ptr_gray_sync1 <= wr_ptr_gray;
            wr_ptr_gray_sync2 <= wr_ptr_gray_sync1;
        end
    end

    assign rd_empty = (rd_ptr_gray == wr_ptr_gray_sync2);

endmodule