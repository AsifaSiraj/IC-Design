// =====================================================================
// tb_avalon_dma_master.v
//
// Testbench for avalon_dma_master.v. Run with:
//   vlib work
//   vlog avalon_dma_master.v tb_avalon_dma_master.v
//   vsim tb_avalon_dma_master
//   run -all
//
// What it checks:
//   1. am_address increments by exactly 4 ONLY on cycles where a
//      request is actually accepted (am_read high AND waitrequest low).
//   2. am_read drops / behaves correctly around waitrequest stalls.
//   3. address wraps back to BASE_ADDR at the end of the buffer.
//   4. outstanding-request counter never lets more than
//      MAX_OUTSTANDING reads be in flight (the flow-control this
//      module exists to enforce).
// =====================================================================
`timescale 1ns / 1ps

module tb_avalon_dma_master;

    localparam [31:0] BASE_ADDR       = 32'h3800_0000;
    localparam        WORD_COUNT      = 8;     // small on purpose: wraps fast
    localparam        MAX_OUTSTANDING = 4;

    reg         clk;
    reg         reset;

    reg  [31:0] am_readdata;
    reg         am_readdatavalid;
    reg         am_waitrequest;

    wire [31:0] am_address;
    wire        am_read;

    wire [31:0] fifo_wdata;
    wire        fifo_wreq;
    reg         fifo_wrfull;

    integer     errors;
    integer     accepted_count;

    reg [31:0]  prev_address;
    reg         prev_read;
    reg         prev_waitreq;
    integer     outstanding_model;

    // ------------------------------------------------------------
    // accept_q: registered copy of `accept`, delayed by one cycle.
    // This is the fix — `accept` describes THIS cycle's handshake,
    // but the address/outstanding registers only reflect that
    // handshake starting NEXT cycle (it's all posedge-clocked).
    // Comparing "did address change" against the *current* accept
    // is a one-cycle race; comparing against accept_q (last cycle's
    // accept) is the correct causal check.
    // ------------------------------------------------------------
    reg accept_q;

    // ------------------------------------------------------------
    // DUT
    // ------------------------------------------------------------
    avalon_dma_master #(
        .BASE_ADDR       (BASE_ADDR),
        .WORD_COUNT      (WORD_COUNT),
        .MAX_OUTSTANDING (MAX_OUTSTANDING)
    ) dut (
        .clk               (clk),
        .reset             (reset),
        .am_address        (am_address),
        .am_read           (am_read),
        .am_waitrequest    (am_waitrequest),
        .am_readdata       (am_readdata),
        .am_readdatavalid  (am_readdatavalid),
        .fifo_wdata        (fifo_wdata),
        .fifo_wreq         (fifo_wreq),
        .fifo_wrfull       (fifo_wrfull)
    );

    // ------------------------------------------------------------
    // Clock: 100 MHz (10 ns period)
    // ------------------------------------------------------------
    initial clk = 0;
    always #5 clk = ~clk;

    always @(posedge clk) begin
        am_readdata <= am_address;
    end

    // ------------------------------------------------------------
    // waitrequest generator: random stall pattern
    // ------------------------------------------------------------
    initial am_waitrequest = 1'b0;
    always @(posedge clk) begin
        if (reset)
            am_waitrequest <= 1'b0;
        else
            am_waitrequest <= ($random % 3 == 0); // stall ~1/3 of cycles
    end

    // ------------------------------------------------------------
    // readdatavalid generator: fixed 3-cycle read latency model
    // ------------------------------------------------------------
    reg accept_d1, accept_d2, accept_d3;
    wire accept = am_read & ~am_waitrequest;

    always @(posedge clk) begin
        if (reset) begin
            accept_d1 <= 0; accept_d2 <= 0; accept_d3 <= 0;
            am_readdatavalid <= 0;
        end else begin
            accept_d1 <= accept;
            accept_d2 <= accept_d1;
            accept_d3 <= accept_d2;
            am_readdatavalid <= accept_d3;
        end
    end

    initial fifo_wrfull = 1'b0;

    // ------------------------------------------------------------
    // Checkers
    // ------------------------------------------------------------
    initial begin
        errors = 0;
        accepted_count = 0;
        outstanding_model = 0;
        accept_q = 0;
    end

    always @(posedge clk) begin
        if (!reset) begin

            // ---- Check 1: count accepts ----
            if (accept)
                accepted_count = accepted_count + 1;

            // ---- Check 2: no address movement without a PRIOR accept ----
            if (!accept_q && (am_address !== prev_address)) begin
                errors = errors + 1;
                $display("[%0t] ERROR: address changed (%h -> %h) without an accepted request",
                          $time, prev_address, am_address);
            end

            // ---- Check 3: wrap behavior (based on the accept that caused this change) ----
            if (accept_q && prev_address == (BASE_ADDR + (WORD_COUNT*4) - 4) &&
                am_address !== BASE_ADDR) begin
                errors = errors + 1;
                $display("[%0t] ERROR: expected wrap to BASE_ADDR, got %h", $time, am_address);
            end

            // ---- Check 4: outstanding counter never exceeds MAX_OUTSTANDING ----
            if (accept && !am_readdatavalid)
                outstanding_model = outstanding_model + 1;
            else if (!accept && am_readdatavalid)
                outstanding_model = outstanding_model - 1;

            if (outstanding_model > MAX_OUTSTANDING) begin
                errors = errors + 1;
                $display("[%0t] ERROR: outstanding=%0d exceeds MAX_OUTSTANDING=%0d",
                          $time, outstanding_model, MAX_OUTSTANDING);
            end

            // ---- roll state forward for next cycle's comparisons ----
            prev_address <= am_address;
            prev_read    <= am_read;
            prev_waitreq <= am_waitrequest;
            accept_q     <= accept;
        end
    end

    // ------------------------------------------------------------
    // Stimulus
    // ------------------------------------------------------------
    initial begin
        reset = 1;
        am_readdata = 32'd0;
        repeat (5) @(posedge clk);
        reset = 0;

        repeat (500) @(posedge clk);

        if (errors == 0)
            $display("\n=== TESTBENCH PASSED: %0d requests accepted, 0 errors ===\n", accepted_count);
        else
            $display("\n=== TESTBENCH FAILED: %0d errors found (see log above) ===\n", errors);

        $finish;
    end

    initial begin
        $dumpfile("tb_avalon_dma_master.vcd");
        $dumpvars(0, tb_avalon_dma_master);
    end

endmodule