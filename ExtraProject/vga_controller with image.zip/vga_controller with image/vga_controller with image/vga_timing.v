// =====================================================================
// vga_timing.v
//
// Part I / Task 1 : VESA 1280x720 @ 60 Hz video timing generator.
// Runs entirely on a 74.25 MHz pixel clock supplied by an external PLL.
//
// CRITICAL: 720p uses POSITIVE (active-high) HSYNC/VSYNC polarity,
// unlike 480p which is active-low. hsync/vsync are asserted HIGH
// during their respective sync-pulse windows.
// =====================================================================
module vga_timing (
    input  wire        clk,          // 74.25 MHz pixel clock (from PLL)
    input  wire        reset,        // synchronous, active-high

    output wire        hsync,        // active-HIGH horizontal sync
    output wire        vsync,        // active-HIGH vertical sync
    output wire        video_on,     // high during the visible 1280x720 window
    output wire        blank_n,      // DE1-SoC VGA_BLANK_N (active-high = "not blanked")
    output wire        sync_n,       // DE1-SoC VGA_SYNC_N (composite sync, unused at 720p -> tied low)

    output wire [10:0] pixel_x,      // 0 .. 1279, valid while video_on is high
    output wire [9:0]  pixel_y,      // 0 .. 719,  valid while video_on is high

    output wire        frame_tick    // single-cycle pulse at the start of each new frame
);

    // ------------------------------------------------------------
    // Horizontal timing (pixel clocks) - from the lab spec table
    // ------------------------------------------------------------
    localparam integer H_ACTIVE      = 1280;
    localparam integer H_FRONT_PORCH = 110;
    localparam integer H_SYNC        = 40;
    localparam integer H_BACK_PORCH  = 220;
    localparam integer H_TOTAL       = H_ACTIVE + H_FRONT_PORCH + H_SYNC + H_BACK_PORCH; // 1650

    localparam integer H_SYNC_START  = H_ACTIVE + H_FRONT_PORCH;   // 1390
    localparam integer H_SYNC_END    = H_SYNC_START + H_SYNC;      // 1430

    // ------------------------------------------------------------
    // Vertical timing (lines) - from the lab spec table
    // ------------------------------------------------------------
    localparam integer V_ACTIVE      = 720;
    localparam integer V_FRONT_PORCH = 5;
    localparam integer V_SYNC        = 5;
    localparam integer V_BACK_PORCH  = 20;
    localparam integer V_TOTAL       = V_ACTIVE + V_FRONT_PORCH + V_SYNC + V_BACK_PORCH; // 750

    localparam integer V_SYNC_START  = V_ACTIVE + V_FRONT_PORCH;   // 725
    localparam integer V_SYNC_END    = V_SYNC_START + V_SYNC;      // 730

    reg [10:0] h_count; // 0 .. 1649
    reg [9:0]  v_count; // 0 .. 749

    wire h_last = (h_count == H_TOTAL - 1);
    wire v_last = (v_count == V_TOTAL - 1);

    // ------------------------------------------------------------
    // Horizontal counter
    // ------------------------------------------------------------
    always @(posedge clk) begin
        if (reset)
            h_count <= 11'd0;
        else if (h_last)
            h_count <= 11'd0;
        else
            h_count <= h_count + 11'd1;
    end

    // ------------------------------------------------------------
    // Vertical counter - advances once per completed horizontal line
    // ------------------------------------------------------------
    always @(posedge clk) begin
        if (reset)
            v_count <= 10'd0;
        else if (h_last) begin
            if (v_last)
                v_count <= 10'd0;
            else
                v_count <= v_count + 10'd1;
        end
    end

    // ------------------------------------------------------------
    // Sync pulses - POSITIVE polarity required by the 720p spec
    // ------------------------------------------------------------
    assign hsync = (h_count >= H_SYNC_START) && (h_count < H_SYNC_END);
    assign vsync = (v_count >= V_SYNC_START) && (v_count < V_SYNC_END);

    // ------------------------------------------------------------
    // Active video window / blanking
    // ------------------------------------------------------------
    assign video_on = (h_count < H_ACTIVE) && (v_count < V_ACTIVE);
    assign blank_n  = video_on;   // DAC pipeline is forced to 0 elsewhere whenever this is low
    assign sync_n   = 1'b0;       // composite sync not used at 720p

    assign pixel_x  = video_on ? h_count : 11'd0;
    assign pixel_y  = video_on ? v_count[9:0] : 10'd0;

    // Pulses once per frame, right at the top-left active pixel -
    // handy for the DMA master to know when a frame-buffer restart
    // (re-wrap to base address) should occur if needed.
    assign frame_tick = (h_count == 0) && (v_count == 0);

endmodule