// =====================================================================
// avalon_dma_master.v  (revised for video_fifo.v as generated —
// plain wrfull, no almost_full / usedw available)
// =====================================================================
module avalon_dma_master #(
    parameter [31:0] BASE_ADDR       = 32'h3800_0000,
    parameter        WORD_COUNT      = 230400,   // 921600 bytes / 4
    parameter        MAX_OUTSTANDING = 16         // safe margin < 512-deep FIFO;
                                                    // must be >= worst-case f2h_sdram_master
                                                    // read latency in words, verify in sim
) (
    input  wire        clk,             // Avalon bus clock (= wrclk on video_fifo)
    input  wire        reset,           // synchronous, active-high

    // Avalon-MM Master interface (export to f2h_sdram_master in QSYS)
    output reg  [31:0] am_address,
    output reg         am_read,
    input  wire         am_waitrequest,
    input  wire [31:0]  am_readdata,
    input  wire         am_readdatavalid,

    // Write side of video_fifo (bus-clock domain)
    output wire [31:0] fifo_wdata,   // -> video_fifo.data
    output wire        fifo_wreq,    // -> video_fifo.wrreq
    input  wire        fifo_wrfull   // <- video_fifo.wrfull  (plain full, not almost-full)
);

    localparam [31:0] END_ADDR = BASE_ADDR + (WORD_COUNT * 4);

    wire accept = am_read & ~am_waitrequest;

    // ------------------------------------------------------------
    // Outstanding-request counter: counts reads that have been
    // accepted by the bus but whose data hasn't come back yet.
    // This is the actual flow-control mechanism now — wrfull is
    // only a backstop, not the primary gate.
    // ------------------------------------------------------------
    reg [5:0] outstanding; // wide enough for MAX_OUTSTANDING=16, adjust if you raise it

    wire can_issue = (outstanding < MAX_OUTSTANDING) && ~fifo_wrfull;

    always @(posedge clk) begin
        if (reset) begin
            am_address  <= BASE_ADDR;
            am_read     <= 1'b0;
            outstanding <= 6'd0;
        end else begin
            am_read <= can_issue;

            if (accept) begin
                if (am_address == END_ADDR - 32'd4)
                    am_address <= BASE_ADDR;
                else
                    am_address <= am_address + 32'd4;
            end

            // Increment on issue, decrement on return; handle the
            // simultaneous case explicitly so the count stays exact.
            case ({accept, am_readdatavalid})
                2'b10:   outstanding <= outstanding + 6'd1;
                2'b01:   outstanding <= outstanding - 6'd1;
                default: outstanding <= outstanding; // 00 or 11: no net change
            endcase
        end
    end

    assign fifo_wdata = am_readdata;
    assign fifo_wreq  = am_readdatavalid;

endmodule