// =====================================================================
// image_rom.v -- FPGA on-chip Block RAM (M10K) used as a ROM, holding
// one small image, loaded at SYNTHESIS TIME from a plain hex text file
// (one byte per line, in hex) via $readmemh.
//
// IMPORTANT: depth/width are HARDCODED (not derived from parameters).
// Quartus's RAM-inference pattern matcher sometimes fails to recognize
// a parameter-computed array bound (e.g. IMG_WIDTH*IMG_HEIGHT) as
// block RAM, and falls back to building the memory out of registers
// plus a huge combinational address decoder -- which can blow up to
// several GB of RAM in quartus_map and crash the compile. Hardcoding
// the literal depth avoids that failure mode entirely.
//
// Image format: 320 x 240, 1 byte/pixel, RGB332
//     bits [7:5]=Red  [4:2]=Green  [1:0]=Blue
// Depth = 320*240 = 76800 words, addr width = 17 bits (covers 0..131071)
// =====================================================================
module image_rom (
    input  wire         clk,
    input  wire [16:0]  addr,     // 0 .. 76799 valid, upper range unused
    output reg  [7:0]   data
);

    reg [7:0] mem [0:76799];

    initial begin
        $readmemh("image.hex", mem);
    end

    // synchronous (registered) read -> Quartus infers this as M10K
    // block RAM instead of logic-based ROM
    always @(posedge clk) begin
        data <= mem[addr];
    end

endmodule