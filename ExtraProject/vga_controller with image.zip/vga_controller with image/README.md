# VGA Controller with Image

A complete, hardware-verified Quartus Prime project that drives the DE1-SoC VGA output at
**VESA 1280×720 @ 60 Hz** from a pixel clock of **74.25 MHz**, sourced from either of two
pixel sources:

1. **On-chip Block RAM** — a 320×240 RGB332 image centred on a black 720p field
   (`image_rom.v` + `image.hex`), no CPU or DDR3 involvement at all.
2. **DDR3 via Avalon-MM DMA** — an autonomous read master streams a 921 600-byte frame
   buffer out of HPS DDR3 through a dual-clock FIFO (`avalon_dma_master.v` +
   `video_fifo.v`).

The Quartus project itself is in the nested
[`vga_controller with image/`](vga_controller%20with%20image/) directory. See
[`vga_controller with image/README.md`](vga_controller%20with%20image/README.md) for the
file-by-file breakdown.

---

## Contents

| Path | What it is |
|------|-----------|
| [`vga_controller with image/`](vga_controller%20with%20image/) | The Quartus project (`vga_controller.qpf` / `.qsf`). **[→ detailed README](vga_controller%20with%20image/README.md)** |
| `…/image.hex` | 76 800 hex bytes — the 320×240 RGB332 image loaded into Block RAM |
| `…/de1soc_vga720p_onchip_top.v` | **Top level** — the design that actually compiles and runs |
| `…/vga_timing.v` | 720p VESA timing generator (active-HIGH sync) |
| `…/image_rom.v` | On-chip M10K ROM with `$readmemh` initialisation |
| `…/reset_sync.v` | Asynchronous→synchronous reset converter |
| `…/avalon_dma_master.v` | Avalon-MM read master with outstanding-request flow control |
| `…/video_fifo.v` | Generated `dcfifo` megafunction (512 × 32 bit, dual-clock) |
| `…/pll_74p25.v` | Generated PLL IP: 50 MHz → 74.25 MHz |
| `…/pixel_unpacker.v` | FIFO read side + RGB332 decode |
| `…/tb_avalon_dma_master.v` | Self-checking DMA testbench |
| `…/de1soc_vga720p_top.v` | Earlier top-level variant (**not compiled**) — parameterised `image_rom` call |
| `…/de1soc_vga720p_onchip_top.txt` | Text copy of the earlier 141-line top-level module |
| `…/pin_assignment_DE1_SoC.tcl` | Terasic board pin script (rev 1.7) |

**236 files, 22.22 MB total** (235 files in the Quartus project directory itself, plus this
README).

---

## Specification

| Parameter | Value |
|-----------|-------|
| Device | `5CSEMA5F31C6` — Cyclone V SoC, FBGA-896, speed grade 6 |
| Input clock | 50 MHz (`CLOCK_50`, PIN_AF14) |
| Pixel clock | **74.25 MHz**, from `pll_74p25` Integer-N PLL |
| Resolution | **1280 × 720** @ **60 Hz** |
| Horizontal total | **1650** px = 1280 active + 110 FP + 40 sync + 220 BP |
| Vertical total | **750** lines = 720 active + 5 FP + 5 sync + 20 BP |
| Sync polarity | **Active-HIGH** (720p requirement, opposite of 480p) |
| Colour format | **RGB332** — `R[7:5]` / `G[4:2]` / `B[1:0]`, expanded to 8/8/8 |
| Frame buffer | **921 600 bytes** (`0xE1000`) at **`0x38000000`** |
| Quartus | 25.1std.0 Build 1129, SC Lite Edition |
| Simulator | Questa Altera FPGA (RTL mode) |

**Timing sanity check:** 1650 × 750 × 60 Hz = 74.25 MHz exactly. ✔

---

## Architecture

### Path A — on-chip image (the compiled top level)

```
 CLOCK_50 ─▶ pll_74p25 ─▶ clk_pixel 74.25 MHz ─┬─▶ vga_timing ─▶ HS/VS/BLANK_N/pixel_x/y
             (locked)                          │
 KEY_N[0] ─┬─────────────────────────────────▶┴─▶ reset_sync ─▶ reset (sync, active-HIGH)
           │                                      │
           └───────────── async_rst_n ────────────┘
                                                  │
                            pixel_x/y ─▶ centred-box compare (in_image_now)
                                                  │
                                     img_y*320 + img_x ─▶ rom_addr
                                                  │
                                    image_rom (M10K, image.hex) ─▶ rom_data
                                                  │
                    ┌─────────────────────────────┘
                    ▼
        1-clock pipeline alignment delay
        (hsync_d, vsync_d, blank_n_d, in_image_d)
                    │
                    ▼
        RGB332 ─▶ {r3,r3,r3[2:1]} ─▶ VGA_R[7:0]   (gated to 0x00 unless show_pixel)
                                    ─▶ VGA_G[7:0]
                                    ─▶ VGA_B[7:0]
```

Image placement: `OFF_X = (1280-320)/2 = 480`, `OFF_Y = (720-240)/2 = 240`. Everything
outside the box is forced to black.

### Path B — DDR3 DMA (modules present, top level not wired)

```
 DDR3 0x38000000 ─▶ f2h_sdram_master ─┬─▶ am_address/am_read ──▶ Avalon-MM read master
                                       └─▶ am_readdata/am_readdatavalid
                                                    │
                                                    ▼
                                          video_fifo (dcfifo, 512×32)
                                          wrclk = Avalon clock
                                          rdclk = 74.25 MHz pixel clock
                                                    │
                                                    ▼
                                          pixel_unpacker ─▶ RGB888
```

---

## Design decisions worth knowing

### Active-HIGH sync is mandatory

Both `vga_timing.v` and the documentation-site reference call this out explicitly. 480p
is active-low; 720p is active-high. Getting this backwards produces a monitor that shows
a rolling or inverted image.

### Synchronous read latency must be compensated

`image_rom` has one clock of read latency. The top level therefore delays
`hsync`, `vsync`, `blank_n` and `in_image` by exactly one clock in a parallel register
bank. Without this, the image is shifted one pixel relative to the sync pulses and
tears at the box edges.

### The ROM array bound must be a literal

`image_rom.v` hardcodes `reg [7:0] mem [0:76799];` rather than deriving the bound from
parameters. Its comment records exactly why — see *Known issues* below.

### `wrfull` is a backstop, not the gate

`avalon_dma_master` gates on a 6-bit `outstanding` counter (`MAX_OUTSTANDING = 16`)
rather than on `fifo_wrfull`. `fifo_wrfull` is checked too, but the counter is the
primary flow-control mechanism because it prevents over-running the FIFO when the
Avalon read latency is bursty. The counter handles the simultaneous accept-and-return
case explicitly via `case ({accept, am_readdatavalid})`.

---

## Verified results

Full compile succeeded: **Fri Jul 17 10:59:25 2026**, Quartus Prime 25.1std.0.

### Resource utilisation (`vga_controller.fit.summary`)

| Metric | Used / Available | % |
|--------|------------------:|---:|
| Logic (ALMs) | 75 / 32 070 | < 1 % |
| Total registers | 36 | — |
| Total pins | 31 / 457 | 7 % |
| Block memory bits | 614 400 / 4 065 280 | 15 % |
| RAM blocks | 76 / 397 | 19 % |
| DSP blocks | 0 / 87 | 0 % |
| PLLs | 1 / 6 | 17 % |
| DLLs | 0 / 4 | 0 % |

### Timing closure — all corners clean

Every one of the 18 reported checks has **positive slack and TNS = 0.000**.

| Corner | Worst setup | Worst hold | Min pulse width (PLL) |
|--------|------------:|-----------:|----------------------:|
| Slow 1100 mV 85 °C | +3.820 ns | +0.389 ns | +0.612 ns |
| Slow 1100 mV 0 °C | +3.779 ns | +0.388 ns | +0.612 ns |
| Fast 1100 mV 85 °C | +7.917 ns | +0.206 ns | +0.612 ns |
| Fast 1100 mV 0 °C | +8.391 ns | +0.193 ns | +0.612 ns |

The critical path is the PLL output divider clock
(`u_pll|pll_74p25_inst|altera_pll_i|…|divclk`), not the pixel datapath.

---

## Known issues

### 1. `quartus_map.exe` out-of-memory crash — and the fix already applied

`serv_req_info.txt` records a real crash on Fri Jul 17 10:45:49 2026:

```
*** Fatal Error: Out of memory in module quartus_map.exe (5168 megabytes used)
  sub_system: MEM
```

`image_rom.v`'s header comment is the post-mortem:

> "Quartus's RAM-inference pattern matcher sometimes fails to recognize a
> parameter-computed array bound (e.g. `IMG_WIDTH*IMG_HEIGHT`) as block RAM, and falls
> back to building the memory out of registers plus a huge combinational address decoder
> — which can blow up to several GB of RAM in `quartus_map` and crash the compile.
> Hardcoding the literal depth avoids that failure mode entirely."

**Keep the literal `mem [0:76799]`.** Do not parameterise it.

### 2. Four JVM crash logs (`hs_err_pid*.log`) + replay logs

`hs_err_pid11192.log`, `hs_err_pid6932.log`, `hs_err_pid8544.log`, `hs_err_pid12588.log`
each report:

```
There is insufficient memory for the Java Runtime Environment to continue.
Native memory allocation (malloc) failed to allocate 248336 bytes for Chunk::new
```

Each has a matching `replay_pid*.log` HotSpot replay-compilation log. These are JVM
diagnostics from the Quartus GUI hitting the machine's RAM ceiling during large
analyses. **Safe to delete.**

### 3. NativeLink simulation fails on a file lock

`vga_controller_nativelink_simulation.rpt`:

```
Warning: File vga_controller_run_msim_rtl_verilog.do already exists -
         backing up current file as vga_controller_run_msim_rtl_verilog.do.bak7
error deleting "msim_transcript": permission denied
Error: NativeLink simulation flow was NOT successful
```

`POSIX EACCES {permission denied}` — Questa still holds `msim_transcript` open from a
previous run. The eleven `.do.bak1` … `.do.bak11` files are the accumulated backups from
repeated failed NativeLink attempts (`.bak8` and `.bak9` are zero-length).

**Fix:** close every running ModelSim/Questa GUI and console, then delete
`simulation/questa/msim_transcript`, `simulation/questa/vsim.wlf` and
`simulation/questa/rtl_work/`. The `.do` script and its backups can all be deleted too
— NativeLink regenerates them.

### 4. `de1soc_vga720p_top.v` and the DDR3 path are not compiled

`vga_controller.qsf` lists only:

```
VERILOG_FILE vga_timing.v
VERILOG_FILE reset_sync.v
QIP_FILE     pll_74p25.qip
SIP_FILE     pll_74p25.sip
QIP_FILE     video_fifo.qip
VERILOG_FILE de1soc_vga720p_onchip_top.v
VERILOG_FILE image_rom.v
HEX_FILE     image.hex
```

`avalon_dma_master.v`, `pixel_unpacker.v`, `de1soc_vga720p_top.v`, and
`tb_avalon_dma_master.v` are **not** in the compile list. The DDR3 pipeline is
therefore present-but-inactive in hardware; the running design is purely on-chip ROM.
The testbench is separately wired for EDA simulation
(`EDA_TEST_BENCH_NAME tb_avalon_dma_master`), so simulation still works.

`video_fifo.v` is listed via `QIP_FILE` but nothing instantiates it in the compiled top
level, so it is optimised away — hence 76 RAM blocks (all ROM) rather than 77.

### 5. `de1soc_vga720p_top.v` is an orphaned near-duplicate

All three of `de1soc_vga720p_top.v`, `de1soc_vga720p_top.v.bak` (from a different era —
that one really does declare `module de1soc_vga720p_top`) and
`de1soc_vga720p_onchip_top.v.bak` / `de1soc_vga720p_onchip_top.txt` are the *earlier*,
**parameterised** 141-line version of the top level. The compiled
`de1soc_vga720p_onchip_top.v` is the 136-line version that matches the hardcoded
`image_rom.v`.

The single functional difference is how the ROM is instantiated:

| File | Instantiation | Lines |
|------|---------------|------:|
| `de1soc_vga720p_onchip_top.v` **(compiled)** | `image_rom u_rom (.clk, .addr, .data)` | 136 |
| `de1soc_vga720p_top.v` | `image_rom #(.IMG_WIDTH, .IMG_HEIGHT, .ADDR_WIDTH, .HEX_FILE) u_rom (...)` | 141 |

`de1soc_vga720p_top.v` still declares `module de1soc_vga720p_onchip_top`, so adding it to
the file list alongside the real top level would be a duplicate-module error. It is not
in the QSF, so this is dormant — but it will bite anyone who does a "compile everything"
sweep. The old files are also the ones that reference a *parameterised* `image_rom`, which
no longer exists.

### 6. `image_rom.v` is parameterless by design — this is intentional, not a bug

The compiled top level calls it positionally/port-only:

```verilog
image_rom u_rom (
    .clk  (clk_pixel),
    .addr (rom_addr),
    .data (rom_data)
);
```

`image_rom.v` and `image_rom.v.bak` both declare **no parameters** — only ports `clk`,
`addr[16:0]`, `data[7:0]`, and the literal `reg [7:0] mem [0:76799];`. The header comment
explains this was a deliberate fix for the `quartus_map` OOM (see issue 1). The
`IMG_WIDTH` / `IMG_HEIGHT` / `HEX_FILE` locals that remain in the top level are therefore
used only to compute `rom_addr`; the file name is fixed inside `image_rom.v`'s
`$readmemh` call.

### 7. Vestigial camera / video-in pins

`vga_controller.qsf` carries the full DE1-SoC board assignment including the video-in
decoder (`TD_CLK27`, `TD_DATA[7:0]`, `TD_HS`, `TD_VS`, `TD_RESET_N`). The design does
not use them; they come from the wholesale board script.

### 8. `pll_74p25.v` was generated for the wrong device

The PLL IP header records `device = "5CEBA2F17A7"` while the project targets
`5CSEMA5F31C6`. Both are Cyclone V and the generated divider ratios are correct for
74.25 MHz from 50 MHz, so it compiles and clocks correctly — but for a clean regeneration
you should re-create the PLL against the actual device.

---

## Build & program

```bash
# Compile
quartus_sh --flow compile "vga_controller with image/vga_controller with image"

# Program the DE1-SoC over USB-Blaster
quartus_pgm -m jtag -o "p;vga_controller with image/vga_controller with image/output_files/vga_controller.sof"
```

Bitstream is `output_files/vga_controller.sof` (6.69 MB).

---

## Simulation (no hardware needed)

The Avalon-MM DMA testbench is fully self-checking and runs standalone:

```tcl
vlib work
vlog avalon_dma_master.v tb_avalon_dma_master.v
vsim tb_avalon_dma_master
run -all
```

**Expected output on success:**

```
=== TESTBENCH PASSED: 314 requests accepted, 0 errors ===
```

Waveforms are written to `tb_avalon_dma_master.vcd` — open in GTKWave.

### What the testbench verifies

| # | Check |
|---|--------|
| 1 | A software shadow counter models the outstanding-request count and must never exceed `MAX_OUTSTANDING`. |
| 2 | `am_address` never changes without a **prior** accepted request — compared against a registered `accept_q`, not the current-cycle handshake. |
| 3 | Address wraps back to `BASE_ADDR` after `WORD_COUNT * 4` bytes. |

Plus a random `waitrequest` generator stalling ~1/3 of cycles and a fixed 3-cycle
`readdatavalid` latency model, with `am_readdata` echoing `am_address` so data content is
trivially checkable.

> The `accept_q` fix is documented in the testbench itself — comparing "did the address
> change?" against the *current* handshake is a one-cycle race, because the address
> register only reflects that handshake starting on the next posedge.
> `tb_avalon_dma_master.v.bak` is the pre-fix version.

---

## Regenerating `image.hex`

`image.hex` is a plain text file, one hex byte per line, row-major, RGB332. The shipped
version is 76 800 lines, i.e. exactly 320 × 240 bytes. The first values are `ff` (white),
which is why the image appears as a white rectangle.

To replace it with your own 320×240 image:

```python
# 320x240 RGB332 hex generator
W, H = 320, 240
with open("image.hex", "w") as f:
    for y in range(H):
        for x in range(W):
            r = clamp(x * 7 // (W - 1))
            g = clamp(y * 7 // (H - 1))
            b = clamp((x ^ y) & 0x3)
            f.write(f"{(r << 5) | (g << 2) | b:02x}\n")
```

Quartus picks up changes on recompile (`set_global_assignment -name HEX_FILE image.hex`).
The file must remain exactly 76 800 lines — a different size will silently break the
address mapping.

---

## Relationship to other projects in this repository

* **`720p-snake-game-verilog/`** — a React documentation site that specifies this exact
  design. Its timing tables, memory map, and DMA FSM rules match the RTL here one for
  one. Its `vga_dma_master.v` / `async_fifo.v` variants are the cleaner
  FSM-based alternative to this project's counter-based `avalon_dma_master.v` +
  `dcfifo` approach.
* **`uart/`** — an unrelated peripheral. Shares only the board family, the Quartus flow,
  and the SDC conventions.
