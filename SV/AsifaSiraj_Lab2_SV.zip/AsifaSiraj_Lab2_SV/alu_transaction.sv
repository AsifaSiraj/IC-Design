class alu_transaction;
    rand bit [15:0] a;
    rand bit [15:0] b;
    rand bit [3:0]  opcode;

    bit [15:0] result;
    bit        carry;
    bit        zero;

    constraint c_opcode { opcode inside {[0:12]}; }

    constraint c_corner {
        a dist { 16'h0000 := 1, 16'hFFFF := 1, [16'h0001:16'hFFFE] :/ 8 };
        b dist { 16'h0000 := 1, 16'hFFFF := 1, [16'h0001:16'hFFFE] :/ 8 };
    }

    function void display(string tag);
        $display("[%0t] [%s] a=%h b=%h opcode=%0d result=%h carry=%b zero=%b",
                   $time, tag, a, b, opcode, result, carry, zero);
    endfunction
endclass
