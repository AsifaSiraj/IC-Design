interface alu_if (input logic clk);
    logic [15:0] a;
    logic [15:0] b;
    logic [3:0]  opcode;
    logic [15:0] result;
    logic        carry;
    logic        zero;
endinterface
