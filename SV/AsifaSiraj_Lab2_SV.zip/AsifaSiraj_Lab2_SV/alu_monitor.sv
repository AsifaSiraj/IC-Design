class monitor;
    virtual alu_if vif;
    mailbox #(alu_transaction) mon2scb;

    function new(virtual alu_if vif, mailbox #(alu_transaction) mon2scb);
        this.vif     = vif;
        this.mon2scb = mon2scb;
    endfunction

    task run();
        alu_transaction tr;
        forever begin
            @(posedge vif.clk);
            tr         = new();
            tr.a       = vif.a;
            tr.b       = vif.b;
            tr.opcode  = vif.opcode;
            tr.result  = vif.result;
            tr.carry   = vif.carry;
            tr.zero    = vif.zero;
            mon2scb.put(tr);
        end
    endtask
endclass
