class generator;
    mailbox #(alu_transaction) gen2drv;
    int num_random_tests = 13;

    function new(mailbox #(alu_transaction) gen2drv);
        this.gen2drv = gen2drv;
    endfunction

    task run_directed();
        alu_transaction tr;

        tr = new(); tr.a=16'd10;    tr.b=16'd20;    tr.opcode=0;  gen2drv.put(tr);
        tr = new(); tr.a=16'hFFFF;  tr.b=16'h0001;  tr.opcode=0;  gen2drv.put(tr);
        tr = new(); tr.a=16'd50;    tr.b=16'd20;    tr.opcode=1;  gen2drv.put(tr);
        tr = new(); tr.a=16'h0000;  tr.b=16'h0001;  tr.opcode=1;  gen2drv.put(tr);
        tr = new(); tr.a=16'hFFFF;  tr.b=16'h00FF;  tr.opcode=2;  gen2drv.put(tr);
        tr = new(); tr.a=16'hF000;  tr.b=16'h000F;  tr.opcode=3;  gen2drv.put(tr);
        tr = new(); tr.a=16'hAAAA;  tr.b=16'h5555;  tr.opcode=4;  gen2drv.put(tr);
        tr = new(); tr.a=16'hAAAA;  tr.b=16'h0000;  tr.opcode=5;  gen2drv.put(tr);
        tr = new(); tr.a=16'h0001;  tr.b=16'h0000;  tr.opcode=8;  gen2drv.put(tr);
        tr = new(); tr.a=16'h8000;  tr.b=16'h0000;  tr.opcode=9;  gen2drv.put(tr);
        tr = new(); tr.a=16'h1234;  tr.b=16'h1234;  tr.opcode=10; gen2drv.put(tr);
        tr = new(); tr.a=16'h5678;  tr.b=16'h1234;  tr.opcode=11; gen2drv.put(tr);
        tr = new(); tr.a=16'h1234;  tr.b=16'h5678;  tr.opcode=12; gen2drv.put(tr);
        tr = new(); tr.a=16'h00FF;  tr.b=16'h0000;  tr.opcode=6;  gen2drv.put(tr);
        tr = new(); tr.a=16'h0000;  tr.b=16'h0000;  tr.opcode=7;  gen2drv.put(tr);
    endtask

    task run_random();
        alu_transaction tr;
        repeat (num_random_tests) begin
            tr = new();
            if (!tr.randomize())
                $display("[GEN] ERROR: Randomization failed!");
            gen2drv.put(tr);
        end
    endtask

    task run();
        run_directed();
        run_random();
    endtask
endclass
