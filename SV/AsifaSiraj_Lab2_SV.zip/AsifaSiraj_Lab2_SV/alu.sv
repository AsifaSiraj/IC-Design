module alu (
    input  logic [15:0] a,
    input  logic [15:0] b,
    input  logic [3:0]  opcode,
    output logic [15:0] result,
    output logic        carry,
    output logic        zero
);
    logic [16:0] temp;

    always_comb begin
        result = 16'h0000;
        carry  = 1'b0;
        temp   = 17'h00000;

        case (opcode)
            4'd0  : begin temp = a + b;  result = temp[15:0]; carry = temp[16];        end
            4'd1  : begin temp = a - b;  result = temp[15:0]; carry = (a < b);         end
            4'd2  : begin result = a & b;                                              end
            4'd3  : begin result = a | b;                                              end
            4'd4  : begin result = a ^ b;                                              end
            4'd5  : begin result = ~a;                                                 end
            4'd6  : begin temp = a + 1;  result = temp[15:0]; carry = temp[16];        end
            4'd7  : begin temp = a - 1;  result = temp[15:0]; carry = (a == 16'h0000); end
            4'd8  : begin result = a << 1; carry = a[15];                              end
            4'd9  : begin result = a >> 1; carry = a[0];                               end
            4'd10 : begin result = (a == b) ? 16'h0001 : 16'h0000;                      end
            4'd11 : begin result = (a >  b) ? 16'h0001 : 16'h0000;                      end
            4'd12 : begin result = (a <  b) ? 16'h0001 : 16'h0000;                      end
            default: result = 16'h0000;
        endcase
    end

    assign zero = (result == 16'h0000);
endmodule
