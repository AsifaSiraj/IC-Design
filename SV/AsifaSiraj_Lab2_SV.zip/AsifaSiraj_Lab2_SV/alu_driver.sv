class driver;
    virtual alu_if vif;
    mailbox #(alu_transaction) gen2drv;
    int drv_count = 0;

    function new(virtual alu_if vif, mailbox #(alu_transaction) gen2drv);
        this.vif     = vif;
        this.gen2drv = gen2drv;
    endfunction

    task run();
        alu_transaction tr;
        forever begin
            gen2drv.get(tr);
            @(negedge vif.clk);
            vif.a      = tr.a;
            vif.b      = tr.b;
            vif.opcode = tr.opcode;
            drv_count++;
        end
    endtask
endclass
