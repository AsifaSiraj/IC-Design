class scoreboard;
    mailbox #(alu_transaction) mon2scb;
    int pass_count = 0;
    int fail_count = 0;

    function new(mailbox #(alu_transaction) mon2scb);
        this.mon2scb = mon2scb;
    endfunction

    function void compute_expected(
        input  bit [15:0] a,
        input  bit [15:0] b,
        input  bit [3:0]  opcode,
        output bit [15:0] exp_result,
        output bit        exp_carry
    );
        bit [16:0] temp;
        exp_result = 16'h0000;
        exp_carry  = 1'b0;

        case (opcode)
            4'd0  : begin temp = a + b; exp_result = temp[15:0]; exp_carry = temp[16];        end
            4'd1  : begin temp = a - b; exp_result = temp[15:0]; exp_carry = (a < b);          end
            4'd2  : exp_result = a & b;
            4'd3  : exp_result = a | b;
            4'd4  : exp_result = a ^ b;
            4'd5  : exp_result = ~a;
            4'd6  : begin temp = a + 1; exp_result = temp[15:0]; exp_carry = temp[16];         end
            4'd7  : begin temp = a - 1; exp_result = temp[15:0]; exp_carry = (a == 16'h0000);  end
            4'd8  : begin exp_result = a << 1; exp_carry = a[15];                              end
            4'd9  : begin exp_result = a >> 1; exp_carry = a[0];                               end
            4'd10 : exp_result = (a == b) ? 16'h0001 : 16'h0000;
            4'd11 : exp_result = (a >  b) ? 16'h0001 : 16'h0000;
            4'd12 : exp_result = (a <  b) ? 16'h0001 : 16'h0000;
            default: exp_result = 16'h0000;
        endcase
    endfunction

    task run();
        alu_transaction tr;
        bit [15:0] exp_result;
        bit        exp_carry;
        bit        exp_zero;

        forever begin
            mon2scb.get(tr);
            compute_expected(tr.a, tr.b, tr.opcode, exp_result, exp_carry);
            exp_zero = (exp_result == 16'h0000);

            if ((exp_result === tr.result) &&
                (exp_carry  === tr.carry)  &&
                (exp_zero   === tr.zero)) begin
                pass_count++;
                $display("[%0t] [PASS] a=%h b=%h op=%0d | result=%h(exp %h) carry=%b(exp %b) zero=%b(exp %b)",
                          $time, tr.a, tr.b, tr.opcode,
                          tr.result, exp_result, tr.carry, exp_carry, tr.zero, exp_zero);
            end else begin
                fail_count++;
                $display("[%0t] [FAIL] a=%h b=%h op=%0d | result=%h(exp %h) carry=%b(exp %b) zero=%b(exp %b)",
                          $time, tr.a, tr.b, tr.opcode,
                          tr.result, exp_result, tr.carry, exp_carry, tr.zero, exp_zero);
            end
        end
    endtask

    function void report();
        $display("=========================================================");
        $display(" ALU VERIFICATION SUMMARY");
        $display(" Total  : %0d", pass_count + fail_count);
        $display(" Passed : %0d", pass_count);
        $display(" Failed : %0d", fail_count);
        $display("=========================================================");
    endfunction
endclass
