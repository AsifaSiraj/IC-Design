class environment;
    generator  gen;
    driver     drv;
    monitor    mon;
    scoreboard scb;

    mailbox #(alu_transaction) gen2drv;
    mailbox #(alu_transaction) mon2scb;

    virtual alu_if vif;

    int total_tests = 0;  

    function new(virtual alu_if vif);
        this.vif = vif;
        gen2drv  = new();
        mon2scb  = new();

        gen = new(gen2drv);
        drv = new(vif, gen2drv);
        mon = new(vif, mon2scb);
        scb = new(mon2scb);
    endfunction

    task wait_for_completion();
        int processed = 0;
        #500; 

    endtask

    task run();
        fork
            drv.run();
            mon.run();
            scb.run();
        join_none

        gen.run(); 
        
        wait_for_completion();

        repeat (20) @(posedge vif.clk);

        scb.report();
        
        $display("Environment finished - all %0d tests completed.", 
                 scb.pass_count + scb.fail_count);
        $finish;
    endtask
endclass
