import alu_pkg::*;

module tb_top;

    logic clk;

    initial clk = 0;
    always #5 clk = ~clk;

    alu_if vif (clk);

    alu dut (
        .a      (vif.a),
        .b      (vif.b),
        .opcode (vif.opcode),
        .result (vif.result),
        .carry  (vif.carry),
        .zero   (vif.zero)
    );

    environment env;

    initial begin
        $display("=========================================================");
        $display(" Starting 16-bit ALU Verification");
        $display("=========================================================");

        env = new(vif);
        env.run();

        $display("Simulation Complete.");
        //$finish;
    end

    initial begin
        $dumpfile("alu_tb.vcd");
        $dumpvars(0, tb_top);
    end

endmodule
