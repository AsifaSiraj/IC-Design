# =====================================================
# wave.do — FIFO waveform + assertion display script
# =====================================================
onerror {resume}
quietly WaveActivateNextPane {} 0

# ---------------- DUT / TB signals ----------------
add wave -noupdate -divider "Clock/Reset"
add wave -noupdate /fifo_tb/clk
add wave -noupdate /fifo_tb/rst_n

add wave -noupdate -divider "Control"
add wave -noupdate /fifo_tb/wr_en
add wave -noupdate /fifo_tb/rd_en

add wave -noupdate -divider "Data"
add wave -noupdate -radix hexadecimal /fifo_tb/din
add wave -noupdate -radix hexadecimal /fifo_tb/dout

add wave -noupdate -divider "Status"
add wave -noupdate /fifo_tb/full
add wave -noupdate /fifo_tb/empty

add wave -noupdate -divider "Internal Pointers (DUT)"
add wave -noupdate -radix unsigned /fifo_tb/dut/wr_ptr
add wave -noupdate -radix unsigned /fifo_tb/dut/rd_ptr

add wave -noupdate -divider "Memory Array"
add wave -noupdate -radix hexadecimal /fifo_tb/dut/mem

# ---------------- Assertion checker internal signals ----------------
add wave -noupdate -divider "Assertion Checker - Reference Model"
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/expected_valid
add wave -noupdate -radix hexadecimal /fifo_tb/dut/u_fifo_assertions/expected_data

# ---------------- Assertion pass/fail/vacuous indicators ----------------
add wave -noupdate -divider "Assertions (pass=green tick / fail=red X)"
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/a_reset_empty
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/a_full_empty_mutex
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/a_illegal_read_ignored
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/a_illegal_write_ignored
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/a_write_empty_to_nonempty
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/a_read_full_to_nonfull
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/a_data_order

# ---------------- Cover properties (for vacuity check) ----------------
add wave -noupdate -divider "Cover Properties"
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/cov_illegal_read
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/cov_illegal_write
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/cov_write_empty
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/cov_read_full
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/cov_full_reached
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/cov_empty_reached
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/cov_valid_write
add wave -noupdate /fifo_tb/dut/u_fifo_assertions/cov_valid_read

# ---------------- Formatting ----------------
configure wave -namecolwidth 260
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -datasetprefix 0

# ---------------- Enable assertions before running ----------------
assertion enable -recursive /fifo_tb/dut/u_fifo_assertions/*

# ---------------- Run ----------------
run -all

# ---------------- Zoom to fit ----------------
wave zoom full

# ---------------- Generate assertion report ----------------
assertion report -recursive /fifo_tb/dut/u_fifo_assertions -file assertion_report.txt
assertion report -verbose -file assertion_report_verbose.txt

# ---------------- Generate coverage summary (if functional coverage used) ----------------
# coverage report -output coverage_report.txt -detail -assert -cvg