//=====================================================================
// Description: Synchronous FIFO, 8-bit wide, 8-entry deep, active-low
//              asynchronous reset, single clock domain.
//=====================================================================
module fifo #(
    parameter int DATA_WIDTH = 8,
    parameter int DEPTH      = 8,
    parameter int PTR_WIDTH  = $clog2(DEPTH)
)(
    input  logic                   clk,
    input  logic                   rst_n,
    input  logic                   wr_en,
    input  logic                   rd_en,
    input  logic [DATA_WIDTH-1:0]  din,
    output logic [DATA_WIDTH-1:0]  dout,
    output logic                   full,
    output logic                   empty
);

    // Memory array
    logic [DATA_WIDTH-1:0] mem [0:DEPTH-1];

    // Pointers have one extra MSB to distinguish full from empty
    logic [PTR_WIDTH:0] wr_ptr, rd_ptr;

    wire [PTR_WIDTH-1:0] wr_addr = wr_ptr[PTR_WIDTH-1:0];
    wire [PTR_WIDTH-1:0] rd_addr = rd_ptr[PTR_WIDTH-1:0];

    //-----------------------------------------------------------------
    // Status flags
    //-----------------------------------------------------------------
    assign empty = (wr_ptr == rd_ptr);
    assign full  = (wr_ptr[PTR_WIDTH]     != rd_ptr[PTR_WIDTH]) &&
                   (wr_ptr[PTR_WIDTH-1:0] == rd_ptr[PTR_WIDTH-1:0]);

    //-----------------------------------------------------------------
    // Write logic
    //-----------------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr <= '0;
        end else if (wr_en && !full) begin
            mem[wr_addr] <= din;
            wr_ptr       <= wr_ptr + 1'b1;
        end
    end

    //-----------------------------------------------------------------
    // Read logic
    //-----------------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rd_ptr <= '0;
            dout   <= '0;
        end else if (rd_en && !empty) begin
            dout   <= mem[rd_addr];
            rd_ptr <= rd_ptr + 1'b1;
        end
    end

endmodule
