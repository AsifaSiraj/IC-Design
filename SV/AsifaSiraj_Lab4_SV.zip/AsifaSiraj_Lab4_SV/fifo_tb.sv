//=====================================================================
// Description: Testbench for the synchronous FIFO. Generates clock,
//              reset, and directed stimulus covering all required
//              test cases. Assertions from fifo_assertions.sv are
//              automatically attached via the `bind` statement.
//=====================================================================
module fifo_tb;

    localparam int DATA_WIDTH = 8;
    localparam int DEPTH      = 8;

    logic                  clk;
    logic                  rst_n;
    logic                  wr_en, rd_en;
    logic [DATA_WIDTH-1:0] din;
    logic [DATA_WIDTH-1:0] dout;
    logic                  full, empty;

    int i;

    //-----------------------------------------------------------------
    // DUT instantiation
    //-----------------------------------------------------------------
    fifo #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH     (DEPTH)
    ) dut (
        .clk   (clk),
        .rst_n (rst_n),
        .wr_en (wr_en),
        .rd_en (rd_en),
        .din   (din),
        .dout  (dout),
        .full  (full),
        .empty (empty)
    );

    //-----------------------------------------------------------------
    // Clock generation: 10ns period
    //-----------------------------------------------------------------
    initial clk = 1'b0;
    always #5 clk = ~clk;

    //-----------------------------------------------------------------
    // Reset generation (active-low)
    //-----------------------------------------------------------------
    initial begin
        rst_n = 1'b0;
        wr_en = 1'b0;
        rd_en = 1'b0;
        din   = '0;
        repeat (3) @(negedge clk);
        rst_n = 1'b1;
    end

    //-----------------------------------------------------------------
    // Tasks for write / read stimulus (single-cycle pulses)
    //-----------------------------------------------------------------
    task automatic do_write(input [DATA_WIDTH-1:0] data);
        @(negedge clk);
        wr_en = 1'b1;
        din   = data;
        @(negedge clk);
        wr_en = 1'b0;
    endtask

    task automatic do_read();
        @(negedge clk);
        rd_en = 1'b1;
        @(negedge clk);
        rd_en = 1'b0;
    endtask

    task automatic do_write_read(input [DATA_WIDTH-1:0] data);
        @(negedge clk);
        wr_en = 1'b1; din = data;
        rd_en = 1'b1;
        @(negedge clk);
        wr_en = 1'b0; rd_en = 1'b0;
    endtask

    //-----------------------------------------------------------------
    // Simple transaction monitor
    //-----------------------------------------------------------------
    always @(posedge clk) begin
        if (rst_n) begin
            if (wr_en) $display("[%0t] WRITE  din=%0h full=%0b empty=%0b",
                                  $time, din, full, empty);
            if (rd_en) $display("[%0t] READ   dout=%0h full=%0b empty=%0b",
                                  $time, dout, full, empty);
        end
    end

    //-----------------------------------------------------------------
    // Main stimulus sequence (covers all required test cases)
    //-----------------------------------------------------------------
    initial begin
        // Wait for reset release --------------------------------- Test 1
        wr_en = 0; rd_en = 0; din = 0;
        wait (rst_n == 1'b1);
        @(negedge clk);
        $display("== Test 1: Reset check (empty expected) ==");

        // Test 2: single write ------------------------------------------
        $display("== Test 2: Single write ==");
        do_write(8'hA1);

        // Test 3: single read --------------------------------------------
        $display("== Test 3: Single read ==");
        do_read();

        // Test 4: consecutive writes --------------------------------------
        $display("== Test 4: Consecutive writes ==");
        do_write(8'h11);
        do_write(8'h22);
        do_write(8'h33);

        // Test 5: consecutive reads ----------------------------------------
        $display("== Test 5: Consecutive reads ==");
        do_read();
        do_read();
        do_read();

        // Test 6: fill FIFO until full --------------------------------------
        $display("== Test 6: Fill FIFO until full ==");
        for (i = 0; i < DEPTH; i++) begin
            do_write(8'h50 + i[7:0]);
        end

        // Test 9: attempt write when full (illegal, must be ignored) --------
        $display("== Test 9: Attempt write while full ==");
        do_write(8'hFF);

        // Test 7: empty FIFO until empty asserted ----------------------------
        $display("== Test 7: Empty FIFO until empty ==");
        for (i = 0; i < DEPTH; i++) begin
            do_read();
        end

        // Test 8: attempt read when empty (illegal, must be ignored) --------
        $display("== Test 8: Attempt read while empty ==");
        do_read();

        // Test 10: FIFO ordering verification --------------------------------
        $display("== Test 10: FIFO ordering check ==");
        for (i = 0; i < DEPTH; i++) begin
            do_write(i[7:0]);
        end
        for (i = 0; i < DEPTH; i++) begin
            do_read();
        end

        // Extra: simultaneous write/read to exercise boundary transitions
        $display("== Extra: simultaneous write & read ==");
        do_write(8'hAA);
        do_write_read(8'hBB);
        do_read();

        #50;
        $display("Simulation complete at time %0t", $time);
        $stop;
    end

    //-----------------------------------------------------------------
    // Waveform dump
    //-----------------------------------------------------------------
    initial begin
        $dumpfile("fifo_tb.vcd");
        $dumpvars(0, fifo_tb);
    end

endmodule
