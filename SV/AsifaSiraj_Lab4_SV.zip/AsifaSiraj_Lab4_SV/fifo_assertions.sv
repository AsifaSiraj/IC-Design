//=====================================================================
// Description: SystemVerilog Assertions for the synchronous FIFO.
//              Bound to the fifo module so that internal signals
//              (wr_ptr, rd_ptr) are directly visible without
//              modifying the RTL port list.
//=====================================================================
module fifo_assertions #(
    parameter int DATA_WIDTH = 8,
    parameter int DEPTH      = 8,
    parameter int PTR_WIDTH  = $clog2(DEPTH)
)(
    input logic                   clk,
    input logic                   rst_n,
    input logic                   wr_en,
    input logic                   rd_en,
    input logic [DATA_WIDTH-1:0]  din,
    input logic [DATA_WIDTH-1:0]  dout,
    input logic                   full,
    input logic                   empty,
    input logic [PTR_WIDTH:0]     wr_ptr,
    input logic [PTR_WIDTH:0]     rd_ptr
);

    //=================================================================
    // Reference model (golden queue) for data-ordering checks
    //=================================================================
    logic [DATA_WIDTH-1:0] ref_q[$];
    logic [DATA_WIDTH-1:0] expected_data;
    logic                  expected_valid;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ref_q.delete();
            expected_data  <= '0;
            expected_valid <= 1'b0;
        end else begin
            // Model a valid write
            if (wr_en && !full) ref_q.push_back(din);

            // Model a valid read (dout is registered, valid 1 cycle later)
            if (rd_en && !empty) begin
                expected_data  <= ref_q.pop_front();
                expected_valid <= 1'b1;
            end else begin
                expected_valid <= 1'b0;
            end
        end
    end

    //=================================================================
    // Property 1: FIFO shall be empty after reset
    //=================================================================
    property p_reset_empty;
        @(posedge clk) $rose(rst_n) |-> empty;
    endproperty
    a_reset_empty: assert property (p_reset_empty)
        else $error("[ASSERT FAIL] FIFO not empty immediately after reset");

    //=================================================================
    // Property 2: full and empty shall not be asserted simultaneously
    //=================================================================
    property p_full_empty_mutex;
        @(posedge clk) disable iff (!rst_n) !(full && empty);
    endproperty
    a_full_empty_mutex: assert property (p_full_empty_mutex)
        else $error("[ASSERT FAIL] full and empty asserted at the same time");

    //=================================================================
    // Property 3: A read shall not be performed when FIFO is empty
    // (i.e., an rd_en while empty must have NO effect on rd_ptr)
    //=================================================================
    property p_illegal_read_ignored;
        @(posedge clk) disable iff (!rst_n)
            (rd_en && empty) |=> (rd_ptr == $past(rd_ptr));
    endproperty
    a_illegal_read_ignored: assert property (p_illegal_read_ignored)
        else $error("[ASSERT FAIL] rd_ptr changed during illegal read (empty)");

    cov_illegal_read: cover property (
        @(posedge clk) disable iff (!rst_n) (rd_en && empty));

    //=================================================================
    // Property 4: A write shall not be performed when FIFO is full
    // (i.e., a wr_en while full must have NO effect on wr_ptr)
    //=================================================================
    property p_illegal_write_ignored;
        @(posedge clk) disable iff (!rst_n)
            (wr_en && full) |=> (wr_ptr == $past(wr_ptr));
    endproperty
    a_illegal_write_ignored: assert property (p_illegal_write_ignored)
        else $error("[ASSERT FAIL] wr_ptr changed during illegal write (full)");

    cov_illegal_write: cover property (
        @(posedge clk) disable iff (!rst_n) (wr_en && full));

    //=================================================================
    // Property 5: A valid write to an empty FIFO shall make it non-empty
    //=================================================================
    property p_write_empty_to_nonempty;
        @(posedge clk) disable iff (!rst_n)
            (wr_en && empty && !full) |=> !empty;
    endproperty
    a_write_empty_to_nonempty: assert property (p_write_empty_to_nonempty)
        else $error("[ASSERT FAIL] FIFO still empty after valid write to empty FIFO");

    cov_write_empty: cover property (
        @(posedge clk) disable iff (!rst_n) (wr_en && empty && !full));

    //=================================================================
    // Property 6: A valid read from a full FIFO shall make it non-full
    //=================================================================
    property p_read_full_to_nonfull;
        @(posedge clk) disable iff (!rst_n)
            (rd_en && full && !empty) |=> !full;
    endproperty
    a_read_full_to_nonfull: assert property (p_read_full_to_nonfull)
        else $error("[ASSERT FAIL] FIFO still full after valid read from full FIFO");

    cov_read_full: cover property (
        @(posedge clk) disable iff (!rst_n) (rd_en && full && !empty));

    //=================================================================
    // Property 7: Data shall be read out in FIFO (FIFO) order
    //=================================================================
    property p_data_order;
        @(posedge clk) disable iff (!rst_n)
            expected_valid |-> (dout == expected_data);
    endproperty
    a_data_order: assert property (p_data_order)
        else $error("[ASSERT FAIL] Data ordering violation: expected=%0h got=%0h",
                     expected_data, dout);

    //=================================================================
    // Additional coverage to help identify vacuous assertion successes
    //=================================================================
    cov_full_reached  : cover property (@(posedge clk) disable iff (!rst_n) full);
    cov_empty_reached : cover property (@(posedge clk) disable iff (!rst_n) empty);
    cov_valid_write   : cover property (@(posedge clk) disable iff (!rst_n) (wr_en && !full));
    cov_valid_read    : cover property (@(posedge clk) disable iff (!rst_n) (rd_en && !empty));

endmodule



