//=====================================================================
// Bind statement: attaches the checker to every instance of "fifo"
// without modifying the RTL. Internal signals wr_ptr/rd_ptr of the
// fifo module are visible here because bind places the instance
// inside the target module's scope.
//=====================================================================

bind fifo fifo_assertions #(
    .DATA_WIDTH(DATA_WIDTH),
    .DEPTH(DEPTH),
    .PTR_WIDTH(PTR_WIDTH)
) u_fifo_assertions (
    .clk    (clk),
    .rst_n  (rst_n),
    .wr_en  (wr_en),
    .rd_en  (rd_en),
    .din    (din),
    .dout   (dout),
    .full   (full),
    .empty  (empty),
    .wr_ptr (wr_ptr),
    .rd_ptr (rd_ptr)
);
