`include "transaction.sv"
`include "generator.sv"
`include "driver.sv"
`include "monitor.sv"
`include "scoreboard.sv"

class environment;
  generator gen;
  driver drv;
  monitor mon;
  scoreboard scb;
  
  mailbox #(transaction) gen2drv;
  mailbox #(transaction) mon2scb;
  
  virtual arb_intf vif;
  
  function new(virtual arb_intf vif);
    this.vif = vif;
    
    // Create mailboxes
    gen2drv = new();
    mon2scb = new();
    
    // Create components
    gen = new(gen2drv);
    drv = new(vif, gen2drv);
    mon = new(vif, mon2scb);
    scb = new(mon2scb);
  endfunction
  
  task run();
    $display("\n========================================");
    $display("    ENVIRONMENT: Starting Simulation    ");
    $display("========================================\n");
    
    // Fork all processes
    fork
      drv.reset();
    join
    
    fork
      gen.run();
      drv.run();
      mon.run();
      scb.run();
    join_any
    
    // Wait for all transactions to be processed
    #1000;
    
    scb.report();
    
    $display("\n========================================");
    $display("    ENVIRONMENT: Simulation Complete    ");
    $display("========================================\n");
  endtask
  
endclass

