`ifndef TRANSACTION_SV
`define TRANSACTION_SV

class transaction;
 bit [3:0] req;
  bit [3:0] grant;
  
  // Constraint to ensure req is never 0000
  constraint req_not_zero {
    req != 4'b0000;
  }
  
  // Display function
  function void display(string name = "Transaction");
    $display("========================================");
    $display("%s:", name);
    $display("Time = %0t", $time);
    $display("req   = %4b", req);
    $display("grant = %4b", grant);
    $display("========================================");
  endfunction
  
  // Copy function for deep copy
  function transaction copy();
    copy = new();
    copy.req = this.req;
    copy.grant = this.grant;
  endfunction
  
endclass


`endif
