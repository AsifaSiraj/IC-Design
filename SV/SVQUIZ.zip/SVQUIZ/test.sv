`include "environment.sv"

module test(arb_intf intf);
  environment env;

  initial begin
    $display("\n========================================");
    $display("    TEST: Initializing Test Program     ");
    $display("========================================\n");

    env = new(intf);
    env.run();

    #100;
    $display("\n========================================");
    $display("         TEST: Ending Simulation        ");
    $display("========================================\n");
    $finish;
  end

endmodule