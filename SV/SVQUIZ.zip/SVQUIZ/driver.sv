`include "transaction.sv"

class driver;
  virtual arb_intf.DRIVER vif;
  mailbox #(transaction) gen2drv;
  transaction trans;
  
  function new(virtual arb_intf.DRIVER vif, mailbox #(transaction) gen2drv);
    this.vif = vif;
    this.gen2drv = gen2drv;
  endfunction
  
  task reset();
    $display("[DRIVER] Resetting DUT...");
    vif.reset <= 1'b1;
    vif.driver_cb.req <= 4'b0000;
    repeat(2) @(vif.driver_cb);
    vif.reset <= 1'b0;
    $display("[DRIVER] Reset complete");
  endtask
  
  task run();
    $display("[DRIVER] Driver started");
    
    forever begin
      gen2drv.get(trans);
      
      @(vif.driver_cb);
      vif.driver_cb.req <= trans.req;
      
      $display("[DRIVER] Driving req = %4b at time %0t", trans.req, $time);
    end
  endtask
  
endclass

