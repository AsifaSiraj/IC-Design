module round_robin_arbiter(
  input logic clk,
  input logic reset,
  input logic [3:0] req,
  output logic [3:0] grant
);
  
  logic [1:0] priority_ptr;
  
  always_ff @(posedge clk or posedge reset) begin
    if(reset) begin
      priority_ptr <= 2'b00;
      grant <= 4'b0000;
    end
    else begin
      grant <= 4'b0000;
      
      if(req != 4'b0000) begin
      
        case(priority_ptr)
          2'b00: begin
            if(req[0])      begin grant <= 4'b0001; priority_ptr <= 2'b01; end
            else if(req[1]) begin grant <= 4'b0010; priority_ptr <= 2'b10; end
            else if(req[2]) begin grant <= 4'b0100; priority_ptr <= 2'b11; end
            else if(req[3]) begin grant <= 4'b1000; priority_ptr <= 2'b00; end
          end
          2'b01: begin
            if(req[1])      begin grant <= 4'b0010; priority_ptr <= 2'b10; end
            else if(req[2]) begin grant <= 4'b0100; priority_ptr <= 2'b11; end
            else if(req[3]) begin grant <= 4'b1000; priority_ptr <= 2'b00; end
            else if(req[0]) begin grant <= 4'b0001; priority_ptr <= 2'b01; end
          end
          2'b10: begin
            if(req[2])      begin grant <= 4'b0100; priority_ptr <= 2'b11; end
            else if(req[3]) begin grant <= 4'b1000; priority_ptr <= 2'b00; end
            else if(req[0]) begin grant <= 4'b0001; priority_ptr <= 2'b01; end
            else if(req[1]) begin grant <= 4'b0010; priority_ptr <= 2'b10; end
          end
          2'b11: begin
            if(req[3])      begin grant <= 4'b1000; priority_ptr <= 2'b00; end
            else if(req[0]) begin grant <= 4'b0001; priority_ptr <= 2'b01; end
            else if(req[1]) begin grant <= 4'b0010; priority_ptr <= 2'b10; end
            else if(req[2]) begin grant <= 4'b0100; priority_ptr <= 2'b11; end
          end
        endcase
      end
    end
  end
  
endmodule
