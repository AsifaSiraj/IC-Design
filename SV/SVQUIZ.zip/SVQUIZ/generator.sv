`include "transaction.sv"

class generator;

  transaction trans;
  mailbox #(transaction) gen2drv;
  int num_transactions = 25;

  function new(mailbox #(transaction) gen2drv);
    this.gen2drv = gen2drv;
  endfunction

  task run();

    int i;

    $display("========================================");
    $display("[GENERATOR] Starting generation of %0d transactions", num_transactions);
    $display("========================================");

    for(i = 0; i < num_transactions; i++) begin

      trans = new();

      // Generate request between 1 and 15 (never 0000)
      trans.req = $urandom_range(1,15);

      $display("[GENERATOR] Transaction %0d : req = %4b",
                i+1, trans.req);

      gen2drv.put(trans.copy());

    end

    $display("[GENERATOR] All %0d transactions generated", num_transactions);

  endtask

endclass