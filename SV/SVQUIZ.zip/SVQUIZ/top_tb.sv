`timescale 1ns/1ps

module top_tb;

  logic clk;
  logic reset;
  logic [3:0] req;
  logic [3:0] grant;

  integer ptr;
  integer pass_count;
  integer fail_count;
  integer total_count;
  integer i;
  reg [3:0] rand_req;

  // DUT instantiation
  round_robin_arbiter dut (
    .clk   (clk),
    .reset (reset),
    .req   (req),
    .grant (grant)
  );

  // Clock generation
  initial begin
    clk = 0;
  end

  always #5 clk = ~clk;

  // Expected grant calculator
  function automatic [3:0] expected_grant(input [3:0] r, input integer p);
    integer k;
    integer idx;
    reg found;
    begin
      expected_grant = 4'b0000;
      found = 0;

      if (r != 4'b0000) begin
        for (k = 0; k < 4; k = k + 1) begin
          idx = (p + k) % 4;

          if (!found && r[idx]) begin
            expected_grant[idx] = 1'b1;
            found = 1;
          end
        end
      end
    end
  endfunction

  // Check one-hot or zero grant
  function automatic bit is_onehot0(input [3:0] g);
    integer k;
    integer count;
    begin
      count = 0;

      for (k = 0; k < 4; k = k + 1) begin
        if (g[k])
          count = count + 1;
      end

      is_onehot0 = (count <= 1);
    end
  endfunction

  // Update reference priority pointer
  task automatic update_ptr(input [3:0] exp_gnt);
    integer k;
    begin
      if (exp_gnt != 4'b0000) begin
        for (k = 0; k < 4; k = k + 1) begin
          if (exp_gnt[k]) begin
            ptr = (k + 1) % 4;
          end
        end
      end
    end
  endtask

  // Apply request and check grant
  task automatic apply_and_check(input [3:0] r);
    reg [3:0] exp;
    integer old_ptr;
    begin
      @(negedge clk);
      req = r;

      @(posedge clk);
      #1;

      old_ptr = ptr;
      exp = expected_grant(r, ptr);

      total_count = total_count + 1;

      $display("--------------------------------------------------");
      $display("Time=%0t | Req=%b | Grant=%b | Expected=%b | Ptr(before)=%0d",
                $time, r, grant, exp, old_ptr);

      if (!is_onehot0(grant)) begin
        $display("FAIL: Multiple grants detected!");
        fail_count = fail_count + 1;
      end
      else if (grant === exp) begin
        $display("PASS");
        pass_count = pass_count + 1;
      end
      else begin
        $display("FAIL: Grant mismatch!");
        fail_count = fail_count + 1;
      end

      // Reference model pointer expected grant ke basis par update hoga
      update_ptr(exp);

      $display("Ptr(after)=%0d", ptr);
      $display("--------------------------------------------------");
    end
  endtask

  // Reset task
  task automatic reset_dut();
    begin
      $display("\nApplying reset...");

      reset = 1'b1;
      req = 4'b0000;
      ptr = 0;

      repeat (3) @(posedge clk);
      #1;

      if (grant !== 4'b0000) begin
        $display("FAIL: Grant should be 0000 during reset, grant=%b", grant);
        fail_count = fail_count + 1;
      end

      @(negedge clk);
      reset = 1'b0;
      ptr = 0;

      $display("Reset released. Priority pointer = 0\n");
    end
  endtask

  // Main test
  initial begin
    reset = 0;
    req = 0;
    ptr = 0;
    pass_count = 0;
    fail_count = 0;
    total_count = 0;

    reset_dut();

    // Directed tests
    $display("\n========== Directed Tests ==========");

    apply_and_check(4'b0000); // no request, grant should be zero, ptr unchanged

    apply_and_check(4'b0001); // req0
    apply_and_check(4'b0011); // req0 and req1
    apply_and_check(4'b1111); // all requesters
    apply_and_check(4'b1111);
    apply_and_check(4'b1111);
    apply_and_check(4'b1111);

    apply_and_check(4'b0100); // req2 only
    apply_and_check(4'b1000); // req3 only
    apply_and_check(4'b0000); // no request again

    // Random tests with req != 0000
    $display("\n========== Random Tests: req != 0000 ==========");

    for (i = 0; i < 25; i = i + 1) begin
      rand_req = $urandom_range(1, 15); // constraint: req != 0000
      apply_and_check(rand_req);
    end

    // Final report
    $display("\n========== FINAL REPORT ==========");
    $display("Total Checks = %0d", total_count);
    $display("PASS         = %0d", pass_count);
    $display("FAIL         = %0d", fail_count);
    $display("==================================\n");

    if (fail_count == 0)
      $display("TEST PASSED");
    else
      $display("TEST FAILED");

    #20;
    $finish;
  end

endmodule