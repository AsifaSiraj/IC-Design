`include "transaction.sv"

class monitor;
  virtual arb_intf.MONITOR vif;
  mailbox #(transaction) mon2scb;
  transaction trans;
  
  function new(virtual arb_intf.MONITOR vif, mailbox #(transaction) mon2scb);
    this.vif = vif;
    this.mon2scb = mon2scb;
  endfunction
  
  task run();
    $display("[MONITOR] Monitor started");
    
    forever begin
      @(vif.monitor_cb);
      
      // Skip if in reset
      if(vif.monitor_cb.reset) begin
        continue;
      end
      
      trans = new();
      trans.req = vif.monitor_cb.req;
      trans.grant = vif.monitor_cb.grant;
      
      $display("[MONITOR] Sampled at time %0t: req = %4b, grant = %4b", 
               $time, trans.req, trans.grant);
      
      mon2scb.put(trans);
    end
  endtask
  
endclass
