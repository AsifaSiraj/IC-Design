`include "transaction.sv"

class scoreboard;
  mailbox #(transaction) mon2scb;
  transaction trans;
  int priority_pointer = 0;  
  int pass_count = 0;
  int fail_count = 0;
  int total_count = 0;
  
  function new(mailbox #(transaction) mon2scb);
    this.mon2scb = mon2scb;
  endfunction
  
  // Function to calculate expected grant based on round-robin priority
  function bit [3:0] calculate_expected_grant(bit [3:0] req);
    bit [3:0] expected_grant = 4'b0000;
    int check_order[4];
    
    // If no request, no grant
    if(req == 4'b0000) begin
      return 4'b0000;
    end
    
    // Create priority order starting from priority_pointer
    for(int i = 0; i < 4; i++) begin
      check_order[i] = (priority_pointer + i) % 4;
    end
    
    // Find the highest priority requester
    for(int i = 0; i < 4; i++) begin
      if(req[check_order[i]]) begin
        expected_grant[check_order[i]] = 1'b1; //value inside the order not order value itself
        return expected_grant;
      end
    end
    
    return expected_grant;
  endfunction
  
  // Function to check if grant is one-hot or zero
  function bit is_valid_grant(bit [3:0] grant);
    return ($countones(grant) <= 1);
  endfunction
  
  // Function to update priority pointer after successful grant
  function void update_priority_pointer(bit [3:0] grant);
    if(grant != 4'b0000) begin
      for(int i = 0; i < 4; i++) begin
        if(grant[i]) begin
          priority_pointer = (i + 1) % 4;
          $display("[SCOREBOARD] Priority pointer updated to %0d", priority_pointer);
          return;
        end
      end
    end
  endfunction
  
  task run();
    bit [3:0] expected_grant;
    
    $display("[SCOREBOARD] Scoreboard started");
    $display("[SCOREBOARD] Initial priority pointer = %0d", priority_pointer);
    
    forever begin
      mon2scb.get(trans);
      total_count++;
      
      $display("\n========================================");
      $display("[SCOREBOARD] Checking transaction #%0d", total_count);
      $display("----------------------------------------");
      
      // Calculate expected grant
      expected_grant = calculate_expected_grant(trans.req);
      
      $display("[SCOREBOARD] Request        = %4b", trans.req);
      $display("[SCOREBOARD] Actual Grant   = %4b", trans.grant);
      $display("[SCOREBOARD] Expected Grant = %4b", expected_grant);
      $display("[SCOREBOARD] Priority Pointer = %0d", priority_pointer);
      
      // Validate grant format (one-hot or zero)
      if(!is_valid_grant(trans.grant)) begin
        $display("[SCOREBOARD] *** FAIL *** - Multiple grants issued!");
        fail_count++;
      end
      // Compare expected vs actual
      else if(trans.grant === expected_grant) begin
        $display("[SCOREBOARD] *** PASS ***");
        pass_count++;
        // Update priority pointer after successful grant
        update_priority_pointer(trans.grant);
      end
      else begin
        $display("[SCOREBOARD] *** FAIL *** - Grant mismatch!");
        fail_count++;
      end
      
      $display("========================================\n");
    end
  endtask
  
  function void report();
    $display("\n========================================");
    $display("         FINAL SCOREBOARD REPORT        ");
    $display("========================================");
    $display("Total Transactions: %0d", total_count);
    $display("Passed           : %0d", pass_count);
    $display("Failed           : %0d", fail_count);
    $display("Pass Rate        : %.2f%%", (pass_count * 100.0) / total_count);
    $display("========================================\n");
  endfunction
  
endclass

