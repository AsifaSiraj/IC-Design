interface arb_intf(input logic clk);
  logic reset;
  logic [3:0] req;
  logic [3:0] grant;
  
  // Clocking block for driver
  clocking driver_cb @(posedge clk);
    default input #1 output #1;
    output req;
    output reset;
    input grant;
  endclocking
  
  // Clocking block for monitor
  clocking monitor_cb @(posedge clk);
    default input #1;
    input req;
    input grant;
    input reset;
  endclocking
  
  // Modports
  modport DRIVER (clocking driver_cb, input clk, output reset);
  modport MONITOR (clocking monitor_cb, input clk);
  modport DUT (input clk, reset, req, output grant);
  
endinterface
