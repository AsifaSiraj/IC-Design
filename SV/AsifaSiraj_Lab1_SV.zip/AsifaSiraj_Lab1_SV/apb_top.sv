//=============================================================
// File   : apb_top.sv
// Layer  : Top-level testbench (clock, interface, DUT, test)
//=============================================================
`include "apb_if.sv"
`include "apb_test.sv"

module apb_top;

    logic PCLK;

    // Clock generation: 10ns period
    initial PCLK = 0;
    always #5 PCLK = ~PCLK;

    // Interface instance
    apb_if apb_intf (PCLK);

    // DUT instantiation
    apb_slave DUT (
        .PCLK    (PCLK),
        .PRESETn (apb_intf.PRESETn),
        .PSEL    (apb_intf.PSEL),
        .PENABLE (apb_intf.PENABLE),
        .PWRITE  (apb_intf.PWRITE),
        .PADDR   (apb_intf.PADDR),
        .PWDATA  (apb_intf.PWDATA),
        .PRDATA  (apb_intf.PRDATA),
        .PREADY  (apb_intf.PREADY),
        .PSLVERR (apb_intf.PSLVERR)
    );

    test t;

    initial begin
        t = new(apb_intf);
        t.run();
        #50;
        $display("TESTBENCH COMPLETE");
        $finish;
    end

    // Optional waveform dump
    initial begin
        $dumpfile("apb_tb.vcd");
        $dumpvars(0, apb_top);
    end

endmodule
