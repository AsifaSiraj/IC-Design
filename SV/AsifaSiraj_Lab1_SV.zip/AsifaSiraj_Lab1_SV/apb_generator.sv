//=============================================================
// File   : apb_generator.sv
// Layer  : Generator (stimulus)
//=============================================================
`ifndef APB_GENERATOR_SV
`define APB_GENERATOR_SV

`include "apb_transaction.sv"

class generator;
    transaction tr;
    mailbox #(transaction) gen2drv;
    event drv_done;      // driver -> generator: transfer complete
    int num_transactions;

    function new(mailbox #(transaction) gen2drv, event drv_done);
        this.gen2drv  = gen2drv;
        this.drv_done = drv_done;
    endfunction

    task run();
        repeat (num_transactions) begin
            tr = new();
            tr.randomize_tr();
            tr.display("GEN");
            gen2drv.put(tr.copy());
            @(drv_done);
        end
        $display("[GEN] Completed generating %0d transactions", num_transactions);
    endtask
endclass

`endif
