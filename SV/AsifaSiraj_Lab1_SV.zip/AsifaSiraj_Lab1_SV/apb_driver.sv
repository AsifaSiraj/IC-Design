//=============================================================
// File   : apb_driver.sv
// Layer  : Driver (drives DUT via virtual interface)
//=============================================================
`ifndef APB_DRIVER_SV
`define APB_DRIVER_SV

`include "apb_transaction.sv"

class driver;
    virtual apb_if vif;
    mailbox #(transaction) gen2drv;
    event drv_done;
    transaction tr;

    function new(virtual apb_if vif, mailbox #(transaction) gen2drv, event drv_done);
        this.vif      = vif;
        this.gen2drv  = gen2drv;
        this.drv_done = drv_done;
    endfunction

    task reset();
        vif.PRESETn <= 1'b0;
        vif.PSEL    <= 1'b0;
        vif.PENABLE <= 1'b0;
        vif.PWRITE  <= 1'b0;
        vif.PADDR   <= '0;
        vif.PWDATA  <= '0;
        repeat (5) @(posedge vif.PCLK);
        vif.PRESETn <= 1'b1;
        @(posedge vif.PCLK);
        $display("[DRV] Reset complete at time=%0t", $time);
    endtask

    task run();
        forever begin
            gen2drv.get(tr);

            // ---------- SETUP phase (T1) ----------
            @(posedge vif.PCLK);
            vif.PSEL    <= 1'b1;
            vif.PENABLE <= 1'b0;
            vif.PWRITE  <= tr.pwrite;
            vif.PADDR   <= tr.paddr;
            if (tr.pwrite)
                vif.PWDATA <= tr.pwdata;

            // ---------- ACCESS phase (T2) ----------
            @(posedge vif.PCLK);
            vif.PENABLE <= 1'b1;

            // Wait until slave asserts PREADY
            wait (vif.PREADY);

            if (!tr.pwrite)
                tr.prdata = vif.PRDATA;

            tr.display("DRV");

            // ---------- Return to IDLE ----------
            @(posedge vif.PCLK);
            vif.PSEL    <= 1'b0;
            vif.PENABLE <= 1'b0;

            ->drv_done;
        end
    endtask
endclass

`endif
