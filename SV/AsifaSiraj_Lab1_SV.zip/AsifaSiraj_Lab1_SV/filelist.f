// filelist.f
// Usage (QuestaSim):  vlog -sv -f filelist.f
// Usage (VCS):        vcs -sverilog -f filelist.f
// Usage (Xcelium):    xrun -sv -f filelist.f
//
// Only apb_top.sv needs to be passed as a top module; it `includes
// everything else in the correct layered order:
//   apb_if -> transaction -> generator/driver/monitor/scoreboard
//   -> environment -> test -> top
//
// apb_slave.sv (the DUT) is compiled separately since it is a module,
// not part of the `include chain.

apb_slave.sv
apb_top.sv
