//=============================================================
// File        : apb_slave.sv
// Description : APB Slave Memory (Design Under Test)
//               - 256 x 32-bit memory
//               - Supports single-cycle read/write (PREADY tied high)
//               - Synchronous, active-low reset
//=============================================================

module apb_slave (
    input  logic        PCLK,
    input  logic        PRESETn,
    input  logic        PSEL,
    input  logic        PENABLE,
    input  logic        PWRITE,
    input  logic [7:0]  PADDR,
    input  logic [31:0] PWDATA,
    output logic [31:0] PRDATA,
    output logic        PREADY,
    output logic        PSLVERR
);

    // 256 x 32-bit memory array
    logic [31:0] mem [0:255];

    integer i;

    //---------------------------------------------------------
    // Synchronous write / reset
    //---------------------------------------------------------
    always_ff @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) begin
            for (i = 0; i < 256; i = i + 1)
                mem[i] <= 32'h0000_0000;
        end
        else begin
            // ACCESS phase write: PSEL & PENABLE & PWRITE
            if (PSEL && PENABLE && PWRITE) begin
                mem[PADDR] <= PWDATA;
            end
        end
    end

    //---------------------------------------------------------
    // Read data (combinational read, registered timing handled
    // by APB protocol -- data is valid during ACCESS phase)
    //---------------------------------------------------------
    always_comb begin
        if (PSEL && !PWRITE)
            PRDATA = mem[PADDR];
        else
            PRDATA = 32'h0000_0000;
    end

    //---------------------------------------------------------
    // PREADY: this simple slave never inserts wait states.
    // Change this logic to model wait states if required.
    //---------------------------------------------------------
    assign PREADY  = 1'b1;
    assign PSLVERR = 1'b0;

endmodule
