//=============================================================
// File   : apb_transaction.sv
// Layer  : Transaction (sequence item)
//=============================================================
`ifndef APB_TRANSACTION_SV
`define APB_TRANSACTION_SV

class transaction;
    bit [7:0]  paddr;
    bit [31:0] pwdata;
    bit        pwrite;   // 1 = write, 0 = read

    bit [31:0] prdata;
    bit        pready;
    bit        pslverr;

    // Manual randomization using $urandom (no constraint solver needed -
    // works on every simulator/edition, including ModelSim Starter/ASE
    // which does not license the SystemVerilog constraint solver).
    function void randomize_tr();
        paddr  = $urandom_range(0, 255);   // full 256-location address range
        pwdata = $urandom;                 // random 32-bit data
        pwrite = $urandom_range(0, 1);     // random read(0) / write(1)
    endfunction

    function transaction copy();
        copy        = new();
        copy.paddr  = this.paddr;
        copy.pwdata = this.pwdata;
        copy.pwrite = this.pwrite;
    endfunction

    function void display(string tag);
        $display("[%0s] Time=%0t PADDR=%0h PWDATA=%0h PWRITE=%0b PRDATA=%0h",
                   tag, $time, paddr, pwdata, pwrite, prdata);
    endfunction
endclass

`endif
