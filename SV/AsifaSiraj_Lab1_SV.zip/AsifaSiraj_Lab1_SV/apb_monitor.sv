//=============================================================
// File   : apb_monitor.sv
// Layer  : Monitor (passively samples the bus)
//=============================================================
`ifndef APB_MONITOR_SV
`define APB_MONITOR_SV

`include "apb_transaction.sv"

class monitor;
    virtual apb_if vif;
    mailbox #(transaction) mon2scb;
    transaction tr;

    function new(virtual apb_if vif, mailbox #(transaction) mon2scb);
        this.vif     = vif;
        this.mon2scb = mon2scb;
    endfunction

    task run();
        forever begin
            @(posedge vif.PCLK);
            // Capture completed transfer: ACCESS phase with PREADY high
            if (vif.PSEL && vif.PENABLE && vif.PREADY) begin
                tr = new();
                tr.paddr  = vif.PADDR;
                tr.pwrite = vif.PWRITE;
                if (vif.PWRITE)
                    tr.pwdata = vif.PWDATA;
                else
                    tr.prdata = vif.PRDATA;

                tr.display("MON");
                mon2scb.put(tr);
            end
        end
    endtask
endclass

`endif
