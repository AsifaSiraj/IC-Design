//=============================================================
// File   : apb_coverage.sv
// Layer  : Functional Coverage (instantiated inside monitor)
//=============================================================
`ifndef APB_COVERAGE_SV
`define APB_COVERAGE_SV

class coverage;

    // Sampled signal snapshot (bound to covergroup coverpoints)
    bit        pwrite;
    bit [7:0]  paddr;
    bit [31:0] pwdata;
    bit        pready;
    bit        pslverr;

    //---------------------------------------------------------
    // Covergroup : sampled once per observed APB bus cycle
    //---------------------------------------------------------
    covergroup apb_cg;
        option.per_instance = 1;
        option.name         = "apb_functional_coverage";

        //---------------- Coverage Point 1 : Transaction Type -----------
        cp_write : coverpoint pwrite {
            bins read  = {0};
            bins write = {1};
        }

        //---------------- Coverage Point 2 : Address Coverage -----------
        cp_addr : coverpoint paddr {
            bins low    = {[0   : 63 ]};   // 0-63
            bins middle = {[64  : 127]};   // 64-127
            bins high   = {[128 : 191]};   // 128-191
            bins upper  = {[192 : 255]};   // 192-255
        }

        //---------------- Coverage Point 3 : Write Data ------------------
        cp_wdata : coverpoint pwdata iff (pwrite) {
            bins zero_val    = {32'h0000_0000};
            bins small_val   = {[32'h0000_0001 : 32'h0000_FFFF]};
            bins default_bin = default;
        }

        //---------------- Coverage Point 4 : Slave Ready -----------------
        cp_pready : coverpoint pready {
            bins wait_state = {0};
            bins ready      = {1};
        }

        //---------------- Coverage Point 5 : Error Response (Optional) ---
        cp_pslverr : coverpoint pslverr {
            bins no_error = {0};
            bins error    = {1};
        }

        //---------------- Cross Coverage ----------------------------------
        cx_write_addr   : cross cp_write, cp_addr;
        cx_write_pready : cross cp_write, cp_pready;
        cx_addr_pready  : cross cp_addr,  cp_pready;

    endgroup

    function new();
        apb_cg = new();
    endfunction

    // Called by monitor for EVERY observed access-phase cycle
    function void sample(bit pwrite_i, bit [7:0] paddr_i, bit [31:0] pwdata_i,
                          bit pready_i, bit pslverr_i);
        this.pwrite  = pwrite_i;
        this.paddr   = paddr_i;
        this.pwdata  = pwdata_i;
        this.pready  = pready_i;
        this.pslverr = pslverr_i;
        apb_cg.sample();
    endfunction

    function void report();
        $display("=====================================================");
        $display("FUNCTIONAL COVERAGE REPORT");
        $display("-----------------------------------------------------");
        $display("  cp_write          = %0.2f %%", apb_cg.cp_write.get_coverage());
        $display("  cp_addr           = %0.2f %%", apb_cg.cp_addr.get_coverage());
        $display("  cp_wdata          = %0.2f %%", apb_cg.cp_wdata.get_coverage());
        $display("  cp_pready         = %0.2f %%", apb_cg.cp_pready.get_coverage());
        $display("  cp_pslverr        = %0.2f %%", apb_cg.cp_pslverr.get_coverage());
        $display("-----------------------------------------------------");
        $display("  cx_write_addr     = %0.2f %%", apb_cg.cx_write_addr.get_coverage());
        $display("  cx_write_pready   = %0.2f %%", apb_cg.cx_write_pready.get_coverage());
        $display("  cx_addr_pready    = %0.2f %%", apb_cg.cx_addr_pready.get_coverage());
        $display("-----------------------------------------------------");
        $display("  TOTAL COVERAGE    = %0.2f %%", apb_cg.get_coverage());
        $display("=====================================================");
    endfunction

endclass

`endif
