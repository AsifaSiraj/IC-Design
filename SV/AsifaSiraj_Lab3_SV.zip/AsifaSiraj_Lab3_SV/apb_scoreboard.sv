//=============================================================
// File   : apb_scoreboard.sv
// Layer  : Scoreboard (checks read data against reference model)
//=============================================================
`ifndef APB_SCOREBOARD_SV
`define APB_SCOREBOARD_SV

`include "apb_transaction.sv"

class scoreboard;
    mailbox #(transaction) mon2scb;
    transaction tr;

    bit [31:0] ref_mem [0:255];   // reference (golden) memory model
    int pass_count;
    int fail_count;
    int error_count;

    function new(mailbox #(transaction) mon2scb);
        this.mon2scb = mon2scb;
    endfunction

    task run();
        forever begin
            mon2scb.get(tr);

            if (tr.pslverr) begin
                // Error response: transfer did not modify memory correctly.
                error_count++;
                $display("[SCB] ERROR   Addr=%0h -> PSLVERR asserted, skipping check",
                           tr.paddr);
            end
            else if (tr.pwrite) begin
                ref_mem[tr.paddr] = tr.pwdata;
                $display("[SCB] WRITE  Addr=%0h Data=%0h -> Reference updated",
                           tr.paddr, tr.pwdata);
            end
            else begin
                if (tr.prdata === ref_mem[tr.paddr]) begin
                    pass_count++;
                    $display("[SCB] READ   Addr=%0h Data=%0h  --> PASS",
                               tr.paddr, tr.prdata);
                end
                else begin
                    fail_count++;
                    $display("[SCB] READ   Addr=%0h Expected=%0h Got=%0h --> FAIL",
                               tr.paddr, ref_mem[tr.paddr], tr.prdata);
                end
            end
        end
    endtask

    function void report();
        $display("=====================================================");
        $display("SCOREBOARD REPORT : PASS = %0d  FAIL = %0d  ERROR = %0d",
                   pass_count, fail_count, error_count);
        $display("=====================================================");
    endfunction
endclass

`endif
