//=============================================================
// File   : apb_monitor.sv
// Layer  : Monitor (passively samples the bus + functional coverage)
//=============================================================
`ifndef APB_MONITOR_SV
`define APB_MONITOR_SV

`include "apb_transaction.sv"
`include "apb_coverage.sv"

class monitor;
    virtual apb_if vif;
    mailbox #(transaction) mon2scb;
    transaction tr;

    coverage cov;   // functional coverage instantiated inside monitor

    function new(virtual apb_if vif, mailbox #(transaction) mon2scb);
        this.vif     = vif;
        this.mon2scb = mon2scb;
        cov = new();
    endfunction

    task run();
        forever begin
            @(posedge vif.PCLK);

            // Sample EVERY cycle of the ACCESS phase (captures wait states)
            if (vif.PSEL && vif.PENABLE) begin

                cov.sample(vif.PWRITE, vif.PADDR, vif.PWDATA,
                           vif.PREADY, vif.PSLVERR);

                // Transfer completes only when PREADY is high
                if (vif.PREADY) begin
                    tr = new();
                    tr.paddr   = vif.PADDR;
                    tr.pwrite  = vif.PWRITE;
                    tr.pready  = vif.PREADY;
                    tr.pslverr = vif.PSLVERR;

                    if (vif.PWRITE)
                        tr.pwdata = vif.PWDATA;
                    else
                        tr.prdata = vif.PRDATA;

                    tr.display("MON");
                    mon2scb.put(tr);
                end
            end
        end
    endtask

    // Called by environment at end of simulation
    function void report_coverage();
        cov.report();
    endfunction
endclass

`endif
