//=============================================================
// File   : apb_generator.sv
// Layer  : Generator (directed + random stimulus)
//=============================================================
`ifndef APB_GENERATOR_SV
`define APB_GENERATOR_SV

`include "apb_transaction.sv"

class generator;
    transaction tr;
    mailbox #(transaction) gen2drv;
    event drv_done;      // driver -> generator: transfer complete
    int num_transactions;

    function new(mailbox #(transaction) gen2drv, event drv_done);
        this.gen2drv  = gen2drv;
        this.drv_done = drv_done;
    endfunction

    // Helper task for directed stimulus
    task send(bit [7:0] addr, bit write, bit [31:0] data = 0);
        tr = new();
        tr.paddr  = addr;
        tr.pwrite = write;
        tr.pwdata = data;
        tr.display("GEN-DIRECTED");
        gen2drv.put(tr.copy());
        @(drv_done);
    endtask

    task run();
        //-----------------------------------------------------
        // Directed test cases (Lab Section 5 requirements)
        //-----------------------------------------------------
        send(8'h10, 0);                  // 1. Read from 0x10
        send(8'h20, 1, 32'hDEAD_BEEF);    // 2. Write to 0x20
        send(8'h50, 0);                  // 3. Read from range 64-127
        send(8'h5F, 0);                  //    another addr in 64-127
        send(8'hA0, 1, 32'h1234_5678);    // 4. Write to range 128-191
        send(8'h30, 1, 32'h0000_0000);    // 5. Write zero data
        send(8'h31, 1, 32'hCAFE_BABE);    // 6. Write non-zero data

        // 7. Consecutive read transactions
        send(8'h40, 0);
        send(8'h41, 0);
        send(8'h42, 0);

        // 8. Consecutive write transactions
        send(8'h60, 1, 32'h1111_1111);
        send(8'h61, 1, 32'h2222_2222);
        send(8'h62, 1, 32'h3333_3333);

        // 9 & 10. Wait-state / Ready transactions are naturally
        // exercised by apb_slave's randomized wait-state logic
        // on every transaction above and below.

        // Directed address-range / error-path closure
        send(8'h00, 1, 32'hAAAA_AAAA);    // addr_min (low bin edge)
        send(8'hFF, 0);                   // addr_max / triggers PSLVERR path
        send(8'hFF, 1, 32'h9999_9999);    // write to error address
        send(8'hC5, 1, 32'h5555_5555);    // upper range write
        send(8'hC6, 0);                   // upper range read

        //-----------------------------------------------------
        // Randomized stimulus to fill remaining bins/crosses
        //-----------------------------------------------------
        repeat (num_transactions) begin
            tr = new();
            tr.randomize_tr();
            tr.display("GEN-RANDOM");
            gen2drv.put(tr.copy());
            @(drv_done);
        end

        $display("[GEN] Completed directed + %0d random transactions",
                   num_transactions);
    endtask
endclass

`endif
