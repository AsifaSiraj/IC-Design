//=============================================================
// File   : apb_test.sv
// Layer  : Test (configures and runs the environment)
//=============================================================
`ifndef APB_TEST_SV
`define APB_TEST_SV

`include "apb_environment.sv"

class test;
    environment env;
    virtual apb_if vif;

    function new(virtual apb_if vif);
        this.vif = vif;
        env = new(vif);
    endfunction

    task run();
        env.gen.num_transactions = 100;   // random transactions after directed set
        env.run();
    endtask
endclass

`endif
