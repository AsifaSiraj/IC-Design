//=============================================================
// File        : apb_slave.sv
// Description : APB Slave Memory (Design Under Test)
//               - 256 x 32-bit memory
//               - Randomly inserts wait states (PREADY=0) to allow
//                 functional coverage of the Slave-Ready coverpoint
//               - Asserts PSLVERR on reserved address (0xFF) to allow
//                 Error-Response coverage (optional requirement)
//=============================================================

module apb_slave (
    input  logic        PCLK,
    input  logic        PRESETn,
    input  logic        PSEL,
    input  logic        PENABLE,
    input  logic        PWRITE,
    input  logic [7:0]  PADDR,
    input  logic [31:0] PWDATA,
    output logic [31:0] PRDATA,
    output logic        PREADY,
    output logic        PSLVERR
);

    logic [31:0] mem [0:255];
    integer i;

    int unsigned wait_cnt;
    logic        access_start;
    logic        penable_d;

    //---------------------------------------------------------
    // Detect start of a new ACCESS phase (SETUP -> ACCESS edge)
    //---------------------------------------------------------
    always_ff @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) penable_d <= 1'b0;
        else          penable_d <= PENABLE;
    end
    assign access_start = PSEL && PENABLE && !penable_d;

    //---------------------------------------------------------
    // Random wait-state generation (0, 1, or 2 extra cycles)
    //---------------------------------------------------------
    always_ff @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) begin
            wait_cnt <= 0;
        end
        else if (access_start) begin
            // ~40% chance of inserting 1-2 wait states
            wait_cnt <= ($urandom_range(0,9) < 4) ? $urandom_range(1,2) : 0;
        end
        else if (PSEL && PENABLE && wait_cnt != 0) begin
            wait_cnt <= wait_cnt - 1;
        end
    end

    assign PREADY = (PSEL && PENABLE) ? (wait_cnt == 0) : 1'b1;

    //---------------------------------------------------------
    // Error response: address 0xFF treated as reserved/error
    //---------------------------------------------------------
    assign PSLVERR = (PSEL && PENABLE && PREADY && (PADDR == 8'hFF)) ? 1'b1 : 1'b0;

    //---------------------------------------------------------
    // Synchronous write / reset
    //---------------------------------------------------------
    always_ff @(posedge PCLK or negedge PRESETn) begin
        if (!PRESETn) begin
            for (i = 0; i < 256; i = i + 1)
                mem[i] <= 32'h0000_0000;
        end
        else if (PSEL && PENABLE && PWRITE && PREADY && !PSLVERR) begin
            mem[PADDR] <= PWDATA;
        end
    end

    //---------------------------------------------------------
    // Read data (combinational)
    //---------------------------------------------------------
    always_comb begin
        if (PSEL && !PWRITE)
            PRDATA = mem[PADDR];
        else
            PRDATA = 32'h0000_0000;
    end

endmodule
