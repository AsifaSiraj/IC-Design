//=============================================================
// File   : apb_environment.sv
// Layer  : Environment (connects generator, driver, monitor, scoreboard)
//=============================================================
`ifndef APB_ENVIRONMENT_SV
`define APB_ENVIRONMENT_SV

`include "apb_generator.sv"
`include "apb_driver.sv"
`include "apb_monitor.sv"
`include "apb_scoreboard.sv"

class environment;
    generator  gen;
    driver     drv;
    monitor    mon;
    scoreboard scb;

    mailbox #(transaction) gen2drv;
    mailbox #(transaction) mon2scb;
    event drv_done;

    virtual apb_if vif;

    function new(virtual apb_if vif);
        this.vif = vif;
        gen2drv  = new();
        mon2scb  = new();

        gen = new(gen2drv, drv_done);
        drv = new(vif, gen2drv, drv_done);
        mon = new(vif, mon2scb);      // coverage lives inside monitor
        scb = new(mon2scb);
    endfunction

    task run();
        drv.reset();
        fork
            gen.run();
            drv.run();
            mon.run();
            scb.run();
        join_any

        scb.report();
        mon.report_coverage();        // print functional coverage report
    endtask
endclass

`endif
