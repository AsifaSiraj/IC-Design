//=============================================================
// File   : apb_coverage.sv
// Layer  : Coverage (functional coverage collector)
//=============================================================
`ifndef APB_COVERAGE_SV
`define APB_COVERAGE_SV

`include "apb_transaction.sv"

class coverage;
    mailbox #(transaction) mon2cov;
    transaction tr;

    // ---- history for sequence/transition coverage ----
    bit        first_sample = 1'b1;
    bit        last_write;
    bit [7:0]  last_addr;

    // ---------------------------------------------------
    // Covergroup : sampled once per completed APB transfer
    // ---------------------------------------------------
    covergroup apb_cg;
        option.per_instance = 1;
        option.name         = "apb_functional_cg";

        // ---- Direction coverage ----
        cp_write : coverpoint tr.pwrite {
            bins write = {1};
            bins read  = {0};
        }

        // ---- Address coverage ----
        cp_addr : coverpoint tr.paddr {
            bins addr_min      = {0};
            bins addr_max      = {255};
            bins addr_low      = {[1:63]};
            bins addr_mid_low  = {[64:127]};
            bins addr_mid_high = {[128:191]};
            bins addr_high     = {[192:254]};
        }

        // ---- Write-data coverage ----
        cp_wdata : coverpoint tr.pwdata iff (tr.pwrite) {
            bins all_zero   = {32'h0000_0000};
            bins all_ones   = {32'hFFFF_FFFF};
            bins low_range  = {[32'h0000_0001 : 32'h3FFF_FFFF]};
            bins mid_range  = {[32'h4000_0000 : 32'hBFFF_FFFF]};
            bins high_range = {[32'hC000_0000 : 32'hFFFF_FFFE]};
        }

        // ---- Read-data coverage ----
        cp_rdata : coverpoint tr.prdata iff (!tr.pwrite) {
            bins all_zero = {32'h0000_0000};
            bins all_ones = {32'hFFFF_FFFF};
            bins others   = default;
        }

        // ---- Cross: which addresses get read vs written ----
        cross_addr_write : cross cp_addr, cp_write;

        // ---- Back-to-back operation sequence coverage ----
        cp_seq : coverpoint {last_write, tr.pwrite} iff (!first_sample) {
            bins write_after_write = {2'b11};
            bins read_after_write  = {2'b10};
            bins write_after_read  = {2'b01};
            bins read_after_read   = {2'b00};
        }

        // ---- Repeated-address access coverage ----
        cp_same_addr : coverpoint (tr.paddr == last_addr) iff (!first_sample) {
            bins same_addr = {1};
            bins diff_addr = {0};
        }

        // ---- Write followed immediately by read to SAME address ----
        cp_wr_then_rd_same_addr :
            coverpoint (last_write && !tr.pwrite && (tr.paddr == last_addr))
            iff (!first_sample) {
            bins hit = {1};
        }
    endgroup

    function new(mailbox #(transaction) mon2cov);
        this.mon2cov = mon2cov;
        apb_cg = new();
    endfunction

    task run();
        forever begin
            mon2cov.get(tr);

            apb_cg.sample();

            // update history AFTER sampling
            last_write   = tr.pwrite;
            last_addr    = tr.paddr;
            first_sample = 1'b0;
        end
    endtask

    function void report();
        $display("=====================================================");
        $display("FUNCTIONAL COVERAGE REPORT");
        $display("  Overall Coverage = %0.2f %%", apb_cg.get_coverage());
        $display("  cp_write         = %0.2f %%", apb_cg.cp_write.get_coverage());
        $display("  cp_addr          = %0.2f %%", apb_cg.cp_addr.get_coverage());
        $display("  cp_wdata         = %0.2f %%", apb_cg.cp_wdata.get_coverage());
        $display("  cp_rdata         = %0.2f %%", apb_cg.cp_rdata.get_coverage());
        $display("  cross_addr_write = %0.2f %%", apb_cg.cross_addr_write.get_coverage());
        $display("  cp_seq           = %0.2f %%", apb_cg.cp_seq.get_coverage());
        $display("  cp_same_addr     = %0.2f %%", apb_cg.cp_same_addr.get_coverage());
        $display("=====================================================");
    endfunction
endclass

`endif
