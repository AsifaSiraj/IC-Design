//=============================================================
// File   : apb_environment.sv  (MODIFIED)
//=============================================================
`ifndef APB_ENVIRONMENT_SV
`define APB_ENVIRONMENT_SV

`include "apb_generator.sv"
`include "apb_driver.sv"
`include "apb_monitor.sv"
`include "apb_scoreboard.sv"
`include "apb_coverage.sv"          // <-- NEW

class environment;
    generator  gen;
    driver     drv;
    monitor    mon;
    scoreboard scb;
    coverage   cov;                 // <-- NEW

    mailbox #(transaction) gen2drv;
    mailbox #(transaction) mon2scb;
    mailbox #(transaction) mon2cov; // <-- NEW
    event drv_done;

    virtual apb_if vif;

    function new(virtual apb_if vif);
        this.vif = vif;
        gen2drv  = new();
        mon2scb  = new();
        mon2cov  = new();            // <-- NEW

        gen = new(gen2drv, drv_done);
        drv = new(vif, gen2drv, drv_done);
        mon = new(vif, mon2scb, mon2cov);  // <-- pass both mailboxes
        scb = new(mon2scb);
        cov = new(mon2cov);          // <-- NEW
    endfunction

    task run();
        drv.reset();
        fork
            gen.run();
            drv.run();
            mon.run();
            scb.run();
            cov.run();               // <-- NEW
        join_any
        scb.report();
        cov.report();                // <-- NEW
    endtask
endclass

`endif