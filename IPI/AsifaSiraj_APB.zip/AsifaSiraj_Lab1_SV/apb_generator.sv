//=============================================================
// File   : apb_generator.sv
// Layer  : Generator (stimulus)
//=============================================================
`ifndef APB_GENERATOR_SV
`define APB_GENERATOR_SV

`include "apb_transaction.sv"

class generator;
    transaction tr;
    mailbox #(transaction) gen2drv;
    event drv_done;      // driver -> generator: transfer complete
    int num_transactions;

    function new(mailbox #(transaction) gen2drv, event drv_done);
        this.gen2drv  = gen2drv;
        this.drv_done = drv_done;
    endfunction

    task run();
        transaction wtr, rtr;

        // ---------- Random stimulus ----------
        repeat (num_transactions) begin
            tr = new();
            tr.randomize_tr();
            tr.display("GEN");
            gen2drv.put(tr.copy());
            @(drv_done);
        end

        // ---------- Directed: write then read same address ----------
        repeat (20) begin
            bit [7:0] addr = $urandom_range(0,255);

            wtr = new();
            wtr.paddr  = addr;
            wtr.pwrite = 1;
            wtr.pwdata = $urandom;
            gen2drv.put(wtr);
            @(drv_done);

            rtr = new();
            rtr.paddr  = addr;
            rtr.pwrite = 0;
            gen2drv.put(rtr);
            @(drv_done);
        end

        $display("[GEN] Completed generating %0d random + 40 directed transactions",
                   num_transactions);
    endtask
endclass

`endif