//=============================================================
// File   : apb_monitor.sv  (MODIFIED)
//=============================================================
`ifndef APB_MONITOR_SV
`define APB_MONITOR_SV

`include "apb_transaction.sv"

class monitor;
    virtual apb_if vif;
    mailbox #(transaction) mon2scb;
    mailbox #(transaction) mon2cov;      // <-- NEW
    transaction tr;

    function new(virtual apb_if vif,
                 mailbox #(transaction) mon2scb,
                 mailbox #(transaction) mon2cov); // <-- NEW arg
        this.vif     = vif;
        this.mon2scb = mon2scb;
        this.mon2cov = mon2cov;
    endfunction

    task run();
        forever begin
            @(posedge vif.PCLK);
            if (vif.PSEL && vif.PENABLE && vif.PREADY) begin
                tr = new();
                tr.paddr  = vif.PADDR;
                tr.pwrite = vif.PWRITE;
                if (vif.PWRITE)
                    tr.pwdata = vif.PWDATA;
                else
                    tr.prdata = vif.PRDATA;

                tr.display("MON");

                mon2scb.put(tr.copy());   // to scoreboard
                mon2cov.put(tr.copy());   // to coverage
            end
        end
    endtask
endclass

`endif