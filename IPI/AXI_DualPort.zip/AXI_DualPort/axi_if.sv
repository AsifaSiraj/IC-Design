//=====================================================
// File : axi_if.sv
// Desc : AXI4 interface with master/slave modports
//=====================================================
`include "axi_pkg.sv"

interface axi_if
    import axi_pkg::*;
(
    input logic clk,
    input logic rst_n
);

    // ---------------- Write Address Channel ----------------
    logic [ID_WIDTH-1:0]    awid;
    logic [ADDR_WIDTH-1:0]  awaddr;
    logic [LEN_WIDTH-1:0]   awlen;
    logic [SIZE_WIDTH-1:0]  awsize;
    logic [BURST_WIDTH-1:0] awburst;
    logic                   awvalid;
    logic                   awready;

    // ---------------- Write Data Channel --------------------
    logic [DATA_WIDTH-1:0] wdata;
    logic [STRB_WIDTH-1:0] wstrb;
    logic                  wlast;
    logic                  wvalid;
    logic                  wready;

    // ---------------- Write Response Channel ----------------
    logic [ID_WIDTH-1:0]   bid;
    logic [RESP_WIDTH-1:0] bresp;
    logic                  bvalid;
    logic                  bready;

    // ---------------- Read Address Channel -------------------
    logic [ID_WIDTH-1:0]    arid;
    logic [ADDR_WIDTH-1:0]  araddr;
    logic [LEN_WIDTH-1:0]   arlen;
    logic [SIZE_WIDTH-1:0]  arsize;
    logic [BURST_WIDTH-1:0] arburst;
    logic                   arvalid;
    logic                   arready;

    // ---------------- Read Data Channel -----------------------
    logic [ID_WIDTH-1:0]   rid;
    logic [DATA_WIDTH-1:0] rdata;
    logic [RESP_WIDTH-1:0] rresp;
    logic                  rlast;
    logic                  rvalid;
    logic                  rready;

    modport master (
        output awid, awaddr, awlen, awsize, awburst, awvalid,
        input  awready,
        output wdata, wstrb, wlast, wvalid,
        input  wready,
        input  bid, bresp, bvalid,
        output bready,
        output arid, araddr, arlen, arsize, arburst, arvalid,
        input  arready,
        input  rid, rdata, rresp, rlast, rvalid,
        output rready
    );

    modport slave (
        input  awid, awaddr, awlen, awsize, awburst, awvalid,
        output awready,
        input  wdata, wstrb, wlast, wvalid,
        output wready,
        output bid, bresp, bvalid,
        input  bready,
        input  arid, araddr, arlen, arsize, arburst, arvalid,
        output arready,
        output rid, rdata, rresp, rlast, rvalid,
        input  rready
    );

endinterface
