//=====================================================
// File : axi_dp_mem.sv
// Desc : Generic TRUE dual-port memory.
//   - Port A and Port B are each fully capable of
//     independent READ or WRITE on every clock cycle.
//   - Detects address collisions between the two ports
//     and resolves them deterministically instead of
//     leaving behavior racy/undefined:
//
//     * WRITE-WRITE collision (both ports write same addr)
//         -> Port A wins arbitration (priority), warning issued
//
//     * READ-WRITE collision (one port reads while the
//       other writes the same addr in the same cycle)
//         -> "write-first" forwarding: the reading port
//            receives the data being written this cycle
//            instead of stale memory content.
//=====================================================
module axi_dp_mem #(
    parameter int DATA_WIDTH    = 32,
    parameter int STRB_WIDTH    = DATA_WIDTH/8,
    parameter int MEM_DEPTH     = 1024,
    parameter int MEM_ADDR_BITS = $clog2(MEM_DEPTH)
)(
    input  logic clk,
    input  logic rst_n,

    // ---------------- Port A (full R/W) ----------------
    input  logic                      a_en,
    input  logic                      a_we,     // 1 = write, 0 = read
    input  logic [MEM_ADDR_BITS-1:0]  a_addr,
    input  logic [DATA_WIDTH-1:0]     a_wdata,
    input  logic [STRB_WIDTH-1:0]     a_wstrb,
    output logic [DATA_WIDTH-1:0]     a_rdata,

    // ---------------- Port B (full R/W) ----------------
    input  logic                      b_en,
    input  logic                      b_we,     // 1 = write, 0 = read
    input  logic [MEM_ADDR_BITS-1:0]  b_addr,
    input  logic [DATA_WIDTH-1:0]     b_wdata,
    input  logic [STRB_WIDTH-1:0]     b_wstrb,
    output logic [DATA_WIDTH-1:0]     b_rdata,

    // ---------------- Collision monitor (debug/verif) ---
    output logic collision_ww,    // both ports write same addr
    output logic collision_rw_a,  // A reads while B writes same addr
    output logic collision_rw_b   // B reads while A writes same addr
);

    logic [DATA_WIDTH-1:0] mem [0:MEM_DEPTH-1];

    wire same_addr = a_en && b_en && (a_addr == b_addr);

    assign collision_ww   = same_addr &&  a_we &&  b_we;
    assign collision_rw_a = same_addr && !a_we &&  b_we; // A is reading, B writing
    assign collision_rw_b = same_addr &&  a_we && !b_we; // B is reading, A writing

    // Byte-lane merge helper (applies write strobes)
    function automatic [DATA_WIDTH-1:0] merge_wr
        (input [DATA_WIDTH-1:0] old_d,
         input [DATA_WIDTH-1:0] new_d,
         input [STRB_WIDTH-1:0] strb);
        int i;
        begin
            merge_wr = old_d;
            for (i = 0; i < STRB_WIDTH; i++)
                if (strb[i]) merge_wr[i*8 +: 8] = new_d[i*8 +: 8];
        end
    endfunction

    // ------------------------------------------------------------
    // Combinational READ with write-first forwarding on collision
    // ------------------------------------------------------------
    always_comb begin
        if (a_en && !a_we) begin
            a_rdata = collision_rw_a ? merge_wr(mem[a_addr], b_wdata, b_wstrb)
                                      : mem[a_addr];
        end else begin
            a_rdata = mem[a_addr];
        end

        if (b_en && !b_we) begin
            b_rdata = collision_rw_b ? merge_wr(mem[b_addr], a_wdata, a_wstrb)
                                      : mem[b_addr];
        end else begin
            b_rdata = mem[b_addr];
        end
    end

    // ------------------------------------------------------------
    // Synchronous WRITE with WW-collision arbitration (A wins)
    // ------------------------------------------------------------
    always_ff @(posedge clk) begin
        if (collision_ww) begin
            mem[a_addr] <= merge_wr(mem[a_addr], a_wdata, a_wstrb);
`ifndef SYNTHESIS
            $display("[%0t] AXI_DP_MEM: WRITE-WRITE collision @0x%0h -> Port A priority",
                      $time, a_addr);
`endif
        end else begin
            if (a_en && a_we)
                mem[a_addr] <= merge_wr(mem[a_addr], a_wdata, a_wstrb);
            if (b_en && b_we)
                mem[b_addr] <= merge_wr(mem[b_addr], b_wdata, b_wstrb);
        end

`ifndef SYNTHESIS
        if (collision_rw_a)
            $display("[%0t] AXI_DP_MEM: READ-WRITE collision @0x%0h -> Port A read forwarded from Port B write",
                      $time, a_addr);
        if (collision_rw_b)
            $display("[%0t] AXI_DP_MEM: READ-WRITE collision @0x%0h -> Port B read forwarded from Port A write",
                      $time, b_addr);
`endif
    end

endmodule
