//=====================================================
// File : axi_slave.sv
// Desc : AXI4 Slave using a TRUE dual-port memory
//        (axi_dp_mem). The write channel drives Port A,
//        the read channel drives Port B. Both ports are
//        full R/W capable at the memory level; collisions
//        between them (same address, same cycle) are
//        detected and resolved inside axi_dp_mem.
//=====================================================
`include "axi_pkg.sv"
`include "axi_dp_mem.sv"

module axi_slave
    import axi_pkg::*;
#(
    parameter int MEM_DEPTH = 1024
)
(
    input  logic clk,
    input  logic rst_n,
    axi_if.slave axi,

    // Optional collision monitor outputs (debug/verification)
    output logic collision_ww,
    output logic collision_rw_a,
    output logic collision_rw_b
);

    localparam int ADDR_LSB      = $clog2(STRB_WIDTH);
    localparam int MEM_ADDR_BITS = $clog2(MEM_DEPTH);

    // ---------------- Dual-Port Memory Instance ----------------
    logic                      a_en, a_we;
    logic [MEM_ADDR_BITS-1:0]  a_addr;
    logic [DATA_WIDTH-1:0]     a_wdata, a_rdata;
    logic [STRB_WIDTH-1:0]     a_wstrb;

    logic                      b_en, b_we;
    logic [MEM_ADDR_BITS-1:0]  b_addr;
    logic [DATA_WIDTH-1:0]     b_wdata, b_rdata;
    logic [STRB_WIDTH-1:0]     b_wstrb;

    axi_dp_mem #(
        .DATA_WIDTH   (DATA_WIDTH),
        .STRB_WIDTH   (STRB_WIDTH),
        .MEM_DEPTH    (MEM_DEPTH),
        .MEM_ADDR_BITS(MEM_ADDR_BITS)
    ) u_dp_mem (
        .clk  (clk),
        .rst_n(rst_n),

        .a_en   (a_en),
        .a_we   (a_we),
        .a_addr (a_addr),
        .a_wdata(a_wdata),
        .a_wstrb(a_wstrb),
        .a_rdata(a_rdata),

        .b_en   (b_en),
        .b_we   (b_we),
        .b_addr (b_addr),
        .b_wdata(b_wdata),
        .b_wstrb(b_wstrb),
        .b_rdata(b_rdata),

        .collision_ww  (collision_ww),
        .collision_rw_a(collision_rw_a),
        .collision_rw_b(collision_rw_b)
    );

    //======================================================
    // WRITE CHANNEL FSM  (drives dual-port memory Port A)
    //======================================================
    typedef enum logic [1:0] {W_IDLE, W_DATA, W_RESP} wr_state_e;
    wr_state_e wr_state, wr_state_n;

    logic [ADDR_WIDTH-1:0]  waddr, waddr_n;
    logic [LEN_WIDTH-1:0]   wlen_cnt, wlen_cnt_n;
    logic [BURST_WIDTH-1:0] wburst_type, wburst_type_n;
    logic [ID_WIDTH-1:0]    wid_reg, wid_reg_n;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_state    <= W_IDLE;
            waddr       <= '0;
            wlen_cnt    <= '0;
            wburst_type <= BURST_INCR;
            wid_reg     <= '0;
        end else begin
            wr_state    <= wr_state_n;
            waddr       <= waddr_n;
            wlen_cnt    <= wlen_cnt_n;
            wburst_type <= wburst_type_n;
            wid_reg     <= wid_reg_n;
        end
    end

    always_comb begin
        wr_state_n    = wr_state;
        waddr_n       = waddr;
        wlen_cnt_n    = wlen_cnt;
        wburst_type_n = wburst_type;
        wid_reg_n     = wid_reg;

        axi.awready = 1'b0;
        axi.wready  = 1'b0;
        axi.bvalid  = 1'b0;
        axi.bresp   = RESP_OKAY;
        axi.bid     = wid_reg;

        // Port A defaults
        a_en    = 1'b0;
        a_we    = 1'b1;   // this channel only ever writes
        a_addr  = waddr[MEM_ADDR_BITS+ADDR_LSB-1:ADDR_LSB];
        a_wdata = axi.wdata;
        a_wstrb = axi.wstrb;

        case (wr_state)
            W_IDLE: begin
                axi.awready = 1'b1;
                if (axi.awvalid && axi.awready) begin
                    waddr_n       = axi.awaddr;
                    wlen_cnt_n    = axi.awlen;
                    wburst_type_n = axi.awburst;
                    wid_reg_n     = axi.awid;
                    wr_state_n    = W_DATA;
                end
            end

            W_DATA: begin
                axi.wready = 1'b1;
                a_en       = axi.wvalid && axi.wready;
                if (axi.wvalid && axi.wready) begin
                    if (wlen_cnt == 0) begin
                        wr_state_n = W_RESP;
                    end else begin
                        wlen_cnt_n = wlen_cnt - 1'b1;
                        case (wburst_type)
                            BURST_FIXED: waddr_n = waddr;
                            default:     waddr_n = waddr + STRB_WIDTH;
                        endcase
                    end
                end
            end

            W_RESP: begin
                axi.bvalid = 1'b1;
                if (axi.bvalid && axi.bready)
                    wr_state_n = W_IDLE;
            end
        endcase
    end

    //======================================================
    // READ CHANNEL FSM  (drives dual-port memory Port B)
    //======================================================
    typedef enum logic [1:0] {R_IDLE, R_DATA} rd_state_e;
    rd_state_e rd_state, rd_state_n;

    logic [ADDR_WIDTH-1:0]  raddr, raddr_n;
    logic [LEN_WIDTH-1:0]   rlen_cnt, rlen_cnt_n;
    logic [BURST_WIDTH-1:0] rburst_type, rburst_type_n;
    logic [ID_WIDTH-1:0]    rid_reg, rid_reg_n;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rd_state    <= R_IDLE;
            raddr       <= '0;
            rlen_cnt    <= '0;
            rburst_type <= BURST_INCR;
            rid_reg     <= '0;
        end else begin
            rd_state    <= rd_state_n;
            raddr       <= raddr_n;
            rlen_cnt    <= rlen_cnt_n;
            rburst_type <= rburst_type_n;
            rid_reg     <= rid_reg_n;
        end
    end

    always_comb begin
        rd_state_n    = rd_state;
        raddr_n       = raddr;
        rlen_cnt_n    = rlen_cnt;
        rburst_type_n = rburst_type;
        rid_reg_n     = rid_reg;

        axi.arready = 1'b0;
        axi.rvalid  = 1'b0;
        axi.rlast   = 1'b0;
        axi.rresp   = RESP_OKAY;
        axi.rid     = rid_reg;

        // Port B defaults
        b_en    = 1'b0;
        b_we    = 1'b0;   // this channel only ever reads
        b_addr  = raddr[MEM_ADDR_BITS+ADDR_LSB-1:ADDR_LSB];
        b_wdata = '0;
        b_wstrb = '0;

        axi.rdata = b_rdata;   // includes collision forwarding when applicable

        case (rd_state)
            R_IDLE: begin
                axi.arready = 1'b1;
                if (axi.arvalid && axi.arready) begin
                    raddr_n       = axi.araddr;
                    rlen_cnt_n    = axi.arlen;
                    rburst_type_n = axi.arburst;
                    rid_reg_n     = axi.arid;
                    rd_state_n    = R_DATA;
                end
            end

            R_DATA: begin
                b_en       = 1'b1;
                axi.rvalid = 1'b1;
                axi.rlast  = (rlen_cnt == 0);
                if (axi.rvalid && axi.rready) begin
                    if (rlen_cnt == 0) begin
                        rd_state_n = R_IDLE;
                    end else begin
                        rlen_cnt_n = rlen_cnt - 1'b1;
                        case (rburst_type)
                            BURST_FIXED: raddr_n = raddr;
                            default:     raddr_n = raddr + STRB_WIDTH;
                        endcase
                    end
                end
            end
        endcase
    end

endmodule
