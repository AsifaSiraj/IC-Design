//=====================================================
// File : axi_master.sv
// Desc : AXI4 Master with simple user-side FIFO-like
//        handshakes for burst read/write
//=====================================================
`include "axi_pkg.sv"

module axi_master
    import axi_pkg::*;
(
    input  logic clk,
    input  logic rst_n,

    // -------- User Write Interface --------
    input  logic                  wr_req,
    input  logic [ADDR_WIDTH-1:0] wr_addr,
    input  logic [LEN_WIDTH-1:0]  wr_len,        // burst length - 1
    input  logic [DATA_WIDTH-1:0] wr_data,
    input  logic [STRB_WIDTH-1:0] wr_strb,
    input  logic                  wr_data_valid,
    output logic                  wr_data_ready,
    output logic                  wr_done,
    output logic [RESP_WIDTH-1:0] wr_resp,

    // -------- User Read Interface ---------
    input  logic                  rd_req,
    input  logic [ADDR_WIDTH-1:0] rd_addr,
    input  logic [LEN_WIDTH-1:0]  rd_len,        // burst length - 1
    output logic [DATA_WIDTH-1:0] rd_data,
    output logic                  rd_data_valid,
    input  logic                  rd_data_ready,
    output logic                  rd_done,
    output logic [RESP_WIDTH-1:0] rd_resp,

    axi_if.master axi
);

    //======================================================
    // WRITE CHANNEL FSM
    //======================================================
    typedef enum logic [1:0] {WM_IDLE, WM_AW, WM_DATA, WM_RESP} wm_state_e;
    wm_state_e wm_state, wm_state_n;

    logic [ADDR_WIDTH-1:0] waddr_reg, waddr_reg_n;
    logic [LEN_WIDTH-1:0]  wlen_reg,  wlen_reg_n;
    logic [LEN_WIDTH-1:0]  wbeat_cnt, wbeat_cnt_n;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wm_state  <= WM_IDLE;
            waddr_reg <= '0;
            wlen_reg  <= '0;
            wbeat_cnt <= '0;
        end else begin
            wm_state  <= wm_state_n;
            waddr_reg <= waddr_reg_n;
            wlen_reg  <= wlen_reg_n;
            wbeat_cnt <= wbeat_cnt_n;
        end
    end

    always_comb begin
        wm_state_n  = wm_state;
        waddr_reg_n = waddr_reg;
        wlen_reg_n  = wlen_reg;
        wbeat_cnt_n = wbeat_cnt;

        axi.awvalid = 1'b0;
        axi.awid    = '0;
        axi.awaddr  = waddr_reg;
        axi.awlen   = wlen_reg;
        axi.awsize  = $clog2(STRB_WIDTH);
        axi.awburst = BURST_INCR;

        axi.wvalid  = 1'b0;
        axi.wdata   = wr_data;
        axi.wstrb   = wr_strb;
        axi.wlast   = (wbeat_cnt == wlen_reg);

        axi.bready  = 1'b0;

        wr_data_ready = 1'b0;
        wr_done       = 1'b0;
        wr_resp       = RESP_OKAY;

        case (wm_state)
            WM_IDLE: begin
                if (wr_req) begin
                    waddr_reg_n = wr_addr;
                    wlen_reg_n  = wr_len;
                    wbeat_cnt_n = '0;
                    wm_state_n  = WM_AW;
                end
            end

            WM_AW: begin
                axi.awvalid = 1'b1;
                if (axi.awvalid && axi.awready)
                    wm_state_n = WM_DATA;
            end

            WM_DATA: begin
                axi.wvalid    = wr_data_valid;
                wr_data_ready = axi.wready;
                if (axi.wvalid && axi.wready) begin
                    if (wbeat_cnt == wlen_reg)
                        wm_state_n = WM_RESP;
                    else
                        wbeat_cnt_n = wbeat_cnt + 1'b1;
                end
            end

            WM_RESP: begin
                axi.bready = 1'b1;
                if (axi.bvalid && axi.bready) begin
                    wr_resp    = axi.bresp;
                    wr_done    = 1'b1;
                    wm_state_n = WM_IDLE;
                end
            end
        endcase
    end

    //======================================================
    // READ CHANNEL FSM
    //======================================================
    typedef enum logic [1:0] {RM_IDLE, RM_AR, RM_DATA} rm_state_e;
    rm_state_e rm_state, rm_state_n;

    logic [ADDR_WIDTH-1:0] raddr_reg, raddr_reg_n;
    logic [LEN_WIDTH-1:0]  rlen_reg,  rlen_reg_n;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rm_state  <= RM_IDLE;
            raddr_reg <= '0;
            rlen_reg  <= '0;
        end else begin
            rm_state  <= rm_state_n;
            raddr_reg <= raddr_reg_n;
            rlen_reg  <= rlen_reg_n;
        end
    end

    always_comb begin
        rm_state_n  = rm_state;
        raddr_reg_n = raddr_reg;
        rlen_reg_n  = rlen_reg;

        axi.arvalid = 1'b0;
        axi.arid    = '0;
        axi.araddr  = raddr_reg;
        axi.arlen   = rlen_reg;
        axi.arsize  = $clog2(STRB_WIDTH);
        axi.arburst = BURST_INCR;

        axi.rready  = 1'b0;

        rd_data       = axi.rdata;
        rd_data_valid = 1'b0;
        rd_done       = 1'b0;
        rd_resp       = RESP_OKAY;

        case (rm_state)
            RM_IDLE: begin
                if (rd_req) begin
                    raddr_reg_n = rd_addr;
                    rlen_reg_n  = rd_len;
                    rm_state_n  = RM_AR;
                end
            end

            RM_AR: begin
                axi.arvalid = 1'b1;
                if (axi.arvalid && axi.arready)
                    rm_state_n = RM_DATA;
            end

            RM_DATA: begin
                axi.rready    = rd_data_ready;
                rd_data_valid = axi.rvalid;
                if (axi.rvalid && axi.rready) begin
                    rd_resp = axi.rresp;
                    if (axi.rlast) begin
                        rd_done    = 1'b1;
                        rm_state_n = RM_IDLE;
                    end
                end
            end
        endcase
    end

endmodule
