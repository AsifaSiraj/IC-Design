//=====================================================
// File : axi_pkg.sv
// Desc : Common AXI4 parameters and type definitions
//=====================================================
package axi_pkg;

    parameter int ADDR_WIDTH  = 32;
    parameter int DATA_WIDTH  = 32;
    parameter int ID_WIDTH    = 4;
    parameter int STRB_WIDTH  = DATA_WIDTH/8;
    parameter int LEN_WIDTH   = 8;
    parameter int SIZE_WIDTH  = 3;
    parameter int BURST_WIDTH = 2;
    parameter int RESP_WIDTH  = 2;

    typedef enum logic [1:0] {
        BURST_FIXED = 2'b00,
        BURST_INCR  = 2'b01,
        BURST_WRAP  = 2'b10
    } burst_type_e;

    typedef enum logic [1:0] {
        RESP_OKAY   = 2'b00,
        RESP_EXOKAY = 2'b01,
        RESP_SLVERR = 2'b10,
        RESP_DECERR = 2'b11
    } resp_type_e;

endpackage
