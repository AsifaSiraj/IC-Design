//=====================================================
// File : tb_axi.sv
// Desc : Testbench ? includes a dedicated test that
//        drives write & read to the SAME address at the
//        same time to exercise the dual-port collision
//        detection/resolution logic.
//=====================================================
`include "axi_pkg.sv"
`include "axi_if.sv"
`include "axi_master.sv"
`include "axi_dp_mem.sv"
`include "axi_slave.sv"

module tb_axi;
    import axi_pkg::*;

    logic clk = 0;
    logic rst_n;

    always #5 clk = ~clk;

    axi_if u_if (.clk(clk), .rst_n(rst_n));

    logic wr_req, rd_req;
    logic [ADDR_WIDTH-1:0] wr_addr, rd_addr;
    logic [LEN_WIDTH-1:0]  wr_len,  rd_len;
    logic [DATA_WIDTH-1:0] wr_data, rd_data;
    logic [STRB_WIDTH-1:0] wr_strb;
    logic wr_data_valid, wr_data_ready, wr_done;
    logic rd_data_valid, rd_data_ready, rd_done;
    logic [RESP_WIDTH-1:0] wr_resp, rd_resp;

    logic collision_ww, collision_rw_a, collision_rw_b;

    axi_master u_master (
        .clk(clk), .rst_n(rst_n),
        .wr_req(wr_req), .wr_addr(wr_addr), .wr_len(wr_len),
        .wr_data(wr_data), .wr_strb(wr_strb),
        .wr_data_valid(wr_data_valid), .wr_data_ready(wr_data_ready),
        .wr_done(wr_done), .wr_resp(wr_resp),
        .rd_req(rd_req), .rd_addr(rd_addr), .rd_len(rd_len),
        .rd_data(rd_data), .rd_data_valid(rd_data_valid),
        .rd_data_ready(rd_data_ready),
        .rd_done(rd_done), .rd_resp(rd_resp),
        .axi(u_if.master)
    );

    axi_slave #(.MEM_DEPTH(1024)) u_slave (
        .clk(clk), .rst_n(rst_n),
        .axi(u_if.slave),
        .collision_ww  (collision_ww),
        .collision_rw_a(collision_rw_a),
        .collision_rw_b(collision_rw_b)
    );

    // Simple collision monitor
    always @(posedge clk) begin
        if (collision_ww)
            $display("[%0t] TB MONITOR: WW collision flagged", $time);
        if (collision_rw_a || collision_rw_b)
            $display("[%0t] TB MONITOR: RW collision flagged (a=%0b b=%0b)",
                      $time, collision_rw_a, collision_rw_b);
    end

    initial begin
        rst_n = 0;
        wr_req = 0; rd_req = 0;
        wr_data_valid = 0;
        rd_data_ready = 1;
        wr_addr = 0; wr_len = 0; wr_data = 0; wr_strb = '1;
        rd_addr = 0; rd_len = 0;

        repeat (5) @(posedge clk);
        rst_n = 1;
        repeat (5) @(posedge clk);

        write_burst(32'h0000_0000, 4, 32'hAAAA_0000);
        read_burst (32'h0000_0000, 4);

        // Concurrent access, DIFFERENT addresses -> no collision
        fork
            write_burst(32'h0000_0040, 4, 32'h5555_0000);
            read_burst (32'h0000_0000, 4);
        join

        repeat (5) @(posedge clk);

        // Concurrent access, SAME address -> collision path exercised
        // (write-first forwarding expected on the read side)
        fork
            write_burst(32'h0000_0000, 4, 32'hCAFE_0000);
            read_burst (32'h0000_0000, 4);
        join

        repeat (20) @(posedge clk);
        $finish;
    end

    task automatic write_burst(input [ADDR_WIDTH-1:0] addr,
                                input int len,
                                input [DATA_WIDTH-1:0] base_data);
        int i;
        begin
            wr_addr = addr;
            wr_len  = len - 1;
            wr_req  = 1;
            @(posedge clk);
            wr_req = 0;

            for (i = 0; i < len; i++) begin
                wr_data = base_data + i;
                wr_strb = '1;
                wr_data_valid = 1;
                @(posedge clk);
                while (!wr_data_ready) @(posedge clk);
                wr_data_valid = 0;
            end

            wait (wr_done);
            $display("[%0t] WRITE burst @0x%08h done, resp=%0d", $time, addr, wr_resp);
        end
    endtask

    task automatic read_burst(input [ADDR_WIDTH-1:0] addr, input int len);
        int i;
        begin
            rd_addr = addr;
            rd_len  = len - 1;
            rd_req  = 1;
            @(posedge clk);
            rd_req = 0;

            for (i = 0; i < len; i++) begin
                wait (rd_data_valid);
                $display("[%0t] READ  @0x%08h data[%0d] = %h",
                          $time, addr, i, rd_data);
                @(posedge clk);
            end

            wait (rd_done);
            $display("[%0t] READ burst @0x%08h done, resp=%0d", $time, addr, rd_resp);
        end
    endtask

endmodule
