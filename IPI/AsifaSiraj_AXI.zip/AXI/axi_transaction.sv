//=============================================================
// File   : axi_transaction.sv
// Purpose: AXI4-Lite transaction item
//=============================================================
package axi_transaction_pkg;
    import axi_pkg::*;

    class axi_transaction;

        rand bit         is_write;   // 1 = WRITE, 0 = READ
        rand bit [31:0]  addr;       // Address (0-31)
        rand bit [31:0]  wdata;      // Write data
        bit [3:0]        wstrb = 4'hF;

        bit [31:0]       rdata;      // captured read data
        bit [1:0]        bresp;      // write response
        bit [1:0]        rresp;      // read response

        int              txn_id;

        constraint c_addr { addr inside {[0:31]}; }

        function void display(string tag = "TXN");
            if (is_write)
                $display("[%0t] %s WRITE  id=%0d addr=%0d wdata=0x%08h",
                          $time, tag, txn_id, addr, wdata);
            else
                $display("[%0t] %s READ   id=%0d addr=%0d rdata=0x%08h rresp=%0d",
                          $time, tag, txn_id, addr, rdata, rresp);
        endfunction

        function axi_transaction copy();
            axi_transaction t = new();
            t.is_write = is_write;
            t.addr     = addr;
            t.wdata    = wdata;
            t.wstrb    = wstrb;
            t.rdata    = rdata;
            t.bresp    = bresp;
            t.rresp    = rresp;
            t.txn_id   = txn_id;
            return t;
        endfunction

    endclass : axi_transaction

endpackage : axi_transaction_pkg
