//=============================================================
// File   : axi_monitor.sv
// Purpose: Passively observes bus activity and reconstructs
//          completed transactions for the scoreboard/coverage
//=============================================================
package axi_monitor_pkg;
    import axi_pkg::*;
    import axi_transaction_pkg::*;

    class axi_monitor;

        virtual axi_if             vif;
        mailbox #(axi_transaction) mon2sb;
        mailbox #(axi_transaction) mon2cov;

        function new(virtual axi_if vif,
                      mailbox #(axi_transaction) mon2sb,
                      mailbox #(axi_transaction) mon2cov);
            this.vif     = vif;
            this.mon2sb  = mon2sb;
            this.mon2cov = mon2cov;
        endfunction

        task run();
            fork
                monitor_write();
                monitor_read();
            join_none
        endtask

        task monitor_write();
            axi_transaction tr;
            forever begin
                @(posedge vif.ACLK);
                if (vif.ARESETn && vif.AWVALID && vif.AWREADY &&
                    vif.WVALID  && vif.WREADY) begin
                    tr = new();
                    tr.is_write = 1'b1;
                    tr.addr     = vif.AWADDR;
                    tr.wdata    = vif.WDATA;
                    tr.wstrb    = vif.WSTRB;

                    while (!(vif.BVALID && vif.BREADY)) @(posedge vif.ACLK);
                    tr.bresp = vif.BRESP;

                    mon2sb.put(tr.copy());
                    mon2cov.put(tr.copy());
                    tr.display("MON ");
                end
            end
        endtask

        task monitor_read();
            axi_transaction tr;
            forever begin
                @(posedge vif.ACLK);
                if (vif.ARESETn && vif.ARVALID && vif.ARREADY) begin
                    tr = new();
                    tr.is_write = 1'b0;
                    tr.addr     = vif.ARADDR;

                    while (!(vif.RVALID && vif.RREADY)) @(posedge vif.ACLK);
                    tr.rdata = vif.RDATA;
                    tr.rresp = vif.RRESP;

                    mon2sb.put(tr.copy());
                    mon2cov.put(tr.copy());
                    tr.display("MON ");
                end
            end
        endtask

    endclass : axi_monitor

endpackage : axi_monitor_pkg
