//=============================================================
// File   : axi_environment.sv
// Purpose: Top level env - agent + scoreboard + coverage
//=============================================================
package axi_environment_pkg;
    import axi_pkg::*;
    import axi_transaction_pkg::*;
    import axi_agent_pkg::*;
    import axi_scoreboard_pkg::*;
    import axi_coverage_pkg::*;

    class axi_environment;

        virtual axi_if              vif;
        axi_agent                   agent;
        axi_scoreboard              sb;
        axi_coverage                cov;

        mailbox #(axi_transaction)  mon2sb;
        mailbox #(axi_transaction)  mon2cov;

        function new(virtual axi_if vif);
            this.vif = vif;
            mon2sb   = new();
            mon2cov  = new();

            agent = new(vif, mon2sb, mon2cov);
            sb    = new(mon2sb);
            cov   = new(mon2cov);
        endfunction

        task run();
            fork
                agent.run();
                sb.run();
                cov.run();
            join_none
        endtask

    endclass : axi_environment

endpackage : axi_environment_pkg
