//=============================================================
// File   : axi_pkg.sv
// Purpose: Global parameters and response constants for AXI4-Lite
//=============================================================
package axi_pkg;

    parameter int ADDR_WIDTH = 32;
    parameter int DATA_WIDTH = 32;
    parameter int MEM_DEPTH  = 32;   // 32 words memory

    // AXI response encodings
    parameter logic [1:0] RESP_OKAY   = 2'b00;
    parameter logic [1:0] RESP_EXOKAY = 2'b01;
    parameter logic [1:0] RESP_SLVERR = 2'b10;
    parameter logic [1:0] RESP_DECERR = 2'b11;

endpackage : axi_pkg
