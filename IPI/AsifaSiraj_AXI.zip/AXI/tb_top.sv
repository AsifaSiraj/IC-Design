//=============================================================
// File   : tb_top.sv
// Purpose: Top-level testbench - clock/reset, DUT, test start
//=============================================================
`timescale 1ns/1ps

module tb_top;

    import axi_pkg::*;
    import axi_transaction_pkg::*;
    import axi_generator_pkg::*;
    import axi_driver_pkg::*;
    import axi_monitor_pkg::*;
    import axi_scoreboard_pkg::*;
    import axi_coverage_pkg::*;
    import axi_agent_pkg::*;
    import axi_environment_pkg::*;
    import axi_test_pkg::*;

    // Clock generation
    logic ACLK;
    initial ACLK = 1'b0;
    always #5 ACLK = ~ACLK;   // 100MHz clock

    // Interface instance
    axi_if vif (.ACLK(ACLK));

    // DUT instantiation
    axi_slave dut (
        .ACLK    (ACLK),
        .ARESETn (vif.ARESETn),

        .AWADDR  (vif.AWADDR),
        .AWVALID (vif.AWVALID),
        .AWREADY (vif.AWREADY),

        .WDATA   (vif.WDATA),
        .WSTRB   (vif.WSTRB),
        .WVALID  (vif.WVALID),
        .WREADY  (vif.WREADY),

        .BRESP   (vif.BRESP),
        .BVALID  (vif.BVALID),
        .BREADY  (vif.BREADY),

        .ARADDR  (vif.ARADDR),
        .ARVALID (vif.ARVALID),
        .ARREADY (vif.ARREADY),

        .RDATA   (vif.RDATA),
        .RRESP   (vif.RRESP),
        .RVALID  (vif.RVALID),
        .RREADY  (vif.RREADY)
    );

    axi_test tst;

    initial begin
        // Initialize master-driven signals
        vif.AWADDR  = 32'h0;
        vif.AWVALID = 1'b0;
        vif.WDATA   = 32'h0;
        vif.WSTRB   = 4'h0;
        vif.WVALID  = 1'b0;
        vif.BREADY  = 1'b0;
        vif.ARADDR  = 32'h0;
        vif.ARVALID = 1'b0;
        vif.RREADY  = 1'b0;

        // Global reset
        vif.apply_reset(5);

        // Build & run test
        tst = new(vif);
        tst.run();

        $display("\nSimulation Completed Successfully.");
        $finish;
    end

    // Optional simulation timeout watchdog
    initial begin
        #100000;
        $display("[TB_TOP] ERROR: Simulation timeout!");
        $finish;
    end

endmodule : tb_top
