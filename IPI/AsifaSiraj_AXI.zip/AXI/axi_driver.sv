//=============================================================
// File   : axi_driver.sv
// Purpose: Drives AXI4-Lite Write/Read handshakes on the bus
//=============================================================
package axi_driver_pkg;
    import axi_pkg::*;
    import axi_transaction_pkg::*;

    class axi_driver;

        virtual axi_if              vif;
        mailbox #(axi_transaction)  gen2drv;
        mailbox #(bit)              drv2gen;

        function new(virtual axi_if vif,
                      mailbox #(axi_transaction) gen2drv,
                      mailbox #(bit)             drv2gen);
            this.vif     = vif;
            this.gen2drv = gen2drv;
            this.drv2gen = drv2gen;
        endfunction

        // Main driver loop
        task run();
            axi_transaction tr;
            forever begin
                gen2drv.get(tr);
                wait (vif.ARESETn == 1'b1);
                if (tr.is_write)
                    do_write(tr);
                else
                    do_read(tr);
                tr.display("DRV ");
                drv2gen.put(1'b1);
            end
        endtask

        // Single AXI4-Lite Write transaction
        task do_write(axi_transaction tr);
            @(posedge vif.ACLK);
            vif.AWADDR  <= tr.addr;
            vif.AWVALID <= 1'b1;
            vif.WDATA   <= tr.wdata;
            vif.WSTRB   <= tr.wstrb;
            vif.WVALID  <= 1'b1;
            vif.BREADY  <= 1'b1;

            do @(posedge vif.ACLK); while (!(vif.AWREADY && vif.WREADY));

            vif.AWVALID <= 1'b0;
            vif.WVALID  <= 1'b0;

            while (!vif.BVALID) @(posedge vif.ACLK);
            tr.bresp = vif.BRESP;

            @(posedge vif.ACLK);
            vif.BREADY <= 1'b0;
        endtask

        // Single AXI4-Lite Read transaction
        task do_read(axi_transaction tr);
            @(posedge vif.ACLK);
            vif.ARADDR  <= tr.addr;
            vif.ARVALID <= 1'b1;
            vif.RREADY  <= 1'b1;

            do @(posedge vif.ACLK); while (!vif.ARREADY);

            vif.ARVALID <= 1'b0;

            while (!vif.RVALID) @(posedge vif.ACLK);
            tr.rdata = vif.RDATA;
            tr.rresp = vif.RRESP;

            @(posedge vif.ACLK);
            vif.RREADY <= 1'b0;
        endtask

    endclass : axi_driver

endpackage : axi_driver_pkg
