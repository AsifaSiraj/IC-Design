//=============================================================
// File   : axi_agent.sv
// Purpose: Bundles generator, driver, monitor
//=============================================================
package axi_agent_pkg;
    import axi_pkg::*;
    import axi_transaction_pkg::*;
    import axi_generator_pkg::*;
    import axi_driver_pkg::*;
    import axi_monitor_pkg::*;

    class axi_agent;

        virtual axi_if              vif;
        axi_generator                gen;
        axi_driver                   drv;
        axi_monitor                  mon;

        mailbox #(axi_transaction)   gen2drv;
        mailbox #(bit)                drv2gen;

        function new(virtual axi_if vif,
                      mailbox #(axi_transaction) mon2sb,
                      mailbox #(axi_transaction) mon2cov);
            this.vif = vif;
            gen2drv  = new();
            drv2gen  = new();

            gen = new(gen2drv, drv2gen);
            drv = new(vif, gen2drv, drv2gen);
            mon = new(vif, mon2sb, mon2cov);
        endfunction

        task run();
            fork
                drv.run();
                mon.run();
            join_none
        endtask

    endclass : axi_agent

endpackage : axi_agent_pkg
