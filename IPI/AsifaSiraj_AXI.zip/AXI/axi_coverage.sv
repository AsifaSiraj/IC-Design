//=============================================================
// File   : axi_coverage.sv
// Purpose: Functional coverage for AXI4-Lite transactions
//=============================================================
package axi_coverage_pkg;
    import axi_pkg::*;
    import axi_transaction_pkg::*;

    class axi_coverage;

        mailbox #(axi_transaction) mon2cov;
        axi_transaction tr;

        covergroup cg;
            option.per_instance = 1;

            cp_op : coverpoint tr.is_write {
                bins wr = {1};
                bins rd = {0};
            }

            cp_addr : coverpoint tr.addr {
                bins addr_bins[] = {[0:31]};
            }

            cp_wdata : coverpoint tr.wdata {
                bins zero   = {32'h0000_0000};
                bins others = default;
            }

            cp_rdata : coverpoint tr.rdata {
                bins zero   = {32'h0000_0000};
                bins others = default;
            }

            cp_bresp : coverpoint tr.bresp {
                bins okay = {RESP_OKAY};
                bins err  = default;
            }

            cp_rresp : coverpoint tr.rresp {
                bins okay = {RESP_OKAY};
                bins err  = default;
            }

            cx_op_addr  : cross cp_op, cp_addr;
            cx_op_bresp : cross cp_op, cp_bresp;
            cx_op_rresp : cross cp_op, cp_rresp;
        endgroup

        function new(mailbox #(axi_transaction) mon2cov);
            this.mon2cov = mon2cov;
            cg = new();
        endfunction

        task run();
            forever begin
                mon2cov.get(tr);
                cg.sample();
            end
        endtask

        function void report();
            $display("=========================================");
            $display(" FUNCTIONAL COVERAGE REPORT");
            $display(" Overall Coverage : %0.2f %%", cg.get_coverage());
            $display("=========================================");
        endfunction

    endclass : axi_coverage

endpackage : axi_coverage_pkg
