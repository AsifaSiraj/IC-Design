//=============================================================
// File   : axi_test.sv
// Purpose: Directed + random test-cases for the AXI4-Lite TB
//=============================================================
package axi_test_pkg;
    import axi_pkg::*;
    import axi_transaction_pkg::*;
    import axi_environment_pkg::*;

    class axi_test;

        virtual axi_if      vif;
        axi_environment     env;

        function new(virtual axi_if vif);
            this.vif = vif;
            env = new(vif);
        endfunction

        // Helper: directed write
        task send_write(bit [31:0] addr, bit [31:0] data);
            axi_transaction tr = new();
            bit dummy;
            tr.is_write = 1'b1;
            tr.addr     = addr;
            tr.wdata    = data;
            tr.wstrb    = 4'hF;
            env.agent.gen2drv.put(tr);
            env.agent.drv2gen.get(dummy);
        endtask

        // Helper: directed read
        task send_read(bit [31:0] addr);
            axi_transaction tr = new();
            bit dummy;
            tr.is_write = 1'b0;
            tr.addr     = addr;
            env.agent.gen2drv.put(tr);
            env.agent.drv2gen.get(dummy);
        endtask

        //--------------------------------------------------
        // Individual test-cases
        //--------------------------------------------------
        task test_single_write();
            $display("\n---- TEST: Single Write ----");
            send_write(5, 32'hDEAD_BEEF);
        endtask

        task test_single_read();
            $display("\n---- TEST: Single Read ----");
            send_read(5);
        endtask

        task test_multiple_writes();
            $display("\n---- TEST: Multiple Writes ----");
            for (int i = 0; i < 5; i++)
                send_write(i, (i * 4) + 1);
        endtask

        task test_multiple_reads();
            $display("\n---- TEST: Multiple Reads ----");
            for (int i = 0; i < 5; i++)
                send_read(i);
        endtask

        task test_random();
            $display("\n---- TEST: Random Read/Write ----");
            env.agent.gen.run(10);
        endtask

        task test_reset();
            $display("\n---- TEST: Reset Test ----");
            send_write(10, 32'hCAFE_F00D);
            $display("[TEST] Applying reset pulse ...");
            vif.apply_reset(5);
            $display("[TEST] Reset released, checking data retention");
            send_read(10);
        endtask

        task test_boundary();
            $display("\n---- TEST: Boundary Address Test ----");
            send_write(0,  32'h1111_1111);
            send_read (0);
            send_write(31, 32'hFFFF_FFFF);
            send_read (31);
        endtask

        //--------------------------------------------------
        // Master run - executes all test-cases in sequence
        //--------------------------------------------------
        task run();
            env.run();   // start background agent/scoreboard/coverage

            test_single_write();
            test_single_read();
            test_multiple_writes();
            test_multiple_reads();
            test_random();
            test_reset();
            test_boundary();

            #100; // allow last transactions to flush through monitor/scoreboard

            env.sb.report();
            env.cov.report();
            print_final_summary();
        endtask

        function void print_final_summary();
            $display("\n=========================================");
            $display(" FINAL SIMULATION SUMMARY");
            $display(" TOTAL TESTS         : %0d", env.sb.total_count);
            $display(" PASSED              : %0d", env.sb.pass_count);
            $display(" FAILED              : %0d", env.sb.fail_count);
            $display(" FUNCTIONAL COVERAGE : %0.2f %%", env.cov.cg.get_coverage());
            if (env.sb.fail_count == 0)
                $display(" STATUS : ALL TESTS PASSED");
            else
                $display(" STATUS : SOME TESTS FAILED");
            $display("=========================================");
        endfunction

    endclass : axi_test

endpackage : axi_test_pkg
