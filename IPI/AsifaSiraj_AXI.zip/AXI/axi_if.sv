//=============================================================
// File   : axi_if.sv
// Purpose: AXI4-Lite interface (AW, W, B, AR, R channels)
//=============================================================
interface axi_if (input logic ACLK);

    // Reset generated/controlled internally so classes & TB
    // can call apply_reset() without multiple-driver conflicts.
    logic ARESETn;

    // Write Address Channel
    logic [31:0] AWADDR;
    logic        AWVALID;
    logic        AWREADY;

    // Write Data Channel
    logic [31:0] WDATA;
    logic [3:0]  WSTRB;
    logic        WVALID;
    logic        WREADY;

    // Write Response Channel
    logic [1:0]  BRESP;
    logic        BVALID;
    logic        BREADY;

    // Read Address Channel
    logic [31:0] ARADDR;
    logic        ARVALID;
    logic        ARREADY;

    // Read Data Channel
    logic [31:0] RDATA;
    logic [1:0]  RRESP;
    logic        RVALID;
    logic        RREADY;

    initial ARESETn = 1'b0;

    // Task used by TB/Test to apply reset pulse
    task automatic apply_reset(int cycles);
        ARESETn = 1'b0;
        repeat (cycles) @(posedge ACLK);
        ARESETn = 1'b1;
        @(posedge ACLK);
    endtask

endinterface : axi_if
