//=============================================================
// File   : axi_generator.sv
// Purpose: Random transaction generator
//=============================================================
package axi_generator_pkg;
    import axi_pkg::*;
    import axi_transaction_pkg::*;

    class axi_generator;

        mailbox #(axi_transaction) gen2drv;
        mailbox #(bit)             drv2gen;
        int                        txn_count;

        function new(mailbox #(axi_transaction) gen2drv,
                      mailbox #(bit)             drv2gen);
            this.gen2drv   = gen2drv;
            this.drv2gen   = drv2gen;
            this.txn_count = 0;
        endfunction

        // Generate 'num' random read/write transactions
        task run(int num);
            axi_transaction tr;
            bit dummy;
            repeat (num) begin
                tr = new();
                if (!tr.randomize())
                    $display("[GENERATOR] ERROR: randomize failed");
                tr.txn_id = txn_count++;
                gen2drv.put(tr);
                drv2gen.get(dummy);   // wait for driver to finish
            end
        endtask

    endclass : axi_generator

endpackage : axi_generator_pkg
