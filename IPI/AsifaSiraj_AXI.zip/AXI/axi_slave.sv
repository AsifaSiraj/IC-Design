//=============================================================
// File   : axi_slave.sv
// Purpose: Simple 32x32 memory-mapped AXI4-Lite slave
//          No bursts, no IDs, no outstanding, no pipelining
//=============================================================
module axi_slave (
    input  logic        ACLK,
    input  logic        ARESETn,

    // Write Address Channel
    input  logic [31:0] AWADDR,
    input  logic        AWVALID,
    output logic        AWREADY,

    // Write Data Channel
    input  logic [31:0] WDATA,
    input  logic [3:0]  WSTRB,
    input  logic        WVALID,
    output logic        WREADY,

    // Write Response Channel
    output logic [1:0]  BRESP,
    output logic        BVALID,
    input  logic        BREADY,

    // Read Address Channel
    input  logic [31:0] ARADDR,
    input  logic        ARVALID,
    output logic        ARREADY,

    // Read Data Channel
    output logic [31:0] RDATA,
    output logic [1:0]  RRESP,
    output logic        RVALID,
    input  logic        RREADY
);

    import axi_pkg::*;

    typedef enum logic [1:0] {S_IDLE, S_WRITE_RESP, S_READ_DATA} state_e;
    state_e state;

    // Memory array - single driver: always_ff block only
    logic [DATA_WIDTH-1:0] mem [0:MEM_DEPTH-1];

    // Combinational ready generation (slave always ready when idle)
    assign AWREADY = (state == S_IDLE);
    assign WREADY  = (state == S_IDLE);
    assign ARREADY = (state == S_IDLE) && !(AWVALID && WVALID); // write priority

    integer i;

    always_ff @(posedge ACLK or negedge ARESETn) begin
        if (!ARESETn) begin
            state  <= S_IDLE;
            BVALID <= 1'b0;
            BRESP  <= RESP_OKAY;
            RVALID <= 1'b0;
            RRESP  <= RESP_OKAY;
            RDATA  <= 32'h0;

            // Initialize memory on reset (single driver - inside always_ff)
            for (i = 0; i < MEM_DEPTH; i = i + 1)
                mem[i] <= 32'h0000_0000;

        end else begin
            case (state)
                S_IDLE : begin
                    if (AWVALID && WVALID) begin
                        // Byte-wise write using WSTRB
                        if (WSTRB[0]) mem[AWADDR[4:0]][7:0]   <= WDATA[7:0];
                        if (WSTRB[1]) mem[AWADDR[4:0]][15:8]  <= WDATA[15:8];
                        if (WSTRB[2]) mem[AWADDR[4:0]][23:16] <= WDATA[23:16];
                        if (WSTRB[3]) mem[AWADDR[4:0]][31:24] <= WDATA[31:24];
                        BRESP  <= RESP_OKAY;
                        BVALID <= 1'b1;
                        state  <= S_WRITE_RESP;
                    end else if (ARVALID) begin
                        RDATA  <= mem[ARADDR[4:0]];
                        RRESP  <= RESP_OKAY;
                        RVALID <= 1'b1;
                        state  <= S_READ_DATA;
                    end
                end

                S_WRITE_RESP : begin
                    if (BVALID && BREADY) begin
                        BVALID <= 1'b0;
                        state  <= S_IDLE;
                    end
                end

                S_READ_DATA : begin
                    if (RVALID && RREADY) begin
                        RVALID <= 1'b0;
                        state  <= S_IDLE;
                    end
                end

                default : state <= S_IDLE;
            endcase
        end
    end

endmodule : axi_slave