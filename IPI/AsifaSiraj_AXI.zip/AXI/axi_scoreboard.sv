//=============================================================
// File   : axi_scoreboard.sv
// Purpose: Reference-memory based checker
//=============================================================
package axi_scoreboard_pkg;
    import axi_pkg::*;
    import axi_transaction_pkg::*;

    class axi_scoreboard;

        mailbox #(axi_transaction) mon2sb;
        bit [31:0] ref_mem [0:MEM_DEPTH-1];

        int pass_count;
        int fail_count;
        int total_count;

        function new(mailbox #(axi_transaction) mon2sb);
            this.mon2sb = mon2sb;
            foreach (ref_mem[i]) ref_mem[i] = 32'h0;
            pass_count  = 0;
            fail_count  = 0;
            total_count = 0;
        endfunction

        task run();
            axi_transaction tr;
            forever begin
                mon2sb.get(tr);
                total_count++;

                if (tr.is_write) begin
                    ref_mem[tr.addr[4:0]] = tr.wdata;
                    if (tr.bresp == RESP_OKAY) begin
                        $display("[SCOREBOARD] PASS : WRITE addr=%0d data=0x%08h resp=OKAY",
                                  tr.addr, tr.wdata);
                        pass_count++;
                    end else begin
                        $display("[SCOREBOARD] FAIL : WRITE addr=%0d resp=%0d (expected OKAY)",
                                  tr.addr, tr.bresp);
                        fail_count++;
                    end
                end else begin
                    bit [31:0] expected = ref_mem[tr.addr[4:0]];
                    if ((tr.rdata === expected) && (tr.rresp == RESP_OKAY)) begin
                        $display("[SCOREBOARD] PASS : READ  addr=%0d data=0x%08h",
                                  tr.addr, tr.rdata);
                        pass_count++;
                    end else begin
                        $display("[SCOREBOARD] FAIL : READ  addr=%0d expected=0x%08h got=0x%08h resp=%0d",
                                  tr.addr, expected, tr.rdata, tr.rresp);
                        fail_count++;
                    end
                end
            end
        endtask

        function void report();
            $display("=========================================");
            $display(" SCOREBOARD SUMMARY");
            $display(" TOTAL TRANSACTIONS : %0d", total_count);
            $display(" PASSED             : %0d", pass_count);
            $display(" FAILED             : %0d", fail_count);
            $display("=========================================");
        endfunction

    endclass : axi_scoreboard

endpackage : axi_scoreboard_pkg
