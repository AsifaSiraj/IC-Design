`timescale 1ns/1ps
//=====================================================================
// ahb_slave_bfm : behavioral AHB-Lite slave (BFM)
//---------------------------------------------------------------------
// Functionally equivalent to ahb_slave_burst but written in a pure
// behavioral style with explicit memory initialisation.  Supports:
//   * SINGLE / INCR4 / INCR bursts (INCR length is only limited by the
//     slave itself through the 1 KB memory).
//   * DELAY_READY wait states per data phase.
//   * ERROR injection: accesses to word ERROR_ADDR return HRESP=ERROR.
//   * HTRANS=BUSY : a BUSY cycle extends the pending data phase, so a
//     master can stall from its data buffer without losing a beat.
//=====================================================================
module ahb_slave_bfm #(
  parameter integer DELAY_READY = 0,    // wait states inserted per data phase
  parameter bit     ERROR_EN    = 0,    // 1 => enable ERROR injection
  parameter [7:0]   ERROR_ADDR  = 8'hFF // word address that returns ERROR
)(
  input  wire        HCLK,       // AHB system clock
  input  wire        HRESETn,    // active-low asynchronous reset
  input  wire        HSEL,       // slave select
  input  wire [31:0] HADDR,      // address bus
  input  wire        HWRITE,     // 1 => write, 0 => read
  input  wire [1:0]  HTRANS,     // transfer type (BUSY is honoured)
  input  wire [31:0] HWDATA,     // write-data bus
  input  wire        HREADY,     // bus-level HREADY
  output wire        HREADYOut,  // this slave's ready output
  output wire [1:0]  HRESP,      // response: 00=OKAY, 10=ERROR
  output reg  [31:0] HRDATA      // read-data bus
);
  //-------------------------------------------------------------------
  // Local declarations
  //-------------------------------------------------------------------
  reg [31:0] memory [0:255];       // 1 KB scratch memory (word addressed)
  reg        pend_valid;           // an address phase is registered (pending)
  reg        pend_write;           // registered HWRITE of the pending transfer
  reg [7:0]  pend_addr;            // registered word address of the pending transfer
  reg [3:0]  wait_cnt;             // wait-state down counter

  integer i;
  initial for (i = 0; i < 256; i = i + 1) memory[i] = 32'h0; // zero the memory

  // A new address phase is presented only by NONSEQ or SEQ transfers;
  // BUSY merely extends the previous data phase, IDLE does nothing.
  wire addr_phase = HSEL && HTRANS[1];
  // The pending transfer hits the ERROR word -> assert HRESP=ERROR during
  // its whole data phase (waits and BUSY extensions included).
  wire error_pend = pend_valid && (pend_addr == ERROR_ADDR);

  assign HRESP     = (ERROR_EN && error_pend) ? 2'b10 : 2'b00;
  assign HREADYOut = (wait_cnt == 0);            // low while wait states are inserted

  //-------------------------------------------------------------------
  // Wait-state generator
  //-------------------------------------------------------------------
  always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin
      wait_cnt <= 4'd0;
    end else if (wait_cnt != 0) begin
      wait_cnt <= wait_cnt - 1;                  // keep counting down
    end else if (HREADY && addr_phase && (DELAY_READY > 0)) begin
      wait_cnt <= DELAY_READY;                   // insert wait states on a new beat
    end
  end

  //-------------------------------------------------------------------
  // Transfer pipeline : capture the address phase, then complete the
  // data phase on the next HREADY edge that is not a BUSY cycle.
  //-------------------------------------------------------------------
  always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin
      pend_valid <= 1'b0; pend_write <= 1'b0; pend_addr <= 8'd0; HRDATA <= 32'h0;
    end else if (HREADY) begin
      if (pend_valid) begin
        // A transfer is pending.  It completes when the bus presents a new
        // address phase (NONSEQ/SEQ); BUSY just extends it.
        if (HTRANS != 2'b01) begin
          if (error_pend) begin
            // ERROR response terminates the transfer; drop the next phase.
            pend_valid <= 1'b0;
          end else begin
            if (pend_write) memory[pend_addr] <= HWDATA;  // commit the write data
            pend_valid <= addr_phase;                     // pipeline the new address phase
            pend_write <= HWRITE;
            pend_addr  <= HADDR[9:2];
            if (addr_phase && !HWRITE)
              HRDATA <= memory[HADDR[9:2]];               // read: present data now
          end
        end
        // else HTRANS==BUSY : keep the pending transfer, do not sample the bus
      end else if (addr_phase) begin
        // First address phase of a transfer/burst.
        pend_valid <= 1'b1;
        pend_write <= HWRITE;
        pend_addr  <= HADDR[9:2];
        if (!HWRITE) HRDATA <= memory[HADDR[9:2]];        // read: present data now
      end
    end
  end

endmodule
