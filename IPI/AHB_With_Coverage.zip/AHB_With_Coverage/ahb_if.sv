`timescale 1ns/1ps
//=======================================================================
// Compile guard
//=======================================================================
`ifndef AHB_IF_SV
`define AHB_IF_SV

//-----------------------------------------------------------------------
// ahb_if : bundles (a) the simplified master control interface exposed
// by ahb_master_burst, and (b) the actual AHB bus signals, so the
// verification layers only need ONE handle to talk to the DUT.
//
// User-interface notes:
//   burst_i       2'b00 = SINGLE, 2'b01 = INCR4, 2'b10 = INCR
//   INCR write    data words are streamed via data_valid_i / wdata_i /
//                 data_ack_o; data_last_i marks the final word.
//   INCR read     the number of beats is supplied on data_count_i.
//-----------------------------------------------------------------------
interface ahb_if (input logic HCLK, input logic HRESETn);

  // ---- Simplified request interface into ahb_master_burst ----
  logic        start_i;       // start a new transfer (handshake with ready_o)
  logic        write_i;       // 1 => write, 0 => read
  logic [1:0]  burst_i;       // 0 = SINGLE, 1 = INCR4, 2 = INCR
  logic [31:0] addr_i;        // start address
  logic        data_valid_i;  // write-data word valid on wdata_i
  logic [31:0] wdata_i;       // write-data word from the user interface
  logic        data_last_i;   // 1 on the final word of an INCR write
  logic [8:0]  data_count_i;  // beat count for an INCR read
  logic        data_ack_o;    // master accepted the word on wdata_i
  logic        ready_o;       // master idle, ready for a new start_i
  logic [31:0] rdata_o;       // read data returned to the user
  logic        err_o;         // 1 => last transfer terminated with ERROR

  // ---- AHB bus signals ----
  logic [1:0]  HTRANS;        // transfer type: IDLE/BUSY/NONSEQ/SEQ
  logic [2:0]  HBURST;        // burst type: SINGLE/INCR4/INCR
  logic        HWRITE;        // 1 => write, 0 => read
  logic [31:0] HADDR;         // address bus
  logic [31:0] HWDATA;        // write-data bus
  logic        HREADY;        // slave ready (data phase can end)
  logic [1:0]  HRESP;         // slave response (bit1 = ERROR)
  logic [31:0] HRDATA;        // read-data bus

  // Convenience task usable from any class holding a virtual handle to
  // this interface: block until N clean posedges have elapsed.
  task automatic wait_clocks(input int n);
    repeat (n) @(posedge HCLK);
  endtask

endinterface

`endif // AHB_IF_SV
