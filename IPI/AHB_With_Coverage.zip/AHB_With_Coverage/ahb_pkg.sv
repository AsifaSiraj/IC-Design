`timescale 1ns/1ps
//=======================================================================
// Compile guard
//=======================================================================
`ifndef AHB_PKG_SV
`define AHB_PKG_SV

package ahb_pkg;

  //=====================================================================
  // Operation enumeration
  //=====================================================================
  typedef enum bit [2:0] {
    OP_WRITE_SINGLE = 3'd0,   // single write transfer
    OP_READ_SINGLE  = 3'd1,   // single read transfer
    OP_WRITE_BURST  = 3'd2,   // INCR4 write burst (4 beats)
    OP_READ_BURST   = 3'd3,   // INCR4 read burst (4 beats)
    OP_WRITE_INCR   = 3'd4,   // INCR write, undefined length (data-driven)
    OP_READ_INCR    = 3'd5    // INCR read, undefined length (data_count_i)
  } ahb_op_e;

  // Word index that makes the slave return HRESP=ERROR (address 0xFC).
  // The tb_top ERROR_WORD parameter defaults to this value.
  localparam [7:0] ERROR_WORD_INDEX = 8'h3F;

  //=====================================================================
  // Transaction (stimulus item)
  //=====================================================================
  class ahb_transaction;
    ahb_op_e   op;           // operation to execute
    bit [31:0] addr;         // start address
    bit [31:0] data;         // base write data (or don't-care for reads)
    int        num_beats;    // number of beats (INCR only, otherwise implied)

    function new(ahb_op_e op = OP_WRITE_SINGLE,
                 bit [31:0] addr = 32'h0,
                 bit [31:0] data = 32'h0,
                 int        nbeats = 0);
      this.op   = op;
      this.addr = addr;
      this.data = data;
      // Fixed-length bursts know their length; INCR takes it from the user.
      case (op)
        OP_WRITE_BURST, OP_READ_BURST: this.num_beats = 4;
        OP_WRITE_INCR,  OP_READ_INCR:  this.num_beats = (nbeats > 0) ? nbeats : 8;
        default:                       this.num_beats = 1;
      endcase
    endfunction

    function string convert2string();
      return $sformatf("op=%s addr=0x%08h data=0x%08h beats=%0d",
                        op.name(), addr, data, num_beats);
    endfunction
  endclass

  //=====================================================================
  // Observed bus beat
  //=====================================================================
  class ahb_beat;
    bit        write;   // 1 => write beat, 0 => read beat
    bit [31:0] addr;    // beat address
    bit [31:0] data;    // sampled data (HWDATA for writes, HRDATA for reads)
    bit        error;   // 1 => the slave returned HRESP=ERROR on this beat

    function string convert2string();
      return $sformatf("%s addr=0x%08h data=0x%08h%s",
                        write ? "WRITE" : "READ ", addr, data,
                        error ? " [ERROR]" : "");
    endfunction
  endclass

  //=====================================================================
  // Generator : fixed-but-varied stimulus, including INCR lengths, an
  // ERROR-response access and a 1 KB boundary-truncation access.
  //=====================================================================
  class ahb_generator;
    mailbox #(ahb_transaction) gen2drv;   // generator -> driver mailbox
    int                        num_txns;  // number of transactions produced

    // Word address that makes the slave return HRESP=ERROR (0xFC).
    localparam bit [31:0] ERR_ADDR = {22'h000000, ERROR_WORD_INDEX, 2'b00};
    // Start address whose 1 KB boundary permits only 4 beats (word 252).
    localparam bit [31:0] BND_ADDR = 32'h0000_03F0;

    function new(mailbox #(ahb_transaction) gen2drv);
      this.gen2drv  = gen2drv;
      this.num_txns = 0;
    endfunction

    task run();
      ahb_transaction tr;

      // --- classic directed set (kept from the original testbench) ---
      tr = new(OP_WRITE_SINGLE, 32'h20, 32'hDEAD_BEEF); gen2drv.put(tr); num_txns++;
      tr = new(OP_READ_SINGLE , 32'h20, 32'h0        ); gen2drv.put(tr); num_txns++;
      tr = new(OP_WRITE_SINGLE, 32'h24, 32'hCAFE_0002); gen2drv.put(tr); num_txns++;
      tr = new(OP_READ_SINGLE , 32'h24, 32'h0        ); gen2drv.put(tr); num_txns++;
      tr = new(OP_WRITE_BURST , 32'h10, 32'h0000_00A0); gen2drv.put(tr); num_txns++;
      tr = new(OP_READ_BURST  , 32'h10, 32'h0        ); gen2drv.put(tr); num_txns++;
      tr = new(OP_WRITE_BURST , 32'h00, 32'h0000_000A); gen2drv.put(tr); num_txns++;
      tr = new(OP_READ_BURST  , 32'h00, 32'h0        ); gen2drv.put(tr); num_txns++;

      // --- INCR (undefined length) with different user-interface lengths ---
      tr = new(OP_WRITE_INCR, 32'h40, 32'h0000_0011, 5); gen2drv.put(tr); num_txns++;
      tr = new(OP_READ_INCR , 32'h40, 32'h0        , 5); gen2drv.put(tr); num_txns++;
      tr = new(OP_WRITE_INCR, 32'h60, 32'h0000_0077, 8); gen2drv.put(tr); num_txns++;
      tr = new(OP_READ_INCR , 32'h60, 32'h0        , 8); gen2drv.put(tr); num_txns++;

      // --- ERROR response handling in the master ---
      tr = new(OP_WRITE_SINGLE, ERR_ADDR, 32'hBEEF_DEAD); gen2drv.put(tr); num_txns++;
      tr = new(OP_READ_SINGLE , ERR_ADDR, 32'h0        ); gen2drv.put(tr); num_txns++;

      // --- 1 KB boundary truncation (requested 8 beats, only 4 allowed) ---
      tr = new(OP_WRITE_INCR, BND_ADDR, 32'h0000_00AA, 8); gen2drv.put(tr); num_txns++;
      tr = new(OP_READ_INCR , BND_ADDR, 32'h0        , 8); gen2drv.put(tr); num_txns++;

      $display("[%0t] GEN : generated %0d transactions", $time, num_txns);
    endtask
  endclass

  //=====================================================================
  // ahb_bus_coverage : samples pins every clock (protocol coverage)
  //=====================================================================
  class ahb_bus_coverage;
    virtual ahb_if vif;    // interface handle to the DUT pins

    bit [1:0] cov_htrans;  // sampled HTRANS
    bit [2:0] cov_hburst;  // sampled HBURST
    bit       cov_hwrite;  // sampled HWRITE
    bit       cov_hready;  // sampled HREADY
    bit [1:0] cov_beat;    // sampled beat index (from address bits)
    bit       cov_hresp;   // sampled HRESP[1] (error flag)

    covergroup cg_bus;
      option.per_instance = 1;
      option.name         = "cg_ahb_bus";

      cp_trans : coverpoint cov_htrans {   // transfer type on the bus
        bins idle   = {2'b00};
        bins busy   = {2'b01};
        bins nonseq = {2'b10};
        bins seq    = {2'b11};
      }

      cp_burst : coverpoint cov_hburst iff (cov_htrans[1]) {  // burst kind
        bins single = {3'd0};
        bins incr4  = {3'd3};
        bins incr   = {3'd7};
      }

      cp_write : coverpoint cov_hwrite iff (cov_htrans[1]) {  // direction
        bins rd = {1'b0};
        bins wr = {1'b1};
      }

      cp_ready : coverpoint cov_hready {   // wait states vs ready cycles
        bins ready   = {1'b1};
        bins wait_st = {1'b0};
      }

      cp_resp : coverpoint cov_hresp {     // slave response
        bins okay = {1'b0};
        bins error = {1'b1};
      }

      cp_beat : coverpoint cov_beat iff (cov_htrans[1]) {  // beat position
        bins beat0 = {2'd0};
        bins beat1 = {2'd1};
        bins beat2 = {2'd2};
        bins beat3 = {2'd3};
      }

      cx_burst_ready : cross cp_burst, cp_ready;
      cx_write_ready : cross cp_write, cp_ready;
      cx_trans_burst : cross cp_trans, cp_burst;
    endgroup

    function new(virtual ahb_if vif);
      this.vif = vif;
      cg_bus   = new();
    endfunction

    task run();
      forever begin
        @(posedge vif.HCLK);
        if (vif.HRESETn === 1'b1) begin       // ignore the reset window
          cov_htrans = vif.HTRANS;
          cov_hburst = vif.HBURST;
          cov_hwrite = vif.HWRITE;
          cov_hready = vif.HREADY;
          cov_hresp  = vif.HRESP[1];
          cov_beat   = vif.HADDR[3:2];
          cg_bus.sample();
        end
      end
    endtask

    function real get_coverage();
      return cg_bus.get_inst_coverage();
    endfunction
  endclass

  //=====================================================================
  // ahb_txn_coverage : samples generated/driven transactions
  //=====================================================================
  class ahb_txn_coverage;
    ahb_op_e   cov_op;      // sampled operation
    bit [31:0] cov_addr;    // sampled address
    int        cov_len;     // sampled burst length

    ahb_op_e   prev_op;     // previous sampled operation
    bit [31:0] prev_addr;   // previous sampled address
    bit        have_prev;   // 1 once a previous sample exists

    typedef enum bit [1:0] {
      PAIR_NONE,               // first transaction, no predecessor
      PAIR_SINGLE_WR_RD,       // single write followed by single read, same addr
      PAIR_BURST_WR_RD,        // burst write followed by burst read, same addr
      PAIR_OTHER               // any other combination
    } pair_e;
    pair_e cov_pair;           // sampled write/read pair class

    covergroup cg_txn;
      option.per_instance = 1;
      option.name         = "cg_ahb_txn";

      cp_op : coverpoint cov_op {       // operation type
        bins wr_single = {OP_WRITE_SINGLE};
        bins rd_single = {OP_READ_SINGLE};
        bins wr_burst  = {OP_WRITE_BURST};
        bins rd_burst  = {OP_READ_BURST};
        bins wr_incr   = {OP_WRITE_INCR};
        bins rd_incr   = {OP_READ_INCR};
      }

      cp_addr : coverpoint cov_addr {   // start address used
        bins addr_00 = {32'h00};
        bins addr_10 = {32'h10};
        bins addr_20 = {32'h20};
        bins addr_24 = {32'h24};
        bins addr_40 = {32'h40};
        bins addr_60 = {32'h60};
        bins err_adr = {32'h0000_00FC};
        bins bnd_adr = {32'h0000_03F0};
        bins others  = default;
      }

      cp_len : coverpoint cov_len {     // burst length (INCR)
        bins one   = {1};
        bins four  = {4};
        bins five  = {5};
        bins eight = {8};
      }

      cx_op_addr : cross cp_op, cp_addr;

      cp_pair : coverpoint cov_pair {   // write-then-read sequence class
        bins single_wr_then_rd = {PAIR_SINGLE_WR_RD};
        bins burst_wr_then_rd  = {PAIR_BURST_WR_RD};
        bins other_seq         = {PAIR_OTHER};
        ignore_bins none_bin   = {PAIR_NONE};
      }
    endgroup

    function new();
      cg_txn    = new();
      have_prev = 1'b0;
      prev_op   = OP_WRITE_SINGLE;
      prev_addr = 32'h0;
    endfunction

    // Returns true when the operation is a write of the given class.
    function bit is_single_wr(ahb_op_e o);
      is_single_wr = (o == OP_WRITE_SINGLE);
    endfunction
    function bit is_single_rd(ahb_op_e o);
      is_single_rd = (o == OP_READ_SINGLE);
    endfunction
    function bit is_burst_wr(ahb_op_e o);
      is_burst_wr = (o == OP_WRITE_BURST || o == OP_WRITE_INCR);
    endfunction
    function bit is_burst_rd(ahb_op_e o);
      is_burst_rd = (o == OP_READ_BURST || o == OP_READ_INCR);
    endfunction

    function void sample(ahb_transaction tr);
      cov_op   = tr.op;
      cov_addr = tr.addr;
      cov_len  = tr.num_beats;

      // Classify the write->read sequence seen on the user interface.
      if (!have_prev)
        cov_pair = PAIR_NONE;
      else if (is_single_wr(prev_op) && is_single_rd(tr.op) && prev_addr == tr.addr)
        cov_pair = PAIR_SINGLE_WR_RD;
      else if (is_burst_wr(prev_op) && is_burst_rd(tr.op) && prev_addr == tr.addr)
        cov_pair = PAIR_BURST_WR_RD;
      else
        cov_pair = PAIR_OTHER;

      cg_txn.sample();

      prev_op   = tr.op;
      prev_addr = tr.addr;
      have_prev = 1'b1;
    endfunction

    function real get_coverage();
      return cg_txn.get_inst_coverage();
    endfunction
  endclass

  //=====================================================================
  // ahb_cfg_coverage : records which parameter combination this run used
  //=====================================================================
  class ahb_cfg_coverage;
    bit cov_master_busy;   // master inserted BUSY bubbles this run
    bit cov_slave_wait;    // slave inserted wait states this run
    bit cov_use_bfm;       // which slave implementation was used

    covergroup cg_cfg;
      option.per_instance = 1;
      option.at_least     = 1;
      option.name         = "cg_ahb_cfg";

      cp_busy : coverpoint cov_master_busy { bins off = {0}; bins on = {1}; }
      cp_wait : coverpoint cov_slave_wait  { bins off = {0}; bins on = {1}; }
      cp_bfm  : coverpoint cov_use_bfm     { bins rtl = {0}; bins bfm = {1}; }

      cx_all : cross cp_busy, cp_wait, cp_bfm;
    endgroup

    function new();
      cg_cfg = new();
    endfunction

    function void sample(int master_busy, int slave_wait, int use_bfm);
      cov_master_busy = (master_busy != 0);
      cov_slave_wait  = (slave_wait  != 0);
      cov_use_bfm     = (use_bfm     != 0);
      cg_cfg.sample();
    endfunction

    function real get_coverage();
      return cg_cfg.get_inst_coverage();
    endfunction
  endclass

  //=====================================================================
  // Driver (drives the user interface + samples transaction coverage)
  //=====================================================================
  class ahb_driver;
    virtual ahb_if vif;                 // interface handle to the DUT
    mailbox #(ahb_transaction) gen2drv; // generator -> driver mailbox
    ahb_txn_coverage txn_cov;           // optional coverage hook (may be null)

    function new(virtual ahb_if vif,
                 mailbox #(ahb_transaction) gen2drv,
                 ahb_txn_coverage txn_cov = null);
      this.vif     = vif;
      this.gen2drv = gen2drv;
      this.txn_cov = txn_cov;
    endfunction

    // Push a single write-data word to the master's data buffer using the
    // data_valid_i / data_ack_o handshake (with back-pressure).
    task automatic push_word(input bit [31:0] w, input bit last);
      @(negedge vif.HCLK);                 // drive on the negative edge
      vif.wdata_i     = w;                 // present the data word
      vif.data_valid_i = 1'b1;             // mark it valid
      vif.data_last_i  = last;             // mark the final word if requested
      wait (vif.data_ack_o === 1'b1);      // back-pressure: wait to be accepted
      @(posedge vif.HCLK);                 // master captures it on this edge
      #1;
      vif.data_valid_i = 1'b0;             // deassert the pulse
      vif.data_last_i  = 1'b0;
      vif.wdata_i      = 32'h0;
    endtask

    task automatic drive_one(ahb_transaction tr);
      // Pre-load the write data of an INCR write burst before starting so
      // the master never starves (length limited by the buffer depth).
      if (tr.op == OP_WRITE_INCR) begin
        for (int i = 0; i < tr.num_beats; i = i + 1)
          push_word(tr.data + i, (i == tr.num_beats - 1));
      end

      @(negedge vif.HCLK);
      vif.addr_i       = tr.addr;
      vif.wdata_i      = tr.data;
      vif.data_count_i = tr.num_beats;
      case (tr.op)
        OP_WRITE_SINGLE: begin vif.write_i = 1'b1; vif.burst_i = 2'd0; end
        OP_READ_SINGLE : begin vif.write_i = 1'b0; vif.burst_i = 2'd0; end
        OP_WRITE_BURST : begin vif.write_i = 1'b1; vif.burst_i = 2'd1; end
        OP_READ_BURST  : begin vif.write_i = 1'b0; vif.burst_i = 2'd1; end
        OP_WRITE_INCR  : begin vif.write_i = 1'b1; vif.burst_i = 2'd2; end
        OP_READ_INCR   : begin vif.write_i = 1'b0; vif.burst_i = 2'd2; end
        default        : begin vif.write_i = 1'b0; vif.burst_i = 2'd0; end
      endcase
      vif.start_i = 1'b1;

      @(posedge vif.HCLK);
      #1;
      vif.start_i = 1'b0;

      wait (vif.ready_o === 1'b1);         // transfer complete

      // Report ERROR responses back to the user of the driver.
      if (vif.err_o === 1'b1)
        $display("[%0t] DRV : %s -> ERROR response received", $time, tr.convert2string());
      else
        $display("[%0t] DRV : completed %s", $time, tr.convert2string());

      if (txn_cov != null) txn_cov.sample(tr);
    endtask

    task run(int n_txns);
      ahb_transaction tr;
      repeat (n_txns) begin
        gen2drv.get(tr);
        drive_one(tr);
      end
    endtask
  endclass

  //=====================================================================
  // Monitor : samples the bus and forwards completed beats
  //=====================================================================
  class ahb_monitor;
    virtual ahb_if vif;             // interface handle to the DUT
    mailbox #(ahb_beat) mon2scb;    // monitor -> scoreboard mailbox

    function new(virtual ahb_if vif, mailbox #(ahb_beat) mon2scb);
      this.vif     = vif;
      this.mon2scb = mon2scb;
    endfunction

    task run();
      bit        pend_valid;   // an address phase is pending (data phase open)
      bit        pend_write;   // registered HWRITE of the pending beat
      bit [31:0] pend_addr;    // registered HADDR of the pending beat
      ahb_beat   b;

      pend_valid = 1'b0;

      forever begin
        @(posedge vif.HCLK);
        if (vif.HRESETn === 1'b0) begin
          pend_valid = 1'b0;                       // forget everything on reset
        end else if (vif.HREADY === 1'b1) begin
          // The pending data phase completes when the bus presents a new
          // address phase (NONSEQ/SEQ) or returns to IDLE; a BUSY cycle
          // extends it, so nothing is sampled during BUSY.
          if (pend_valid && (vif.HTRANS != 2'b01)) begin
            b       = new();
            b.write = pend_write;
            b.addr  = pend_addr;
            b.data  = pend_write ? vif.HWDATA : vif.HRDATA;
            b.error = vif.HRESP[1];                // capture the response
            mon2scb.put(b);
            $display("[%0t] MON : %s", $time, b.convert2string());
          end
          if (vif.HTRANS[1]) begin
            // New address phase (NONSEQ/SEQ) sampled -> becomes pending.
            pend_valid = 1'b1;
            pend_write = vif.HWRITE;
            pend_addr  = vif.HADDR;
          end else if (vif.HTRANS == 2'b01) begin
            // BUSY cycle: keep the pending beat, do not overwrite it.
          end else begin
            // IDLE with nothing new: clear any stale pending state.
            pend_valid = 1'b0;
          end
        end
      end
    endtask
  endclass

  //=====================================================================
  // Scoreboard : reference-memory model check
  //=====================================================================
  class ahb_scoreboard;
    mailbox #(ahb_beat) mon2scb;    // monitor -> scoreboard mailbox
    bit [31:0]          ref_mem[bit [31:0]];  // reference memory (by full addr)
    int                 pass_cnt;   // number of passing checks
    int                 fail_cnt;   // number of failing checks

    function new(mailbox #(ahb_beat) mon2scb);
      this.mon2scb = mon2scb;
      pass_cnt = 0;
      fail_cnt = 0;
    endfunction

    task run();
      ahb_beat b;
      forever begin
        mon2scb.get(b);
        if (b.error) begin
          // An ERROR beat is not a real transfer: no memory update, no
          // comparison (the master discarded its data).
          $display("[%0t] SCB : ERROR beat skipped addr=0x%08h", $time, b.addr);
        end else if (b.write) begin
          ref_mem[b.addr] = b.data;                // record the write
          $display("[%0t] SCB : WRITE  addr=0x%08h data=0x%08h (ref updated)",
                    $time, b.addr, b.data);
        end else begin
          if (ref_mem.exists(b.addr)) begin
            if (ref_mem[b.addr] === b.data) begin
              pass_cnt++;
              $display("[%0t] SCB : PASS   addr=0x%08h data=0x%08h",
                        $time, b.addr, b.data);
            end else begin
              fail_cnt++;
              $display("[%0t] SCB : FAIL   addr=0x%08h data=0x%08h expected=0x%08h",
                        $time, b.addr, b.data, ref_mem[b.addr]);
            end
          end else begin
            $display("[%0t] SCB : WARN   read from address 0x%08h before any write",
                      $time, b.addr);
          end
        end
      end
    endtask

    function void report();
      $display("================================================");
      $display("   SCOREBOARD RESULT :  PASS=%0d   FAIL=%0d", pass_cnt, fail_cnt);
      $display(fail_cnt == 0 ? "   STATUS : ALL CHECKS PASSED ***"
                              : "   STATUS : SOME CHECKS FAILED !!!");
      $display("================================================");
    endfunction
  endclass

  //=====================================================================
  // Environment : instantiates and connects every layer
  //=====================================================================
  class ahb_environment;
    virtual ahb_if vif;                 // interface handle to the DUT

    mailbox #(ahb_transaction) gen2drv; // generator -> driver mailbox
    mailbox #(ahb_beat)        mon2scb; // monitor -> scoreboard mailbox

    ahb_generator     gen;              // stimulus generator
    ahb_driver        drv;              // user-interface driver
    ahb_monitor       mon;              // bus monitor
    ahb_scoreboard    scb;              // reference-model checker

    ahb_bus_coverage  bus_cov;          // pin-level protocol coverage
    ahb_txn_coverage  txn_cov;          // transaction-level coverage
    ahb_cfg_coverage  cfg_cov;          // per-run configuration coverage

    function new(virtual ahb_if vif);
      this.vif = vif;
      gen2drv  = new();
      mon2scb  = new();

      gen     = new(gen2drv);
      txn_cov = new();
      bus_cov = new(vif);
      cfg_cov = new();

      drv = new(vif, gen2drv, txn_cov);
      mon = new(vif, mon2scb);
      scb = new(mon2scb);
    endfunction

    task run(int master_busy = 0, int slave_wait = 0, int use_bfm = 0);
      cfg_cov.sample(master_busy, slave_wait, use_bfm);

      fork
        mon.run();       // monitor + scoreboard + coverage run concurrently
        scb.run();
        bus_cov.run();
      join_none

      gen.run();         // produce and drive the stimulus
      drv.run(gen.num_txns);

      vif.wait_clocks(10);

      scb.report();
      report_coverage();
    endtask

    function void report_coverage();
      $display("================================================");
      $display("   FUNCTIONAL COVERAGE SUMMARY");
      $display("   Bus-level   coverage : %0.2f %%", bus_cov.get_coverage());
      $display("   Transaction coverage : %0.2f %%", txn_cov.get_coverage());
      $display("   Config combo covered : %0.2f %%", cfg_cov.get_coverage());
      $display("   (merge multiple runs' .ucdb to close Config coverage)");
      $display("================================================");
    endfunction
  endclass

  //=====================================================================
  // Test : top-level test (thin wrapper around the environment)
  //=====================================================================
  class ahb_test;
    ahb_environment env;     // the full verification environment

    function new(virtual ahb_if vif);
      env = new(vif);
    endfunction

    task run(int master_busy = 0, int slave_wait = 0, int use_bfm = 0);
      env.run(master_busy, slave_wait, use_bfm);
    endtask
  endclass

endpackage

`endif // AHB_PKG_SV
