`timescale 1ns/1ps
//=====================================================================
// tb_ahb_burst : flat directed testbench for ahb_master_burst
//---------------------------------------------------------------------
//  * config : MASTER_BUSY (BUSY bubbles), SLAVE_WAIT (wait states),
//             USE_BFM (behavioral BFM vs RTL slave)
//  * directed tests for SINGLE / INCR4 / INCR bursts
//  * INCR (undefined length) writes use the user-interface data buffer
//    handshake (data_valid_i/data_ack_o/data_last_i)
//  * data-buffer starved test forces the master into HTRANS=BUSY
//  * 1 KB boundary truncation test
//  * ERROR response (HRESP) test on the error word
//=====================================================================
module tb_ahb_burst;

  // ---- configuration: flip these to observe stalls ----
  parameter MASTER_BUSY = 0;   // 1 => master inserts BUSY between burst beats
  parameter SLAVE_WAIT  = 0;   // n => n wait states per data phase
  parameter USE_BFM     = 0;   // 1 => use behavioral BFM instead of RTL slave

  reg         HCLK, HRESETn;
  wire        HREADY, HREADY_rtl, HREADY_bfm;
  wire [1:0]  HRESP,  HRESP_rtl,  HRESP_bfm;
  wire [31:0] HRDATA, HRDATA_rtl, HRDATA_bfm;
  wire [1:0]  HTRANS; wire [2:0] HBURST; wire HWRITE;
  wire [31:0] HADDR, HWDATA;

  // ---- user interface to the master ----
  reg         start_i, write_i;
  reg  [1:0]  burst_i;          // 0=SINGLE, 1=INCR4, 2=INCR
  reg  [31:0] addr_i, wdata_i;
  reg         data_valid_i;     // write-data word available
  reg         data_last_i;      // 1 on the final word of an INCR write
  reg  [8:0]  data_count_i;     // beat count for an INCR read
  wire        data_ack_o;       // master accepted wdata_i
  wire        ready_o; wire [31:0] rdata_o; wire err_o;

  assign HREADY = (USE_BFM!=0) ? HREADY_bfm : HREADY_rtl;
  assign HRDATA = (USE_BFM!=0) ? HRDATA_bfm : HRDATA_rtl;
  assign HRESP  = (USE_BFM!=0) ? HRESP_bfm  : HRESP_rtl;

  // ---- DUT : master ----
  ahb_master_burst #(.ENABLE_BUSY(MASTER_BUSY)) u_master (
    .HCLK(HCLK), .HRESETn(HRESETn), .HREADY(HREADY), .HRESP(HRESP), .HRDATA(HRDATA),
    .start_i(start_i), .write_i(write_i), .burst_i(burst_i), .addr_i(addr_i),
    .data_valid_i(data_valid_i), .wdata_i(wdata_i), .data_last_i(data_last_i),
    .data_count_i(data_count_i), .data_ack_o(data_ack_o),
    .ready_o(ready_o), .rdata_o(rdata_o), .err_o(err_o),
    .HTRANS(HTRANS), .HBURST(HBURST), .HWRITE(HWRITE), .HADDR(HADDR), .HWDATA(HWDATA)
  );

  // ---- DUT : RTL slave (error injection enabled at word 63 = 0xFC) ----
  ahb_slave_burst #(.DELAY_READY(SLAVE_WAIT), .ERROR_EN(1'b1), .ERROR_ADDR(8'h3F)) u_slave (
    .HCLK(HCLK), .HRESETn(HRESETn), .HSEL(USE_BFM==0),
    .HADDR(HADDR), .HWRITE(HWRITE), .HTRANS(HTRANS), .HWDATA(HWDATA),
    .HREADY(HREADY), .HREADYOut(HREADY_rtl), .HRESP(HRESP_rtl), .HRDATA(HRDATA_rtl)
  );

  // ---- DUT : behavioral BFM slave (same error injection) ----
  ahb_slave_bfm #(.DELAY_READY(SLAVE_WAIT), .ERROR_EN(1'b1), .ERROR_ADDR(8'h3F)) u_bfm (
    .HCLK(HCLK), .HRESETn(HRESETn), .HSEL(USE_BFM!=0),
    .HADDR(HADDR), .HWRITE(HWRITE), .HTRANS(HTRANS), .HWDATA(HWDATA),
    .HREADY(HREADY), .HREADYOut(HREADY_bfm), .HRESP(HRESP_bfm), .HRDATA(HRDATA_bfm)
  );

  initial HCLK = 1'b0;              // start the clock low
  always #5 HCLK = ~HCLK;           // 10 ns clock period

  initial begin $dumpfile("ahb_burst.vcd"); $dumpvars(0,tb_ahb_burst); end

  integer pass_count, fail_count;   // pass / fail counters
  integer busy_cnt;                 // BUSY cycles seen during a starved write
  reg     busy_count_en;            // enable the BUSY counter

  // 1-stage read-beat capture: latch HRDATA on the HREADY edge that ends
  // each read data phase (works with waits and with BUSY).
  reg        mp1;                   // a read data phase is ending this edge
  reg [31:0] beat_data [0:15];      // captured read beats
  integer    beat_wr_idx;           // write index into beat_data
  always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin
      mp1 <= 0; beat_wr_idx <= 0;
    end else if (HREADY) begin
      if (mp1 && beat_wr_idx < 16) begin
        beat_data[beat_wr_idx] <= HRDATA;   // latch the completed read beat
        beat_wr_idx <= beat_wr_idx + 1;
      end
      mp1 <= (HTRANS[1] && !HWRITE);        // re-arm on the next read addr phase
    end
  end

  // BUSY-cycle counter (used by the data-buffer starved test).
  always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin
      busy_cnt <= 0;
    end else if (busy_count_en && HREADY && (HTRANS == 2'b01)) begin
      busy_cnt <= busy_cnt + 1;             // count master BUSY stalls
    end
  end

  initial begin
    HRESETn=0; start_i=0; write_i=0; burst_i=0; addr_i=0; wdata_i=0;
    data_valid_i=0; data_last_i=0; data_count_i=0;
    pass_count=0; fail_count=0; busy_cnt=0; busy_count_en=0;
    $display("================================================");
    $display("   AHB BURST TB  BUSY=%0d WAIT=%0d BFM=%0d", MASTER_BUSY, SLAVE_WAIT, USE_BFM);
    $display("================================================");
    repeat (4) @(posedge HCLK); HRESETn=1;   // release reset
    $display("[%0t] Reset Released", $time);
    repeat (2) @(posedge HCLK);

    //--------------------------------------------------------------
    // TEST 1 : INCR4 burst write (internal auto-generated data)
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 1: INCR4 Burst Write ===", $time);
    do_write_burst(32'h10, 32'hAA); repeat (2) @(posedge HCLK);
    check_mem(4,32'hAA,"T1-Beat0"); check_mem(5,32'hAB,"T1-Beat1");
    check_mem(6,32'hAC,"T1-Beat2"); check_mem(7,32'hAD,"T1-Beat3");

    //--------------------------------------------------------------
    // TEST 2 : INCR4 burst read
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 2: INCR4 Burst Read ===", $time);
    clear_beat_buf(); do_read_burst(32'h10); repeat (1) @(posedge HCLK);
    check_beat(0,32'hAA,"T2-B0"); check_beat(1,32'hAB,"T2-B1");
    check_beat(2,32'hAC,"T2-B2"); check_beat(3,32'hAD,"T2-B3");
    check_rdata(32'hAD,"T2-Last ");

    //--------------------------------------------------------------
    // TEST 3 : single write
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 3: Single Write ===", $time);
    do_write_single(32'h20,32'hDEADBEEF); repeat (2) @(posedge HCLK);
    check_mem(8,32'hDEADBEEF,"T3-Single");

    //--------------------------------------------------------------
    // TEST 4 : single read
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 4: Single Read ===", $time);
    clear_beat_buf(); do_read_single(32'h20); repeat (1) @(posedge HCLK);
    check_rdata(32'hDEADBEEF,"T4-SingRd");

    //--------------------------------------------------------------
    // TEST 5 : INCR4 burst write #2
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 5: INCR4 Burst Write #2 ===", $time);
    do_write_burst(32'h00,32'hA); repeat (2) @(posedge HCLK);
    check_mem(0,32'hA,"T5-Beat0"); check_mem(1,32'hB,"T5-Beat1");
    check_mem(2,32'hC,"T5-Beat2"); check_mem(3,32'hD,"T5-Beat3");

    //--------------------------------------------------------------
    // TEST 6 : INCR4 burst read #2
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 6: INCR4 Burst Read #2 ===", $time);
    clear_beat_buf(); do_read_burst(32'h00); repeat (1) @(posedge HCLK);
    check_beat(0,32'hA,"T6-B0"); check_beat(1,32'hB,"T6-B1");
    check_beat(2,32'hC,"T6-B2"); check_beat(3,32'hD,"T6-B3");
    check_rdata(32'hD,"T6-Last ");

    //--------------------------------------------------------------
    // TEST 7 : INCR (undefined length) write - 5 words via the buffer
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 7: INCR Write (5 beats) ===", $time);
    do_write_incr(32'h30,32'h11,5); repeat (2) @(posedge HCLK);
    check_mem(12,32'h11,"T7-B0"); check_mem(13,32'h12,"T7-B1");
    check_mem(14,32'h13,"T7-B2"); check_mem(15,32'h14,"T7-B3");
    check_mem(16,32'h15,"T7-B4");

    //--------------------------------------------------------------
    // TEST 8 : INCR (undefined length) read - 5 beats
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 8: INCR Read (5 beats) ===", $time);
    clear_beat_buf(); do_read_incr(32'h30,5); repeat (1) @(posedge HCLK);
    check_beat(0,32'h11,"T8-B0"); check_beat(1,32'h12,"T8-B1");
    check_beat(2,32'h13,"T8-B2"); check_beat(3,32'h14,"T8-B3");
    check_beat(4,32'h15,"T8-B4"); check_rdata(32'h15,"T8-Last ");

    //--------------------------------------------------------------
    // TEST 9 : INCR write with a longer (8 beat) data stream
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 9: INCR Write (8 beats) ===", $time);
    do_write_incr(32'h60,32'h77,8); repeat (2) @(posedge HCLK);
    check_mem(24,32'h77,"T9-B0"); check_mem(25,32'h78,"T9-B1");
    check_mem(26,32'h79,"T9-B2"); check_mem(27,32'h7A,"T9-B3");
    check_mem(28,32'h7B,"T9-B4"); check_mem(29,32'h7C,"T9-B5");
    check_mem(30,32'h7D,"T9-B6"); check_mem(31,32'h7E,"T9-B7");

    //--------------------------------------------------------------
    // TEST 10 : INCR read with 8 beats
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 10: INCR Read (8 beats) ===", $time);
    clear_beat_buf(); do_read_incr(32'h60,8); repeat (1) @(posedge HCLK);
    check_beat(0,32'h77,"T10-B0"); check_beat(1,32'h78,"T10-B1");
    check_beat(2,32'h79,"T10-B2"); check_beat(3,32'h7A,"T10-B3");
    check_beat(4,32'h7B,"T10-B4"); check_beat(5,32'h7C,"T10-B5");
    check_beat(6,32'h7D,"T10-B6"); check_beat(7,32'h7E,"T10-B7");
    check_rdata(32'h7E,"T10-Last");

    //--------------------------------------------------------------
    // TEST 11 : ERROR response on a write (word 63, addr 0xFC)
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 11: Write with ERROR response ===", $time);
    do_write_single(32'hFC,32'hBEEF); repeat (2) @(posedge HCLK);
    if (err_o===1'b1) begin
      $display("[%0t] PASS T11-Err | err_o asserted", $time); pass_count=pass_count+1;
    end else begin
      $display("[%0t] FAIL T11-Err | err_o not asserted", $time); fail_count=fail_count+1;
    end
    check_mem(63,32'h0,"T11-NoWr");   // memory must NOT be modified on ERROR

    //--------------------------------------------------------------
    // TEST 12 : ERROR response on a read
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 12: Read with ERROR response ===", $time);
    clear_beat_buf(); do_read_single(32'hFC); repeat (1) @(posedge HCLK);
    if (err_o===1'b1) begin
      $display("[%0t] PASS T12-Err | err_o asserted", $time); pass_count=pass_count+1;
    end else begin
      $display("[%0t] FAIL T12-Err | err_o not asserted", $time); fail_count=fail_count+1;
    end

    //--------------------------------------------------------------
    // TEST 13 : 1 KB boundary - INCR write of 8 words truncated to 4
    //           (word 252 allows only 4 more beats before the boundary)
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 13: 1KB Boundary INCR Write ===", $time);
    do_write_incr(32'h3F0,32'hAA,8); repeat (2) @(posedge HCLK);
    check_mem(252,32'hAA,"T13-B0"); check_mem(253,32'hAB,"T13-B1");
    check_mem(254,32'hAC,"T13-B2"); check_mem(255,32'hAD,"T13-B3");

    //--------------------------------------------------------------
    // TEST 14 : 1 KB boundary - INCR read of 8 beats truncated to 4
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 14: 1KB Boundary INCR Read ===", $time);
    clear_beat_buf(); do_read_incr(32'h3F0,8); repeat (1) @(posedge HCLK);
    check_beat(0,32'hAA,"T14-B0"); check_beat(1,32'hAB,"T14-B1");
    check_beat(2,32'hAC,"T14-B2"); check_beat(3,32'hAD,"T14-B3");
    check_rdata(32'hAD,"T14-Last");

    //--------------------------------------------------------------
    // TEST 15 : data-buffer starvation -> master must insert HTRANS=BUSY
    //           word 0 is preloaded, words 1..3 are held back, so the
    //           master's data buffer runs dry mid-burst.
    //--------------------------------------------------------------
    $display("\n[%0t] === TEST 15: Data-Buffer Starved INCR Write ===", $time);
    busy_cnt = 0; busy_count_en = 1;
    do_write_incr_starved(32'h80,32'h10,4);
    busy_count_en = 0;
    repeat (2) @(posedge HCLK);
    if (busy_cnt >= 1) begin
      $display("[%0t] PASS T15-BUSY | master stalled %0d cycle(s) on empty buffer", $time, busy_cnt);
      pass_count=pass_count+1;
    end else begin
      $display("[%0t] FAIL T15-BUSY | no BUSY cycles observed", $time);
      fail_count=fail_count+1;
    end
    check_mem(32,32'h10,"T15-B0"); check_mem(33,32'h11,"T15-B1");
    check_mem(34,32'h12,"T15-B2"); check_mem(35,32'h13,"T15-B3");

    repeat (3) @(posedge HCLK);
    $display("\n================================================");
    $display("   PASSED : %0d", pass_count);
    $display("   FAILED : %0d", fail_count);
    $display(fail_count==0 ? "   STATUS : ALL TESTS PASSED ***"
                           : "   STATUS : SOME TESTS FAILED !!!");
    $display("================================================");
    $finish;
  end

  //-------------------------------------------------------------------
  // Helper tasks
  //-------------------------------------------------------------------
  task clear_beat_buf; integer i; begin
    @(negedge HCLK); beat_wr_idx=0;
    for (i=0;i<16;i=i+1) beat_data[i]=32'hx;
  end endtask

  // Push one write-data word through the user-interface handshake.
  task push_data; input [31:0] d; input last; begin
    @(negedge HCLK);
    wdata_i = d; data_valid_i = 1'b1; data_last_i = last;
    wait (data_ack_o === 1'b1);       // back-pressure until accepted
    @(posedge HCLK); #1;
    data_valid_i = 1'b0; data_last_i = 1'b0; wdata_i = 32'h0;
  end endtask

  task do_write_burst; input [31:0] a,d; begin
    @(negedge HCLK); start_i=1; write_i=1; burst_i=2'd1; addr_i=a; wdata_i=d;
    @(posedge HCLK); #1 start_i=0; wait(ready_o===1'b1);
  end endtask
  task do_read_burst; input [31:0] a; begin
    @(negedge HCLK); start_i=1; write_i=0; burst_i=2'd1; addr_i=a; wdata_i=0;
    @(posedge HCLK); #1 start_i=0; wait(ready_o===1'b1);
  end endtask
  task do_write_single; input [31:0] a,d; begin
    @(negedge HCLK); start_i=1; write_i=1; burst_i=2'd0; addr_i=a; wdata_i=d;
    @(posedge HCLK); #1 start_i=0; wait(ready_o===1'b1);
  end endtask
  task do_read_single; input [31:0] a; begin
    @(negedge HCLK); start_i=1; write_i=0; burst_i=2'd0; addr_i=a; wdata_i=0;
    @(posedge HCLK); #1 start_i=0; wait(ready_o===1'b1);
  end endtask

  // INCR write: push all n words into the buffer, then start the burst.
  task do_write_incr; input [31:0] a,d; input integer n; begin
    integer i;
    for (i=0;i<n;i=i+1) push_data(d + i, (i == n-1));
    @(negedge HCLK); start_i=1; write_i=1; burst_i=2'd2; addr_i=a; wdata_i=d;
    @(posedge HCLK); #1 start_i=0; wait(ready_o===1'b1);
  end endtask

  // INCR read: the beat count is supplied on data_count_i.
  task do_read_incr; input [31:0] a; input integer n; begin
    @(negedge HCLK);
    start_i=1; write_i=0; burst_i=2'd2; addr_i=a; wdata_i=0; data_count_i=n;
    @(posedge HCLK); #1 start_i=0; wait(ready_o===1'b1);
  end endtask

  // INCR write with deliberate data starvation: only word 0 is preloaded,
  // words 1..n-1 are held back so the master runs dry and must use BUSY.
  task do_write_incr_starved; input [31:0] a,d; input integer n; begin
    integer i;
    // preload only the first word
    push_data(d, 1'b0);
    // start the burst
    @(negedge HCLK); start_i=1; write_i=1; burst_i=2'd2; addr_i=a; wdata_i=d;
    @(posedge HCLK); #1 start_i=0;
    // hold back the remaining words for a few cycles -> data buffer runs dry
    repeat (3) @(posedge HCLK);
    for (i=1;i<n;i=i+1) push_data(d + i, (i == n-1));
    wait(ready_o===1'b1);
  end endtask

  //-------------------------------------------------------------------
  // Checkers
  //-------------------------------------------------------------------
  task check_mem; input [7:0] idx; input [31:0] exp; input [79:0] label;
    reg [31:0] m; begin
      m = (USE_BFM!=0) ? u_bfm.memory[idx] : u_slave.memory[idx];
      if (m===exp) begin $display("[%0t] PASS %s | mem[%0d]=0x%08h",$time,label,idx,m); pass_count=pass_count+1; end
      else begin $display("[%0t] FAIL %s | mem[%0d]=0x%08h Expected=0x%08h",$time,label,idx,m,exp); fail_count=fail_count+1; end
  end endtask

  task check_rdata; input [31:0] exp; input [79:0] label; begin
    if (rdata_o===exp) begin $display("[%0t] PASS %s | rdata_o=0x%08h",$time,label,rdata_o); pass_count=pass_count+1; end
    else begin $display("[%0t] FAIL %s | rdata_o=0x%08h Expected=0x%08h",$time,label,rdata_o,exp); fail_count=fail_count+1; end
  end endtask

  task check_beat; input integer idx; input [31:0] exp; input [79:0] label; begin
    if (beat_data[idx]===exp) begin $display("[%0t] PASS %s | beat[%0d]=0x%08h",$time,label,idx,beat_data[idx]); pass_count=pass_count+1; end
    else begin $display("[%0t] FAIL %s | beat[%0d]=0x%08h Expected=0x%08h",$time,label,idx,beat_data[idx],exp); fail_count=fail_count+1; end
  end endtask

  //-------------------------------------------------------------------
  // Bus monitor print (visual aid)
  //-------------------------------------------------------------------
  always @(posedge HCLK) begin
    if (HRESETn && (HTRANS!=2'b00 || !HREADY))   // skip pure idle cycles
      $display("[MON %0t] HREADY=%0b HTRANS=%0d(%s) HBURST=%0d HWRITE=%0b HADDR=0x%08h HWDATA=0x%08h HRDATA=0x%08h",
               $time, HREADY, HTRANS,
               (HTRANS==2'b10)?"NONSEQ":(HTRANS==2'b11)?"SEQ   ":
               (HTRANS==2'b01)?"BUSY  ":"IDLE  ",
               HBURST, HWRITE, HADDR, HWDATA, HRDATA);
  end

  initial begin #100000; $display("[ERROR] TIMEOUT"); $finish; end
endmodule
