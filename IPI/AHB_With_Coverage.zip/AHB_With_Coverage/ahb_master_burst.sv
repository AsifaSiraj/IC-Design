`timescale 1ns/1ps
//=====================================================================
// ahb_master_burst : AHB-Lite single master
//---------------------------------------------------------------------
// Supported bursts
//   * SINGLE  : one transfer.
//   * INCR4   : exactly four transfers; the 4 write-data words are
//               generated internally from wdata_i (+0/+1/+2/+3).
//   * INCR    : incrementing burst of UNDEFINED length.
//                 - WRITE : the user interface streams data words through
//                   the data_valid_i/wdata_i/data_ack_o handshake; the
//                   word marked with data_last_i terminates the burst.
//                 - READ  : the number of beats is taken from data_count_i.
//
// Data-buffer driven BUSY (user requirement)
//   The master only ever enters HTRANS=BUSY for a reason taken from its
//   user-interface data buffer: if the next write-data word has not yet
//   arrived (fifo_empty), the master holds the bus in BUSY instead of
//   presenting the next address phase.  (The optional ENABLE_BUSY
//   parameter additionally inserts one BUSY bubble between burst beats
//   for the directed tests.)
//
// 1 KB address-boundary rule
//   An INCR burst must never cross a 1024-byte boundary.  The number of
//   allowed beats is 256 - addr[9:2], and the FSM truncates the burst to
//   that many beats even if the user interface keeps feeding data.
//
// Error response (HRESP)
//   If the slave returns HRESP=ERROR on any data phase, the current
//   transfer is terminated, the rest of the burst is aborted, and err_o
//   is raised; read data is discarded.
//=====================================================================
module ahb_master_burst #(
  parameter ENABLE_BUSY = 0      // 1 => insert one HTRANS=BUSY bubble between burst beats
)(
  //-------------------------------------------------------------------
  // AHB bus (side facing the slave)
  //-------------------------------------------------------------------
  input  wire        HCLK,       // AHB system clock
  input  wire        HRESETn,    // active-low asynchronous reset
  input  wire        HREADY,     // high => the current data phase may end
  input  wire [1:0]  HRESP,      // slave response; bit[1] = ERROR
  input  wire [31:0] HRDATA,     // slave read-data bus
  output reg  [1:0]  HTRANS,     // transfer type: IDLE/BUSY/NONSEQ/SEQ
  output reg  [2:0]  HBURST,     // burst type: SINGLE/INCR4/INCR
  output reg         HWRITE,     // 1 => write, 0 => read
  output reg  [31:0] HADDR,      // address bus
  output reg  [31:0] HWDATA,     // write-data bus

  //-------------------------------------------------------------------
  // User interface (commands + write-data source)
  //-------------------------------------------------------------------
  input  wire        start_i,      // start a new transfer (handshake with ready_o)
  input  wire        write_i,      // 1 => write, 0 => read
  input  wire [1:0]  burst_i,      // 0 => SINGLE, 1 => INCR4, 2 => INCR
  input  wire [31:0] addr_i,       // start address of the transfer
  input  wire        data_valid_i, // user has a write-data word on wdata_i
  input  wire [31:0] wdata_i,      // write-data word from the user interface
  input  wire        data_last_i,  // 1 on the final word of an INCR write
  input  wire [8:0]  data_count_i, // beat count for an INCR read burst
  output wire        data_ack_o,   // master accepted the word on wdata_i
  output reg         ready_o,      // master idle, ready for a new start_i
  output reg  [31:0] rdata_o,      // read data returned to the user
  output reg         err_o         // 1 => last transfer terminated with ERROR
);
  //-------------------------------------------------------------------
  // Local declarations
  //-------------------------------------------------------------------
  localparam [1:0] IDLE    = 2'd0, // idle, waiting for start_i
                   ADDR    = 2'd1, // deciding/presenting the next address phase
                   BUSY_ST = 2'd2, // issue the address phase owed after a BUSY bubble
                   DONE    = 2'd3; // final data phase in progress / wind down
  reg [1:0]  state;                // FSM state

  reg        is_write;             // current transfer is a write
  reg        is_burst;             // current transfer is a burst (INCR4/INCR)
  reg        is_incr;              // current transfer is an INCR (undefined length)
  reg [31:0] base_addr;            // start address of the current burst
  reg [8:0]  max_beats;            // max beats before end (fixed total / 1KB clamp)
  reg [8:0]  beat;                 // count of address phases presented so far

  reg [31:0] wbuf [0:3];           // internal data words for SINGLE/INCR4 writes
  reg [31:0] fifo [0:7];           // INCR write-data buffer fed by the user interface
  reg        fifo_last [0:7];      // per-slot "this word ends the burst" flag
  reg [2:0]  fifo_wr;              // FIFO write pointer
  reg [2:0]  fifo_rd;              // FIFO read pointer
  reg [3:0]  fifo_cnt;             // number of valid words currently in the FIFO

  reg        rd_dphase;            // a read data phase is ending on this edge
  wire       rd_ap   = HTRANS[1] && !HWRITE; // a read address phase is on the bus now

  // The most beats allowed before the burst would cross a 1 KB boundary.
  wire [8:0] boundary = 9'd256 - {1'b0, addr_i[9:2]};

  wire fifo_empty = (fifo_cnt == 0);   // no write data available for the next beat
  wire fifo_full  = (fifo_cnt == 8);   // write-data buffer is full

  // Accept a word from the user interface while idle (pre-load) or during
  // a write transfer, provided the buffer is not full.
  wire push_en = data_valid_i && !fifo_full &&
                 (state == IDLE || (is_write && state != DONE));
  // Pop one word into HWDATA exactly when the ADDR state loads an INCR word:
  // only on a clean HREADY edge (HREADY low => wait state, the FSM is frozen
  // and HWDATA keeps its value, so no word may be consumed).
  wire pop_en  = HREADY && (state == ADDR) && !HRESP[1] &&
                 is_write && is_incr && !fifo_empty;

  assign data_ack_o = push_en;     // handshake acknowledgement back to the user

  //-------------------------------------------------------------------
  // Write-data FIFO (user interface -> AHB bus)
  //-------------------------------------------------------------------
  always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin
      fifo_wr <= 0; fifo_rd <= 0; fifo_cnt <= 0;   // empty the buffer on reset
    end else begin
      if (push_en) begin                           // user pushed a new word
        fifo[fifo_wr]     <= wdata_i;              //   store the data value
        fifo_last[fifo_wr] <= data_last_i;         //   remember if it is the final word
        fifo_wr           <= fifo_wr + 1;          //   advance the write pointer
      end
      if (pop_en) begin                            // master consumed one word
        fifo_rd <= fifo_rd + 1;                    //   advance the read pointer
      end
      case ({push_en, pop_en})                     // keep the depth accounting correct
        2'b10: fifo_cnt <= fifo_cnt + 1;           //   push only
        2'b01: fifo_cnt <= fifo_cnt - 1;           //   pop only
        default: fifo_cnt <= fifo_cnt;             //   both or neither
      endcase
    end
  end

  //-------------------------------------------------------------------
  // Main transfer FSM
  //-------------------------------------------------------------------
  always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin
      state <= IDLE; ready_o <= 1'b1; rdata_o <= 32'h0; err_o <= 1'b0;
      rd_dphase <= 1'b0;
      HTRANS <= 2'b00; HBURST <= 3'd0; HWRITE <= 1'b0; HADDR <= 32'h0; HWDATA <= 32'h0;
      is_write <= 1'b0; is_burst <= 1'b0; is_incr <= 1'b0; base_addr <= 32'h0;
      max_beats <= 9'd0; beat <= 9'd0;
      wbuf[0] <= 32'h0; wbuf[1] <= 32'h0; wbuf[2] <= 32'h0; wbuf[3] <= 32'h0;
    end
    // The FSM only advances on a clean edge (HREADY high).  While the slave
    // holds HREADY low (wait states) every bus output freezes in place.
    else if (HREADY) begin
      // Sample the response / read data of the data phase ending on this
      // edge.  An ERROR response is flagged and never used as read data.
      if (rd_dphase && !HRESP[1]) rdata_o <= HRDATA;  // latch read data on OKAY only
      rd_dphase <= rd_ap;

      case (state)
        //-----------------------------------------------------------------
        // IDLE : wait for the user to request a transfer
        //-----------------------------------------------------------------
        IDLE: begin
          ready_o <= 1'b1;
          HTRANS <= 2'b00; HBURST <= 3'd0; HWRITE <= 1'b0; HWDATA <= 32'h0;
          beat    <= 9'd0;
          if (start_i) begin
            is_write <= write_i;                   // capture the transfer direction
            is_burst <= (burst_i != 2'd0);         // burst flag for INCR4 / INCR
            is_incr  <= (burst_i == 2'd2);         // undefined-length burst flag
            base_addr <= addr_i;
            wbuf[0] <= wdata_i;                    // internal data for fixed-length writes
            wbuf[1] <= wdata_i + 32'd1;
            wbuf[2] <= wdata_i + 32'd2;
            wbuf[3] <= wdata_i + 32'd3;
            case (burst_i)                         // beats allowed by type + 1KB rule
              2'd0:    max_beats <= (9'd1 < boundary) ? 9'd1 : boundary; // SINGLE
              2'd1:    max_beats <= (9'd4 < boundary) ? 9'd4 : boundary; // INCR4
              default: begin
                if (write_i)                       // INCR write: length is open,
                  max_beats <= boundary;           //   bounded only by the boundary
                else                               // INCR read: user-supplied count
                  max_beats <= (data_count_i < boundary) ? data_count_i : boundary;
              end
            endcase
            HADDR <= addr_i; HWRITE <= write_i;
            HBURST <= (burst_i == 2'd2) ? 3'd7     // INCR
                    : (burst_i == 2'd1) ? 3'd3     // INCR4
                    : 3'd0;                        // SINGLE
            HTRANS <= 2'b10;                       // NONSEQ : address phase of beat 0
            ready_o <= 1'b0;                       // not idle until ready_o rises again
            beat    <= 9'd1;                       // one address phase already presented
            err_o   <= 1'b0;                       // clear the error flag for this transfer
            state   <= ADDR;
          end
        end

        //-----------------------------------------------------------------
        // ADDR : present the next address phase, or stall the bus in BUSY
        //-----------------------------------------------------------------
        ADDR: begin
          // ERROR from the data phase ending now -> abort the whole burst.
          if (HRESP[1]) begin
            err_o <= 1'b1;                         // report the error to the user
            HTRANS <= 2'b00; HBURST <= 3'd0; HWDATA <= 32'h0;
            state <= DONE;
          end
          // INCR write: no data in the buffer yet -> stall with HTRANS=BUSY
          // until the user interface delivers the next word (data buffer).
          else if (is_write && is_incr && fifo_empty) begin
            HTRANS <= 2'b01;                       // BUSY extends the current data phase
            state  <= ADDR;                        // re-evaluate on the next cycle
          end
          // INCR write with data available: load the word into HWDATA now.
          else if (is_write && is_incr) begin
            HWDATA <= fifo[fifo_rd];               // data of the beat ending next cycle
            if (fifo_last[fifo_rd] || beat >= max_beats) begin
              HTRANS <= 2'b00;                     // final beat: stop the burst
              state  <= DONE;
            end else if (ENABLE_BUSY && is_burst) begin
              HTRANS <= 2'b01;                     // optional BUSY bubble inserted
              state  <= BUSY_ST;                   //   owed address phase goes out next
            end else begin
              HADDR  <= base_addr + (beat << 2);   // pipelined next address phase
              HTRANS <= 2'b11; beat <= beat + 1;   // SEQ + advance the beat counter
            end
          end
          // Fixed-length write: data always comes from the internal wbuf.
          else if (is_write) begin
            HWDATA <= wbuf[beat - 1];              // data for the beat ending next cycle
            if (beat >= max_beats) begin
              HTRANS <= 2'b00;                     // last beat of a fixed burst
              state  <= DONE;
            end else if (ENABLE_BUSY && is_burst) begin
              HTRANS <= 2'b01; state <= BUSY_ST;   // optional BUSY bubble inserted
            end else begin
              HADDR  <= base_addr + (beat << 2);   // pipelined next address phase
              HTRANS <= 2'b11; beat <= beat + 1;
            end
          end
          // Read : no write data involved, identical address pipeline.
          else begin
            if (beat >= max_beats) begin
              HTRANS <= 2'b00; state <= DONE;      // last beat of the read burst
            end else if (ENABLE_BUSY && is_burst) begin
              HTRANS <= 2'b01; state <= BUSY_ST;   // optional BUSY bubble inserted
            end else begin
              HADDR  <= base_addr + (beat << 2);   // pipelined next address phase
              HTRANS <= 2'b11; beat <= beat + 1;
            end
          end
        end

        //-----------------------------------------------------------------
        // BUSY_ST : issue the address phase that was owed after a BUSY bubble
        //-----------------------------------------------------------------
        BUSY_ST: begin
          if (HRESP[1]) begin                      // error can arrive on the extended phase
            err_o <= 1'b1; HTRANS <= 2'b00; HBURST <= 3'd0; HWDATA <= 32'h0;
            state <= DONE;
          end else begin
            HADDR  <= base_addr + (beat << 2);     // issue the owed address phase
            HTRANS <= 2'b11; beat <= beat + 1;
            state  <= ADDR;
          end
        end

        //-----------------------------------------------------------------
        // DONE : last data phase in progress; return to idle
        //-----------------------------------------------------------------
        DONE: begin
          if (HRESP[1]) err_o <= 1'b1;             // the final beat itself errored
          HWDATA <= 32'h0; HBURST <= 3'd0;
          fifo_wr <= 3'd0; fifo_rd <= 3'd0; fifo_cnt <= 4'd0; // flush leftover INCR data
          ready_o <= 1'b1;
          state <= IDLE;
        end
        default: state <= IDLE;
      endcase
    end
  end

endmodule
