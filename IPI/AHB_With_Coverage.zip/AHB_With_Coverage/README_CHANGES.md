# AHB Burst Controller — Change Record

This document records **every change** made to the AHB project: where it was
made, why it was made, how it was implemented, and what its impact is.
A companion document, `README_CODE_GUIDE.md`, explains the resulting code in
detail.

---

## 1. Requirements (the task that drove the changes)

| # | Requirement | Status |
|---|-------------|--------|
| i)   | Comment the code, especially every `if` statement and every declaration | DONE |
| ii)  | Cater for the ERROR response (`HRESP`) in the MASTER RTL (previously declared but never used) | DONE |
| instr i) | Make the master enter `HTRANS=BUSY` by evaluating the write-data buffer of the user interface (not just an optional parameter) | DONE |
| instr ii) | Implement the `INCR` (undefined-length) `HBURST` type with different data lengths, obeying the 1 KB address-boundary rule | DONE |
| (extra) | Keep the testbench and top-level code consistent with the RTL | DONE |

---

## 2. Files touched (overview)

| File | Kind | What changed | Impact |
|------|------|--------------|--------|
| `ahb_master_burst.sv` | RTL (master) | Rewritten | New INCR support, FIFO, BUSY-from-buffer, ERROR handling, comments |
| `ahb_slave_burst.sv` | RTL (slave) | Rewritten | 1 KB memory, wait states, ERROR injection, BUSY honouring, memory init |
| `ahb_slave_bfm.sv` | Behavioural slave | Rewritten | Same behaviour as RTL slave (explicit memory init) |
| `ahb_if.sv` | Interface | Extended | New user-interface signals + comments |
| `ahb_pkg.sv` | TB package | Rewritten | New ops, generator/driver/monitor/scoreboard/coverage for the new features |
| `tb_top.sv` | Layered TB top | Rewritten | Wires the new interface, both slaves, HRESP monitor print, watchdog |
| `tb_ahb_burst.sv` | Flat directed TB | Rewritten | 15 directed tests incl. INCR, ERROR, boundary, BUSY-starvation |
| `compile_sim.do` | Simulation script | Fixed | Correct `coverage save` syntax (removed invalid `-directory` option) |
| `regression_cov.do` | Regression script | Fixed | Same `coverage save` fix |

---

## 3. Detailed change log

### 3.1 `ahb_master_burst.sv` (master RTL)

**3.1.1 Documentation / comments (requirement i)**
- Added a full header comment block describing the supported bursts, the
  data-buffer driven BUSY rule, the 1 KB boundary rule, and the ERROR response
  handling (lines 2–32).
- Every local signal has a trailing comment on its declaration.
- Every `if / else` branch in the FSM has an explanatory comment.

**3.1.2 New user-interface ports (required by INCR support)**
- `burst_i[1:0]` — replaces the old 1-bit `burst_i`. Encoding:
  `2'b00 = SINGLE`, `2'b01 = INCR4`, `2'b10 = INCR`.
- `data_valid_i / wdata_i / data_last_i / data_ack_o` — a handshake through
  which the user interface streams the write-data words of an INCR write.
  `data_last_i` marks the final word; `data_ack_o` is asserted when the master
  accepts a word into its buffer.
- `data_count_i[8:0]` — the number of beats for an INCR read.
- `err_o` — raised when the last transfer was terminated by `HRESP=ERROR`.

**3.1.3 INCR (undefined-length) burst support (requirement instr ii)**
- `HBURST` is now driven with `3'd7` for INCR (line 179–181).
- INCR write: words come from the user interface through the FIFO; the burst
  ends when `data_last_i` was received **or** the 1 KB boundary is reached.
- INCR read: the number of beats comes from `data_count_i`.
- Different lengths (5, 8, … beats) are exercised by the testbenches.

**3.1.4 1 KB address-boundary rule (requirement instr ii)**
- New wire `boundary = 9'd256 - {1'b0, addr_i[9:2]}` (line 93) computes how
  many word beats fit before the address would cross the 1024-byte boundary.
- In `IDLE` the allowed beat count is clamped: `max_beats` is
  `min(type_implied_beats, boundary)` for every transfer type (lines 168–177).
  For INCR writes the length is open but bounded by `boundary`; for INCR reads
  it is `min(data_count_i, boundary)`.
- The FSM terminates the burst at `beat >= max_beats` (lines 209, 223, 235).

**3.1.5 Data-buffer driven BUSY (requirement instr i)**
- The master only ever enters `HTRANS=BUSY` because of its data buffer: in
  state `ADDR`, an INCR write with an empty FIFO asserts
  `HTRANS=2'b01` (BUSY) instead of presenting the next address phase
  (lines 200–205). It re-evaluates every cycle until the user interface
  delivers a word.
- The pre-existing `ENABLE_BUSY` parameter (inserts one BUSY bubble between
  burst beats for the directed tests) is kept orthogonal to this.

**3.1.6 ERROR response handling (requirement ii)**
- `HRESP[1]` is sampled at the end of every data phase.
- On ERROR the FSM: raises `err_o`, discards any read data (`rdata_o` is only
  latched on `!HRESP[1]`, line 148), drops the rest of the burst, and returns
  to `IDLE` (lines 195–199, 250–252, 264).
- Writes that got an ERROR are never committed by the slave (see 3.2).

**3.1.7 Write-data FIFO**
- 8-deep FIFO (`fifo[0:7]`, `fifo_last[0:7]`) with write/read pointers and a
  depth counter (lines 83–96), so the user interface can burst up to 8 words
  ahead of the bus (used by the pre-load strategy in the driver).
- `push_en` is gated so words are accepted in `IDLE` (pre-load) or during a
  write transfer but never while the master is winding down in `DONE`.
- Leftover words (e.g. a burst truncated by the boundary) are flushed when the
  transfer completes in `DONE` (line 266), so stale data can never leak into
  the next transfer.

### 3.2 `ahb_slave_burst.sv` (RTL slave)

**3.2.1 Documentation / comments (requirement i)**
- Full header and per-line comments, identical style to the master.

**3.2.2 1 KB memory**
- Memory enlarged to 256 words (`memory[0:255]`) addressed by `HADDR[9:2]`, so
  long INCR bursts and the 1 KB boundary can be exercised.

**3.2.3 Wait states**
- `DELAY_READY` parameter inserts wait states per data phase via a
  `wait_cnt` down-counter; `HREADYOut` is low while counting.

**3.2.4 ERROR injection**
- `ERROR_EN` / `ERROR_ADDR[7:0]` parameters. `error_pend` is true while a
  pending transfer targets the ERROR word; `HRESP` is then driven to `2'b10`
  for the whole data phase (including wait states and BUSY extensions).
  An ERROR transfer is **not** committed to memory.

**3.2.5 BUSY honouring**
- A BUSY cycle extends the pending data phase; the slave holds its registered
  state and samples nothing (`if (HTRANS != 2'b01)`, line 79).

**3.2.6 Memory initialisation (bug fix, see §4)**
- The memory is zero-initialised in the reset branch of the pipeline always
  block (line 73), matching the behavioural BFM.

### 3.3 `ahb_slave_bfm.sv` (behavioural slave)

- Rewritten as a behavioural twin of the RTL slave with the same features:
  256-word memory, wait states, ERROR injection, BUSY honouring.
- Differs only in style: uses an `initial` block to zero the memory
  (line 41) instead of a reset loop.

### 3.4 `ahb_if.sv` (interface)

- Bundles the master control interface and the AHB bus into a single handle
  for the layered verification environment.
- New signals added: `burst_i`, `data_valid_i`, `data_last_i`,
  `data_count_i`, `data_ack_o`, `err_o` (lines 22–33).
- Every signal commented; a `wait_clocks` task added for convenience.

### 3.5 `ahb_pkg.sv` (layered verification package)

- **New operations** `OP_WRITE_INCR`, `OP_READ_INCR` in `ahb_op_e`
  (lines 13–20).
- **`ERROR_WORD_INDEX = 8'h3F`** localparam shared by the TB and the
  generator's `ERR_ADDR` (line 24).
- **Generator** (lines 76–119) now emits, in order: the classic SINGLE/INCR4
  set, INCR write/read with 5 and 8 beats, a write+read to the ERROR word
  (`ERR_ADDR = 0xFC`), and a write+read at `BND_ADDR = 0x3F0` where a
  requested 8-beat INCR must be truncated to 4 by the boundary rule.
- **Driver** (lines 350–425): `push_word` implements the
  `data_valid_i/wdata_i/data_ack_o` back-pressure handshake; `drive_one`
  pre-loads an INCR write's words into the buffer before asserting `start_i`,
  and reports ERROR responses.
- **Monitor** (lines 430–478): samples the bus; a BUSY cycle extends the
  pending beat and nothing is sampled during it; captures `HRESP[1]` as the
  beat's `error` flag.
- **Scoreboard** (lines 483–533): ERROR beats are skipped (no memory update,
  no compare); writes update a reference memory; reads are compared.
- **Coverage classes** (lines 124–348): `ahb_bus_coverage` (with a new
  `cp_resp` coverpoint for `HRESP`), `ahb_txn_coverage`, `ahb_cfg_coverage`.
- **Environment + test** (lines 538–610): connects all layers, runs them
  concurrently, prints the scoreboard and functional-coverage summary.

### 3.6 `tb_top.sv` (layered top)

- `ERROR_WORD` parameter defaults to the package `ERROR_WORD_INDEX`
  (line 20), keeping top and package consistent.
- Both slaves (RTL and BFM) are instantiated with `ERROR_EN=1` and
  `ERROR_ADDR=ERROR_WORD`; `USE_BFM` selects which one drives the bus
  (lines 49–51, 84–121).
- Bus monitor print now includes `HRESP` (lines 126–134).
- Added a global watchdog that force-finishes if the simulation hangs
  (lines 161–165).

### 3.7 `tb_ahb_burst.sv` (flat directed testbench)

- 15 directed tests (see the test map in `README_CODE_GUIDE.md` §9),
  covering: INCR4 write/read, SINGLE write/read, INCR write/read at 5 and 8
  beats, ERROR write/read, 1 KB boundary truncation write/read, and a
  data-buffer-starvation write that must produce `HTRANS=BUSY`.
- Helper tasks `push_data`, `do_write_*`, `do_read_*` and checkers
  `check_mem`, `check_rdata`, `check_beat`.
- Every `if` statement commented (requirement i).

### 3.8 `compile_sim.do` and `regression_cov.do`

- Replaced the invalid `coverage save -onexit -directory covdb run_*.ucdb`
  (there is **no** `-directory` option on `coverage save`) with a plain
  filename path plus `file mkdir covdb`, i.e.
  `coverage save -onexit covdb/run_*.ucdb`.

---

## 4. Bugs found and fixed during verification

These are the bugs that only showed up once the new features were run:

| # | Symptom | Root cause | Fix |
|---|---------|------------|-----|
| 1 | `tb_ahb_burst` TEST 11 failed: `mem[63]=x...x Expected=0x00000000` | RTL slave memory was never initialised, so the "error write must not modify memory" check compared against X | Zero-initialise `memory` in the reset branch of `ahb_slave_burst.sv` (line 73), matching the BFM |
| 2 | Simulation hung forever with `SLAVE_WAIT=1`; master stuck issuing BUSY | The FIFO `pop_en` fired on **every** cycle the FSM sat in `ADDR`, including HREADY-low wait-state cycles, so the buffer drained faster than the bus could consume it | Gate `pop_en` with `HREADY` in `ahb_master_burst.sv` (line 103) so a word is only consumed on the same clean edge that loads `HWDATA` |
| 3 | `coverage save` in the do files wrote no `.ucdb` | Invalid `-directory` option on `coverage save` | Fixed both do files (see §3.8) |

---

## 5. Verification results

Environment: **QuestaSim 2024.1** (`C:\questasim64_2024.1\win64`). All files
compile with **0 errors / 0 warnings**.

**Layered TB (`tb_top`)** — scoreboard result for every combination of
`MASTER_BUSY × SLAVE_WAIT × USE_BFM` (8 runs):

```
MASTER_BUSY=0 SLAVE_WAIT=0 USE_BFM=0  -> PASS=27  FAIL=0
MASTER_BUSY=0 SLAVE_WAIT=0 USE_BFM=1  -> PASS=27  FAIL=0
MASTER_BUSY=0 SLAVE_WAIT=1 USE_BFM=0  -> PASS=27  FAIL=0
MASTER_BUSY=0 SLAVE_WAIT=1 USE_BFM=1  -> PASS=27  FAIL=0
MASTER_BUSY=1 SLAVE_WAIT=0 USE_BFM=0  -> PASS=27  FAIL=0
MASTER_BUSY=1 SLAVE_WAIT=0 USE_BFM=1  -> PASS=27  FAIL=0
MASTER_BUSY=1 SLAVE_WAIT=1 USE_BFM=0  -> PASS=27  FAIL=0
MASTER_BUSY=1 SLAVE_WAIT=1 USE_BFM=1  -> PASS=27  FAIL=0
```

**Flat directed TB (`tb_ahb_burst`)** — 65 checks, all passing, in every
configuration tried:

```
MASTER_BUSY=0 SLAVE_WAIT=0 USE_BFM=0 -> PASSED: 65  FAILED: 0
MASTER_BUSY=1 SLAVE_WAIT=0 USE_BFM=0 -> PASSED: 65  FAILED: 0
MASTER_BUSY=0 SLAVE_WAIT=1 USE_BFM=0 -> PASSED: 65  FAILED: 0
MASTER_BUSY=0 SLAVE_WAIT=0 USE_BFM=1 -> PASSED: 65  FAILED: 0
MASTER_BUSY=1 SLAVE_WAIT=1 USE_BFM=1 -> PASSED: 65  FAILED: 0
```

Verified against the waveform log: SINGLE, INCR4, INCR-5, INCR-8, ERROR
write/read (err_o asserted, memory untouched), 1 KB boundary truncation
(8 requested → 4 emitted), and 3 BUSY cycles inserted on an empty data buffer.

---

## 6. How to run

```text
# one-shot compile + simulate + coverage summary
vsim -c -do compile_sim.do

# full 8-config regression with merged coverage
vsim -c -do regression_cov.do

# single custom run
vsim -c -coverage -voptargs=+acc work.tb_top -GMASTER_BUSY=1 -GSLAVE_WAIT=2 -GUSE_BFM=0

# flat directed testbench (the one Quartus uses as its testbench)
vsim -c work.tb_ahb_burst
```

---

## 7. Environment notes / known limitations

- The functional-coverage **summary** printed by `tb_top` (bus/transaction/
  config percentages) comes from the in-code `covergroup`s and is fully
  functional.
- In this particular **QuestaSim 2024.1** installation, `coverage save`
  was observed not to emit a `.ucdb` file even with `-coverage` and
  `+cover=bcesf` compiled design units (the tool-level code-coverage database
  appears not to be collected for this design in this environment). The do
  files' `coverage save` syntax is nevertheless correct now. On the original
  ModelSim Intel FPGA Starter Edition the same scripts are expected to produce
  the UCDB as designed.
