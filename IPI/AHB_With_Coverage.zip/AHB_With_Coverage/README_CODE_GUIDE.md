# AHB Burst Controller — Code Explanation Guide

This document explains, in detail, how the AHB master/slave code works after
the changes. It is a companion to `README_CHANGES.md` (the change record).
All line numbers refer to the current files.

---

## 1. System architecture

```
        user interface                    AHB bus                     slave
  -------------------------------   --------------------------   ---------------
  start_i / write_i / burst_i \                                  HSEL
  addr_i                       \                                  HADDR
  data_valid_i / wdata_i        \    ahb_master_burst             HWRITE
  data_last_i / data_ack_o  ------>   +--------------+   -------> HTRANS
  data_count_i                ------> |  FIFO (8)    |   -------> HWDATA
  ready_o  <----------------   <------ |  transfer    |   <------- HREADY
  rdata_o  <----------------   <------ |  FSM         |   <------- HRESP
  err_o    <----------------   <------ |  boundary    |   <------- HRDATA
                                       +--------------+
                                                              ahb_slave_burst
                                                           (or ahb_slave_bfm)
```

**Burst encodings (user interface):** `burst_i` `2'b00` = SINGLE,
`2'b01` = INCR4, `2'b10` = INCR.

- **SINGLE / INCR4**: the master generates the write data internally from
  `wdata_i` (`+0, +1, +2, +3`).
- **INCR write** (undefined length): the user streams words through the
  `data_valid_i/wdata_i/data_ack_o` handshake; `data_last_i` marks the final
  word. The master can only go as fast as the buffer has data — otherwise it
  holds the bus in `HTRANS=BUSY`.
- **INCR read**: the number of beats is given on `data_count_i`.

---

## 2. AHB protocol essentials used by this code

- Address and data phases are **pipelined**: while beat *N*'s data phase is
  on the bus, beat *N+1*'s address phase is presented.
- `HREADY=1` ends a data phase. `HREADY=0` = wait state, all outputs freeze.
- `HTRANS`: `00` IDLE, `01` BUSY, `10` NONSEQ, `11` SEQ.
  BUSY extends the previous data phase; it is *not* a new transfer.
- `HRESP[1]` = ERROR. On ERROR the burst is aborted.
- INCR bursts must not cross a 1 KB address boundary.

---

## 3. `ahb_master_burst.sv` — deep dive

### 3.1 Interface (lines 33–65)

| Port | Dir | Meaning |
|------|-----|---------|
| `HCLK, HRESETn` | in | clock, active-low async reset |
| `HREADY, HRESP, HRDATA` | in | slave side |
| `HTRANS, HBURST, HWRITE, HADDR, HWDATA` | out | bus to slave |
| `start_i, write_i, burst_i, addr_i` | in | transfer request |
| `data_valid_i, wdata_i, data_last_i, data_count_i` | in | write-data source / read length |
| `data_ack_o` | out | accept handshake for `wdata_i` |
| `ready_o` | out | master idle again |
| `rdata_o` | out | read data for the user |
| `err_o` | out | last transfer ended with ERROR |

### 3.2 Internal structure

- **FSM states** (lines 69–72):
  `IDLE → ADDR → (BUSY_ST) → DONE → IDLE`.
- **`boundary`** (line 93): `9'd256 - addr[9:2]` — beats left before the
  1 KB boundary. E.g. start word 252 (`0x3F0`) ⇒ `boundary = 4`.
- **`max_beats`** (set in IDLE, lines 168–177):
  - SINGLE: `min(1, boundary)`
  - INCR4: `min(4, boundary)`
  - INCR write: `boundary` (open-ended, also stopped by `data_last_i`)
  - INCR read: `min(data_count_i, boundary)`
- **Write-data FIFO** (lines 82–96, 111–129): 8 words, each slot has a
  `data_last` flag, plus `fifo_wr/fifo_rd/fifo_cnt`.

### 3.3 The FIFO handshake (lines 100–129)

```
push_en = data_valid_i && !fifo_full &&
          (state==IDLE || (is_write && state!=DONE));
pop_en  = HREADY && (state==ADDR) && !HRESP[1] &&
          is_write && is_incr && !fifo_empty;
assign data_ack_o = push_en;
```

- `push_en` accepts a user word in IDLE (pre-load) or during a write, but
  never while winding down in `DONE`.
- `pop_en` is the **critical gating fix**: it is AND-ed with `HREADY`, so a
  word is consumed only on the same clean edge on which the FSM loads it into
  `HWDATA`. Without `HREADY`, wait states would pop words that are never put
  on the bus and the buffer would underflow (the `SLAVE_WAIT=1` hang — see
  `README_CHANGES.md` §4).
- Both pushes and pops can happen in the same cycle; `fifo_cnt` is updated by
  a `case ({push_en, pop_en})` (lines 123–127).

### 3.4 FSM behaviour (lines 134–273)

**IDLE** — `ready_o=1`, all bus outputs IDLE. On `start_i` (line 159):
capture direction/burst/address, pre-compute `wbuf[0..3]` for fixed writes,
set `max_beats`, drive `HADDR/HWRITE/HBURST`, assert `HTRANS=NONSEQ`
(beat 0's address phase), `beat=1`, `err_o=0`, go to `ADDR`.

**ADDR** — on the next clean `HREADY` edge (data phase of beat *N-1* ends):
1. **ERROR check** (lines 195–199): if `HRESP[1]`, raise `err_o`, drive IDLE,
   go to `DONE` — the burst is aborted.
2. **INCR write, buffer empty** (lines 200–205): assert `HTRANS=BUSY`,
   stay in `ADDR`. This is the *data-buffer driven BUSY* the requirement
   asked for. The data phase is extended; nothing is lost.
3. **INCR write, data available** (lines 207–219): load
   `HWDATA <= fifo[fifo_rd]`. If this was the final word
   (`fifo_last`) **or** `beat >= max_beats`, stop the burst (`HTRANS=IDLE`,
   `DONE`); else pipeline the next `SEQ` address (`HADDR = base + beat<<2`,
   `beat++`). With `ENABLE_BUSY` an extra BUSY bubble is emitted first.
4. **Fixed-length write** (lines 221–232): data from `wbuf[beat-1]`; same
   terminal/pipeline logic.
5. **Read** (lines 234–243): no write data; same address pipeline.

**BUSY_ST** (lines 249–258) — used only for the optional `ENABLE_BUSY`
bubble: re-check ERROR, then issue the owed address phase (`HTRANS=SEQ`).

**DONE** (lines 263–269) — last data phase ends here: latch a final ERROR
into `err_o`, drive IDLE, **flush the FIFO** (`fifo_wr/rd/cnt = 0`) so any
leftover pre-loaded words from a boundary-truncated burst cannot leak into the
next transfer, raise `ready_o`.

**Read data** is latched only on `OKAY`: `if (rd_dphase && !HRESP[1])
rdata_o <= HRDATA;` (line 148) — ERROR read data is discarded.

### 3.5 Timing example — INCR write, 5 beats, no waits (from the logs)

```
t       HTRANS  HADDR  HWDATA   comment
N       NONSEQ  0x40   -        beat0 addr phase; wbuf/fifo ready
N+1     SEQ     0x44   0x11     beat0 data + beat1 addr (pipelined)
N+2     SEQ     0x48   0x12
N+3     SEQ     0x4C   0x13
N+4     SEQ     0x50   0x14
N+5     IDLE    -      -        fifo_last seen -> burst done, DONE flush
```

### 3.6 Timing example — data-buffer starvation (TEST 15)

The driver pre-loads only word 0, then withholds word 1:
`NONSEQ(0x80), SEQ(0x84,data0x10), BUSY, BUSY, BUSY, SEQ(0x88,data0x11), ...`
— the three `BUSY` cycles are produced purely by `fifo_empty` in state `ADDR`.

### 3.7 Timing example — 1 KB boundary (TEST 13)

Start `0x3F0` (word 252), request 8 words, `boundary = 4`:
`NONSEQ(0x3F0) SEQ(0x3F4) SEQ(0x3F8) SEQ(0x3FC) IDLE` — exactly 4 beats;
the remaining 4 buffered words are flushed in `DONE`.

---

## 4. `ahb_slave_burst.sv` (RTL slave) — deep dive

### 4.1 Interface & parameters

- `DELAY_READY` — wait states per data phase.
- `ERROR_EN` / `ERROR_ADDR[7:0]` — make one word return ERROR.
- `memory[0:255]` — 1 KB, word-addressed by `HADDR[9:2]`.

### 4.2 Combinational core (lines 43–51)

```
addr_phase = HSEL && HTRANS[1];            // NONSEQ or SEQ
error_pend = reg_active && (reg_addr == ERROR_ADDR);
HRESP      = (ERROR_EN && error_pend) ? 2'b10 : 2'b00;
HREADYOut  = (wait_cnt == 0);
```

`HRESP` is asserted for the *whole* data phase of the ERROR word — including
wait states and BUSY extensions — because it derives from the registered
pending address.

### 4.3 Wait-state generator (lines 56–64)

On a new address phase (`HREADY && addr_phase`) load `wait_cnt = DELAY_READY`;
count down each cycle. `HREADYOut` low ⇒ the master's FSM freezes and its
FIFO stops popping (thanks to the `HREADY` gate on `pop_en`).

### 4.4 Transfer pipeline (lines 70–102)

- **Reset**: clear state and zero the memory (line 73) — makes reads
  deterministic and lets a test prove an ERROR write was never committed.
- On each `HREADY` edge:
  - If a transfer is pending and `HTRANS != BUSY` (lines 75–92):
    - `error_pend` ⇒ terminate the transfer without committing anything
      (the address phase on the bus belongs to the aborted burst and is
      dropped).
    - else: commit a write (`memory[reg_addr] <= HWDATA`), then pipeline the
      new address phase (`reg_active/reg_write/reg_addr`), presenting read
      data immediately for reads.
  - `HTRANS == BUSY` ⇒ **hold** the registered state; sample nothing
    (comment at line 93). This is how the master's buffer-driven BUSY works
    end to end: the slave treats every BUSY as a simple extension.
  - No transfer pending + address phase ⇒ capture it (lines 94–100).

---

## 5. `ahb_slave_bfm.sv` (behavioural slave) — deep dive

- Same parameters and the same pipeline model as the RTL slave, but written
  in a behavioural style with an `initial` block that zeroes the memory
  (line 41).
- Used when `USE_BFM=1`. Because it shares the exact bus protocol, the
  verification layers do not need to know which slave is connected.

---

## 6. `ahb_if.sv` — deep dive

A SystemVerilog interface that bundles the master control signals and the AHB
bus into one handle, so the verification classes only carry a single
`virtual ahb_if`:

- Request side: `start_i, write_i, burst_i, addr_i, data_valid_i, wdata_i,
  data_last_i, data_count_i, data_ack_o, ready_o, rdata_o, err_o`.
- Bus side: `HTRANS, HBURST, HWRITE, HADDR, HWDATA, HREADY, HRESP, HRDATA`.
- `wait_clocks(n)` task blocks for *n* posedges — used by the TB and classes.

---

## 7. `ahb_pkg.sv` — verification package, layer by layer

### 7.1 Types (lines 13–70)

- `ahb_op_e` — the six operations; the two new ones are `OP_WRITE_INCR` and
  `OP_READ_INCR`.
- `ahb_transaction` — stimulus item (op, addr, data, num_beats); the
  constructor fixes the beat count: 4 for INCR4, the supplied value
  (default 8) for INCR.
- `ahb_beat` — one observed bus beat (write/addr/data/error).
- `ERROR_WORD_INDEX = 8'h3F` — the word that returns ERROR (address 0xFC),
  shared by the generator and `tb_top`.

### 7.2 Generator (lines 76–119)

Fixed-but-varied stimulus, 16 transactions:
1–4 SINGLE write/read pair at 0x20 and 0x24,
5–8 INCR4 write/read pair at 0x10 and 0x00,
9–10 INCR write/read with **5** beats at 0x40,
11–12 INCR write/read with **8** beats at 0x60,
13–14 write/read to `ERR_ADDR` (0xFC) → ERROR,
15–16 INCR write/read at `BND_ADDR` (0x3F0) → 8 requested, 4 allowed.

### 7.3 Driver (lines 350–425)

- `push_word(w, last)` (lines 367–378): drives `wdata_i` on the negedge,
  asserts `data_valid_i`, then **waits for `data_ack_o`** (back-pressure) and
  deasserts on the next posedge. This is the exact handshake the master FIFO
  implements.
- `drive_one(tr)` (lines 380–416): for `OP_WRITE_INCR` it first pre-loads all
  `num_beats` words via `push_word` (the buffer is 8 deep, so up to 8 can be
  pre-loaded), then drives `addr_i/write_i/burst_i/data_count_i` and pulses
  `start_i`; it waits for `ready_o` and reports whether the transfer ended
  with ERROR (`err_o`).

### 7.4 Monitor (lines 430–478)

Registers each NONSEQ/SEQ address phase as "pending". A pending beat is
forwarded to the scoreboard only when the bus moves on with a NONSEQ/SEQ or
returns to IDLE — a **BUSY cycle extends the pending beat and samples
nothing** (lines 455–463). `HRESP[1]` is captured as the beat's `error` flag.

### 7.5 Scoreboard (lines 483–533)

Reference-memory model keyed by full address:
- ERROR beats are skipped (no memory update, no compare) — the master
  discarded the data anyway.
- Writes update `ref_mem`; reads are compared, counting PASS/FAIL.

### 7.6 Coverage (lines 124–348)

- `ahb_bus_coverage`: pin-level `covergroup cg_bus` with coverpoints for
  `HTRANS`, `HBURST`, `HWRITE`, `HREADY`, **`HRESP` (the new ERROR bin)**,
  beat position, and cross products (burst×ready, write×ready, trans×burst).
- `ahb_txn_coverage`: per-operation bins for the six ops.
- `ahb_cfg_coverage`: bins over the three config knobs so that merging
  several runs closes the config-combination coverage.

### 7.7 Environment & test (lines 538–610)

`ahb_environment` builds the mailboxes and layers, then `run()` forks the
monitor/scoreboard/coverage tasks concurrently, runs the generator + driver,
drains the pipeline, and prints the scoreboard and coverage summary.
`ahb_test` is a thin wrapper that `tb_top` instantiates.

---

## 8. `tb_top.sv` — layered top

- Parameters `MASTER_BUSY`, `SLAVE_WAIT`, `USE_BFM`; `ERROR_WORD` defaults to
  the package's `ERROR_WORD_INDEX` so the top can never drift from the
  package.
- Instantiates the interface, the master, **both** slaves (HSEL gated by
  `USE_BFM`), and a slave-output mux (lines 49–51).
- The bus-monitor `always` block prints `HREADY, HTRANS, HBURST, HWRITE,
  HADDR, HWDATA, HRDATA, HRESP` every cycle (lines 126–134).
- `initial` runs `ahb_test` after reset; a 100 µs watchdog force-finishes a
  hung simulation (lines 161–165).

---

## 9. `tb_ahb_burst.sv` — flat directed testbench, test map

| Test | What it does | Checks |
|------|--------------|--------|
| 1 | INCR4 write 0x10, data base 0xAA | mem[4..7] == 0xAA..0xAD |
| 2 | INCR4 read back | 4 beat values + rdata_o |
| 3 | SINGLE write 0x20 = 0xDEADBEEF | mem[8] |
| 4 | SINGLE read back | rdata_o |
| 5 | INCR4 write 0x00, base 0x0A | mem[0..3] |
| 6 | INCR4 read back | beats + last |
| 7 | **INCR write, 5 beats** 0x30 | mem[12..16] |
| 8 | **INCR read, 5 beats** | beats + last |
| 9 | **INCR write, 8 beats** 0x60 | mem[24..31] |
| 10 | **INCR read, 8 beats** | beats + last |
| 11 | **ERROR write** to word 63 (0xFC) | err_o asserted **and** mem[63] unchanged (0) |
| 12 | **ERROR read** from 0xFC | err_o asserted |
| 13 | **1 KB boundary write** at 0x3F0, 8 requested | only 4 beats written (mem[252..255]) |
| 14 | **1 KB boundary read** at 0x3F0 | only 4 beats returned |
| 15 | **Buffer-starved INCR write** at 0x80 | ≥1 `HTRANS=BUSY` cycle observed + data intact |

Helper tasks: `push_data` (drives the `data_valid_i/data_ack_o` handshake),
`do_write_single/do_read_single/do_write_incr/do_read_incr/
do_write_incr_starved`, and checkers `check_mem`, `check_rdata`,
`check_beat`. A counter (monitor) counts BUSY cycles for test 15.

---

## 10. Where each requirement lives in the code

| Requirement | Where |
|-------------|-------|
| Comments on ifs and declarations | every file — header blocks + per-line comments |
| ERROR response in the master | `ahb_master_burst.sv` lines 148, 195–199, 250–252, 264 |
| BUSY from the data buffer | `ahb_master_burst.sv` lines 200–205 (`fifo_empty`) |
| INCR with different lengths | `ahb_master_burst.sv` lines 168–181, 207–219; generator lines 103–107; tests 7–10 |
| 1 KB boundary restriction | `ahb_master_burst.sv` lines 93, 168–177, 209/223/235; tests 13–14 |
