//=============================================================================
// File: axi_fifo_tb.sv
// Description: Testbench for AXI FIFO (Corrected)
//=============================================================================

`timescale 1ns/1ps

`define SIMULATION

module axi_fifo_tb;

    localparam DATA_WIDTH  = 32;
    localparam FIFO_DEPTH  = 16;
    localparam CLK_PERIOD  = 10;

    logic                    aclk;
    logic                    aresetn;

    logic [DATA_WIDTH-1:0]   s_axis_tdata;
    logic                    s_axis_tvalid;
    logic                    s_axis_tready;
    logic                    s_axis_tlast;

    logic [DATA_WIDTH-1:0]   m_axis_tdata;
    logic                    m_axis_tvalid;
    logic                    m_axis_tready;
    logic                    m_axis_tlast;

    logic                    fifo_full;
    logic                    fifo_empty;
    logic                    fifo_almost_full;
    logic                    fifo_almost_empty;
    logic [$clog2(FIFO_DEPTH):0] fifo_count;

    axi_fifo #(
        .DATA_WIDTH     (DATA_WIDTH),
        .FIFO_DEPTH     (FIFO_DEPTH),
        .ALMOST_FULL_TH (2),
        .ALMOST_EMPTY_TH(2)
    ) dut (
        .aclk              (aclk),
        .aresetn           (aresetn),
        .s_axis_tdata      (s_axis_tdata),
        .s_axis_tvalid     (s_axis_tvalid),
        .s_axis_tready     (s_axis_tready),
        .s_axis_tlast      (s_axis_tlast),
        .m_axis_tdata      (m_axis_tdata),
        .m_axis_tvalid     (m_axis_tvalid),
        .m_axis_tready     (m_axis_tready),
        .m_axis_tlast      (m_axis_tlast),
        .fifo_full         (fifo_full),
        .fifo_empty        (fifo_empty),
        .fifo_almost_full  (fifo_almost_full),
        .fifo_almost_empty (fifo_almost_empty),
        .fifo_count        (fifo_count)
    );

    // Clock
    initial aclk = 0;
    always #(CLK_PERIOD/2) aclk = ~aclk;

    // VCD for Waveform
    initial begin
        $dumpfile("axi_fifo_wave.vcd");
        $dumpvars(0, axi_fifo_tb);
    end

    task automatic write_data(
        input logic [DATA_WIDTH-1:0] data,
        input logic                  last
    );
        @(posedge aclk);
        s_axis_tdata  = data;
        s_axis_tvalid = 1'b1;
        s_axis_tlast  = last;
        wait (s_axis_tready == 1'b1);
        @(posedge aclk);
        s_axis_tvalid = 1'b0;
        s_axis_tlast  = 1'b0;
        $display("[WRITE] Data: 0x%08h, Last: %b, Count: %0d, Full: %b",
                 data, last, fifo_count, fifo_full);
    endtask

    task automatic read_data(output logic [DATA_WIDTH-1:0] data);
        @(posedge aclk);
        m_axis_tready = 1'b1;
        wait (m_axis_tvalid == 1'b1);
        data = m_axis_tdata;
        @(posedge aclk);
        m_axis_tready = 1'b0;
        $display("[READ]  Data: 0x%08h, Last: %b, Count: %0d, Empty: %b",
                 data, m_axis_tlast, fifo_count, fifo_empty);
    endtask

    logic [DATA_WIDTH-1:0] read_val;
    integer i;

    initial begin
        aresetn       = 1'b0;
        s_axis_tdata  = '0;
        s_axis_tvalid = 1'b0;
        s_axis_tlast  = 1'b0;
        m_axis_tready = 1'b0;

        repeat(5) @(posedge aclk);
        aresetn = 1'b1;
        repeat(2) @(posedge aclk);

        $display("\n========== TEST 1: Basic Write/Read ==========");
        write_data(32'hDEAD_BEEF, 1'b0);
        write_data(32'hCAFE_BABE, 1'b0);
        write_data(32'h1234_5678, 1'b1);
        read_data(read_val);
        read_data(read_val);
        read_data(read_val);

        $display("\n========== TEST 2: Fill FIFO ==========");
        for (i = 0; i < FIFO_DEPTH; i++) begin
            write_data(i, (i == FIFO_DEPTH-1));
        end
        $display("FIFO Full: %b, Count: %0d", fifo_full, fifo_count);

        $display("\n========== TEST 3: Drain FIFO ==========");
        for (i = 0; i < FIFO_DEPTH; i++) begin
            read_data(read_val);
        end
        $display("FIFO Empty: %b, Count: %0d", fifo_empty, fifo_count);

        $display("\n========== TEST 4: Simultaneous Read/Write ==========");
        fork
            begin
                for (int w = 0; w < 8; w++)
                    write_data(32'hA000_0000 + w, (w==7));
            end
            begin
                repeat(2) @(posedge aclk);
                for (int r = 0; r < 8; r++)
                    read_data(read_val);
            end
        join

        $display("\n========== All Tests Passed ==========\n");
        repeat(5) @(posedge aclk);
        $finish;
    end

    initial begin
        #10000;
        $error("Simulation TIMEOUT!");
        $finish;
    end

endmodule
