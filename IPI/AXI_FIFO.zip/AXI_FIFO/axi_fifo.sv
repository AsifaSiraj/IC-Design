//=============================================================================
// File: axi_fifo.sv
// Description: AXI4-Stream FIFO (Corrected Version)
//=============================================================================

`timescale 1ns/1ps

module axi_fifo #(
    parameter DATA_WIDTH      = 32,
    parameter FIFO_DEPTH      = 16,
    parameter ALMOST_FULL_TH  = 2,
    parameter ALMOST_EMPTY_TH = 2
)(
    input  logic                    aclk,
    input  logic                    aresetn,

    // AXI4-Stream Slave (Write)
    input  logic [DATA_WIDTH-1:0]   s_axis_tdata,
    input  logic                    s_axis_tvalid,
    output logic                    s_axis_tready,
    input  logic                    s_axis_tlast,

    // AXI4-Stream Master (Read)
    output logic [DATA_WIDTH-1:0]   m_axis_tdata,
    output logic                    m_axis_tvalid,
    input  logic                    m_axis_tready,
    output logic                    m_axis_tlast,

    // Status
    output logic                    fifo_full,
    output logic                    fifo_empty,
    output logic                    fifo_almost_full,
    output logic                    fifo_almost_empty,
    output logic [$clog2(FIFO_DEPTH):0] fifo_count
);

    localparam ADDR_WIDTH = $clog2(FIFO_DEPTH);
    localparam MEM_WIDTH  = DATA_WIDTH + 1;

    // FIFO Memory
    logic [MEM_WIDTH-1:0]   mem [0:FIFO_DEPTH-1];
    logic [ADDR_WIDTH-1:0]  wr_ptr;
    logic [ADDR_WIDTH-1:0]  rd_ptr;
    logic [ADDR_WIDTH:0]    count;

    logic                   wr_en;
    logic                   rd_en;

    // Handshake
    assign wr_en = s_axis_tvalid & s_axis_tready;
    assign rd_en = m_axis_tvalid & m_axis_tready;

    // Status Flags (FIXED: full at FIFO_DEPTH, not FIFO_DEPTH-1)
    assign fifo_full         = (count == FIFO_DEPTH);
    assign fifo_empty        = (count == 0);
    assign fifo_almost_full  = (count >= (FIFO_DEPTH - ALMOST_FULL_TH));
    assign fifo_almost_empty = (count <= ALMOST_EMPTY_TH);
    assign fifo_count        = count;

    // Ready/Valid (FIXED)
    assign s_axis_tready = ~fifo_full;
    assign m_axis_tvalid = ~fifo_empty;

    // Write Pointer
    always_ff @(posedge aclk or negedge aresetn) begin
        if (!aresetn)
            wr_ptr <= '0;
        else if (wr_en)
            wr_ptr <= wr_ptr + 1'b1;
    end

    // Read Pointer
    always_ff @(posedge aclk or negedge aresetn) begin
        if (!aresetn)
            rd_ptr <= '0;
        else if (rd_en)
            rd_ptr <= rd_ptr + 1'b1;
    end

    // Count Logic (FIXED: proper wrap-around handling)
    always_ff @(posedge aclk or negedge aresetn) begin
        if (!aresetn)
            count <= '0;
        else if (wr_en && !rd_en)
            count <= count + 1'b1;
        else if (!wr_en && rd_en)
            count <= count - 1'b1;
        else
            count <= count;
    end

    // Memory Write
    always_ff @(posedge aclk) begin
        if (wr_en)
            mem[wr_ptr] <= {s_axis_tlast, s_axis_tdata};
    end

    // Memory Read (FIXED: combinational output for immediate data)
    always_comb begin
        if (fifo_empty) begin
            m_axis_tdata = '0;
            m_axis_tlast = '0;
        end else begin
            {m_axis_tlast, m_axis_tdata} = mem[rd_ptr];
        end
    end

    // Assertions
    `ifdef SIMULATION
        property p_no_overflow;
            @(posedge aclk) disable iff (!aresetn)
            (fifo_full && s_axis_tvalid) |-> (s_axis_tready == 0);
        endproperty
        assert property (p_no_overflow)
            else $error("FIFO Overflow at %0t", $time);

        property p_no_underflow;
            @(posedge aclk) disable iff (!aresetn)
            (fifo_empty && m_axis_tready) |-> (m_axis_tvalid == 0);
        endproperty
        assert property (p_no_underflow)
            else $error("FIFO Underflow at %0t", $time);
    `endif

endmodule
