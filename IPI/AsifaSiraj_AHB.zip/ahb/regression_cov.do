# ============================================================
# regression_cov.do  -  runs all corner combinations, merges UCDBs
# ============================================================
quit -sim
vlib work
vmap work work

vlog -sv -work work +cover=bcesf ahb_master_burst.sv
vlog -sv -work work +cover=bcesf ahb_slave_burst.sv
vlog -sv -work work +cover=bcesf ahb_slave_bfm.sv
vlog -sv -work work ahb_if.sv
vlog -sv -work work +cover=bcesf ahb_pkg.sv
vlog -sv -work work tb_top.sv

set busy_vals {0 1}
set wait_vals {0 1}
set bfm_vals  {0 1}
set idx 0

file mkdir covdb

foreach b $busy_vals {
  foreach w $wait_vals {
    foreach f $bfm_vals {
      vsim -voptargs=+acc -coverage work.tb_top \
           -GMASTER_BUSY=$b -GSLAVE_WAIT=$w -GUSE_BFM=$f
      run -all
      coverage save -onexit -directory covdb run_${idx}.ucdb
      quit -sim
      incr idx
    }
  }
}

vcover merge covdb/merged.ucdb covdb/run_*.ucdb
vcover report covdb/merged.ucdb -details -all
