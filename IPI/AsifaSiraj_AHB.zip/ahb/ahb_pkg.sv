`timescale 1ns/1ps
//=======================================================================
// Compile guard
//=======================================================================
`ifndef AHB_PKG_SV
`define AHB_PKG_SV

package ahb_pkg;

  //=====================================================================
  // Operation enumeration
  //=====================================================================
  typedef enum bit [1:0] {
    OP_WRITE_SINGLE = 2'd0,
    OP_READ_SINGLE  = 2'd1,
    OP_WRITE_BURST  = 2'd2,
    OP_READ_BURST   = 2'd3
  } ahb_op_e;

  //=====================================================================
  // Transaction (stimulus item)
  //=====================================================================
  class ahb_transaction;
    ahb_op_e   op;
    bit [31:0] addr;
    bit [31:0] data;
    int        num_beats;

    function new(ahb_op_e op = OP_WRITE_SINGLE,
                 bit [31:0] addr = 32'h0,
                 bit [31:0] data = 32'h0);
      this.op   = op;
      this.addr = addr;
      this.data = data;
      this.num_beats = (op == OP_WRITE_BURST || op == OP_READ_BURST) ? 4 : 1;
    endfunction

    function string convert2string();
      return $sformatf("op=%s addr=0x%08h data=0x%08h beats=%0d",
                        op.name(), addr, data, num_beats);
    endfunction
  endclass

  //=====================================================================
  // Observed bus beat
  //=====================================================================
  class ahb_beat;
    bit        write;
    bit [31:0] addr;
    bit [31:0] data;

    function string convert2string();
      return $sformatf("%s addr=0x%08h data=0x%08h",
                        write ? "WRITE" : "READ ", addr, data);
    endfunction
  endclass

  //=====================================================================
  // Generator
  //=====================================================================
  class ahb_generator;
    mailbox #(ahb_transaction) gen2drv;
    int                        num_txns;

    function new(mailbox #(ahb_transaction) gen2drv);
      this.gen2drv  = gen2drv;
      this.num_txns = 0;
    endfunction

    task run();
      ahb_transaction tr;

      tr = new(OP_WRITE_SINGLE, 32'h20, 32'hDEAD_BEEF); gen2drv.put(tr); num_txns++;
      tr = new(OP_READ_SINGLE , 32'h20, 32'h0        ); gen2drv.put(tr); num_txns++;

      tr = new(OP_WRITE_SINGLE, 32'h24, 32'hCAFE_0002); gen2drv.put(tr); num_txns++;
      tr = new(OP_READ_SINGLE , 32'h24, 32'h0        ); gen2drv.put(tr); num_txns++;

      tr = new(OP_WRITE_BURST , 32'h10, 32'h0000_00A0); gen2drv.put(tr); num_txns++;
      tr = new(OP_READ_BURST  , 32'h10, 32'h0        ); gen2drv.put(tr); num_txns++;

      tr = new(OP_WRITE_BURST , 32'h00, 32'h0000_000A); gen2drv.put(tr); num_txns++;
      tr = new(OP_READ_BURST  , 32'h00, 32'h0        ); gen2drv.put(tr); num_txns++;

      $display("[%0t] GEN : generated %0d transactions", $time, num_txns);
    endtask
  endclass

  //=====================================================================
  // ahb_bus_coverage : samples pins every clock (protocol coverage)
  //=====================================================================
  class ahb_bus_coverage;
    virtual ahb_if vif;

    bit [1:0] cov_htrans;
    bit [2:0] cov_hburst;
    bit       cov_hwrite;
    bit       cov_hready;
    bit [1:0] cov_beat;

    covergroup cg_bus;
      option.per_instance = 1;
      option.name         = "cg_ahb_bus";

      cp_trans : coverpoint cov_htrans {
        bins idle   = {2'b00};
        bins busy   = {2'b01};
        bins nonseq = {2'b10};
        bins seq    = {2'b11};
      }

      cp_burst : coverpoint cov_hburst iff (cov_htrans[1]) {
        bins single = {3'd0};
        bins incr4  = {3'd3};
      }

      cp_write : coverpoint cov_hwrite iff (cov_htrans[1]) {
        bins rd = {1'b0};
        bins wr = {1'b1};
      }

      cp_ready : coverpoint cov_hready {
        bins ready   = {1'b1};
        bins wait_st = {1'b0};
      }

      cp_beat : coverpoint cov_beat iff (cov_htrans[1]) {
        bins beat0 = {2'd0};
        bins beat1 = {2'd1};
        bins beat2 = {2'd2};
        bins beat3 = {2'd3};
      }

      cx_burst_ready : cross cp_burst, cp_ready;
      cx_write_ready : cross cp_write, cp_ready;
      cx_trans_burst : cross cp_trans, cp_burst;
    endgroup

    function new(virtual ahb_if vif);
      this.vif = vif;
      cg_bus   = new();
    endfunction

    task run();
      forever begin
        @(posedge vif.HCLK);
        if (vif.HRESETn === 1'b1) begin
          cov_htrans = vif.HTRANS;
          cov_hburst = vif.HBURST;
          cov_hwrite = vif.HWRITE;
          cov_hready = vif.HREADY;
          cov_beat   = vif.HADDR[3:2];
          cg_bus.sample();
        end
      end
    endtask

    function real get_coverage();
      return cg_bus.get_inst_coverage();
    endfunction
  endclass

  //=====================================================================
  // ahb_txn_coverage : samples generated/driven transactions
  //=====================================================================
  class ahb_txn_coverage;
    ahb_op_e   cov_op;
    bit [31:0] cov_addr;

    ahb_op_e   prev_op;
    bit [31:0] prev_addr;
    bit        have_prev;

    typedef enum bit [1:0] {
      PAIR_NONE, PAIR_SINGLE_WR_RD, PAIR_BURST_WR_RD, PAIR_OTHER
    } pair_e;
    pair_e cov_pair;

    covergroup cg_txn;
      option.per_instance = 1;
      option.name         = "cg_ahb_txn";

      cp_op : coverpoint cov_op {
        bins wr_single = {OP_WRITE_SINGLE};
        bins rd_single = {OP_READ_SINGLE};
        bins wr_burst  = {OP_WRITE_BURST};
        bins rd_burst  = {OP_READ_BURST};
      }

      cp_addr : coverpoint cov_addr {
        bins addr_00 = {32'h00};
        bins addr_10 = {32'h10};
        bins addr_20 = {32'h20};
        bins addr_24 = {32'h24};
        bins others  = default;
      }

      cx_op_addr : cross cp_op, cp_addr;

      cp_pair : coverpoint cov_pair {
        bins single_wr_then_rd = {PAIR_SINGLE_WR_RD};
        bins burst_wr_then_rd  = {PAIR_BURST_WR_RD};
        bins other_seq         = {PAIR_OTHER};
        ignore_bins none_bin   = {PAIR_NONE};
      }
    endgroup

    function new();
      cg_txn    = new();
      have_prev = 1'b0;
      prev_op   = OP_WRITE_SINGLE;
      prev_addr = 32'h0;
    endfunction

    function void sample(ahb_transaction tr);
      cov_op   = tr.op;
      cov_addr = tr.addr;

      if (!have_prev)
        cov_pair = PAIR_NONE;
      else if (prev_op == OP_WRITE_SINGLE && tr.op == OP_READ_SINGLE && prev_addr == tr.addr)
        cov_pair = PAIR_SINGLE_WR_RD;
      else if (prev_op == OP_WRITE_BURST && tr.op == OP_READ_BURST && prev_addr == tr.addr)
        cov_pair = PAIR_BURST_WR_RD;
      else
        cov_pair = PAIR_OTHER;

      cg_txn.sample();

      prev_op   = tr.op;
      prev_addr = tr.addr;
      have_prev = 1'b1;
    endfunction

    function real get_coverage();
      return cg_txn.get_inst_coverage();
    endfunction
  endclass

  //=====================================================================
  // ahb_cfg_coverage : records which parameter combination this run used
  //=====================================================================
  class ahb_cfg_coverage;
    bit cov_master_busy;
    bit cov_slave_wait;
    bit cov_use_bfm;

    covergroup cg_cfg;
      option.per_instance = 1;
      option.at_least     = 1;
      option.name         = "cg_ahb_cfg";

      cp_busy : coverpoint cov_master_busy { bins off = {0}; bins on = {1}; }
      cp_wait : coverpoint cov_slave_wait  { bins off = {0}; bins on = {1}; }
      cp_bfm  : coverpoint cov_use_bfm     { bins rtl = {0}; bins bfm = {1}; }

      cx_all : cross cp_busy, cp_wait, cp_bfm;
    endgroup

    function new();
      cg_cfg = new();
    endfunction

    function void sample(int master_busy, int slave_wait, int use_bfm);
      cov_master_busy = (master_busy != 0);
      cov_slave_wait  = (slave_wait  != 0);
      cov_use_bfm     = (use_bfm     != 0);
      cg_cfg.sample();
    endfunction

    function real get_coverage();
      return cg_cfg.get_inst_coverage();
    endfunction
  endclass

  //=====================================================================
  // Driver (samples transaction coverage)
  //=====================================================================
  class ahb_driver;
    virtual ahb_if vif;
    mailbox #(ahb_transaction) gen2drv;
    ahb_txn_coverage txn_cov;

    function new(virtual ahb_if vif,
                 mailbox #(ahb_transaction) gen2drv,
                 ahb_txn_coverage txn_cov = null);
      this.vif     = vif;
      this.gen2drv = gen2drv;
      this.txn_cov = txn_cov;
    endfunction

    task automatic drive_one(ahb_transaction tr);
      @(negedge vif.HCLK);
      vif.addr_i  = tr.addr;
      vif.wdata_i = tr.data;
      case (tr.op)
        OP_WRITE_SINGLE: begin vif.write_i = 1'b1; vif.burst_i = 1'b0; end
        OP_READ_SINGLE : begin vif.write_i = 1'b0; vif.burst_i = 1'b0; end
        OP_WRITE_BURST : begin vif.write_i = 1'b1; vif.burst_i = 1'b1; end
        OP_READ_BURST  : begin vif.write_i = 1'b0; vif.burst_i = 1'b1; end
        default        : begin vif.write_i = 1'b0; vif.burst_i = 1'b0; end
      endcase
      vif.start_i = 1'b1;

      @(posedge vif.HCLK);
      #1;
      vif.start_i = 1'b0;

      wait (vif.ready_o === 1'b1);

      $display("[%0t] DRV : completed %s", $time, tr.convert2string());

      if (txn_cov != null) txn_cov.sample(tr);
    endtask

    task run(int n_txns);
      ahb_transaction tr;
      repeat (n_txns) begin
        gen2drv.get(tr);
        drive_one(tr);
      end
    endtask
  endclass

  //=====================================================================
  // Monitor
  //=====================================================================
  class ahb_monitor;
    virtual ahb_if vif;
    mailbox #(ahb_beat) mon2scb;

    function new(virtual ahb_if vif, mailbox #(ahb_beat) mon2scb);
      this.vif     = vif;
      this.mon2scb = mon2scb;
    endfunction

    task run();
      bit        pend_valid;
      bit        pend_write;
      bit [31:0] pend_addr;
      ahb_beat   b;

      pend_valid = 1'b0;

      forever begin
        @(posedge vif.HCLK);
        if (vif.HRESETn === 1'b0) begin
          pend_valid = 1'b0;
        end else if (vif.HREADY === 1'b1) begin
          if (pend_valid) begin
            b       = new();
            b.write = pend_write;
            b.addr  = pend_addr;
            b.data  = pend_write ? vif.HWDATA : vif.HRDATA;
            mon2scb.put(b);
            $display("[%0t] MON : %s", $time, b.convert2string());
          end
          pend_valid = vif.HTRANS[1];
          pend_write = vif.HWRITE;
          pend_addr  = vif.HADDR;
        end
      end
    endtask
  endclass

  //=====================================================================
  // Scoreboard
  //=====================================================================
  class ahb_scoreboard;
    mailbox #(ahb_beat) mon2scb;
    bit [31:0]          ref_mem[bit [31:0]];
    int                 pass_cnt;
    int                 fail_cnt;

    function new(mailbox #(ahb_beat) mon2scb);
      this.mon2scb = mon2scb;
      pass_cnt = 0;
      fail_cnt = 0;
    endfunction

    task run();
      ahb_beat b;
      forever begin
        mon2scb.get(b);
        if (b.write) begin
          ref_mem[b.addr] = b.data;
          $display("[%0t] SCB : WRITE  addr=0x%08h data=0x%08h (ref updated)",
                    $time, b.addr, b.data);
        end else begin
          if (ref_mem.exists(b.addr)) begin
            if (ref_mem[b.addr] === b.data) begin
              pass_cnt++;
              $display("[%0t] SCB : PASS   addr=0x%08h data=0x%08h",
                        $time, b.addr, b.data);
            end else begin
              fail_cnt++;
              $display("[%0t] SCB : FAIL   addr=0x%08h data=0x%08h expected=0x%08h",
                        $time, b.addr, b.data, ref_mem[b.addr]);
            end
          end else begin
            $display("[%0t] SCB : WARN   read from address 0x%08h before any write",
                      $time, b.addr);
          end
        end
      end
    endtask

    function void report();
      $display("================================================");
      $display("   SCOREBOARD RESULT :  PASS=%0d   FAIL=%0d", pass_cnt, fail_cnt);
      $display(fail_cnt == 0 ? "   STATUS : ALL CHECKS PASSED ***"
                              : "   STATUS : SOME CHECKS FAILED !!!");
      $display("================================================");
    endfunction
  endclass

  //=====================================================================
  // Environment
  //=====================================================================
  class ahb_environment;
    virtual ahb_if vif;

    mailbox #(ahb_transaction) gen2drv;
    mailbox #(ahb_beat)        mon2scb;

    ahb_generator     gen;
    ahb_driver        drv;
    ahb_monitor       mon;
    ahb_scoreboard    scb;

    ahb_bus_coverage  bus_cov;
    ahb_txn_coverage  txn_cov;
    ahb_cfg_coverage  cfg_cov;

    function new(virtual ahb_if vif);
      this.vif = vif;
      gen2drv  = new();
      mon2scb  = new();

      gen     = new(gen2drv);
      txn_cov = new();
      bus_cov = new(vif);
      cfg_cov = new();

      drv = new(vif, gen2drv, txn_cov);
      mon = new(vif, mon2scb);
      scb = new(mon2scb);
    endfunction

    task run(int master_busy = 0, int slave_wait = 0, int use_bfm = 0);
      cfg_cov.sample(master_busy, slave_wait, use_bfm);

      fork
        mon.run();
        scb.run();
        bus_cov.run();
      join_none

      gen.run();
      drv.run(gen.num_txns);

      vif.wait_clocks(10);

      scb.report();
      report_coverage();
    endtask

    function void report_coverage();
      $display("================================================");
      $display("   FUNCTIONAL COVERAGE SUMMARY");
      $display("   Bus-level   coverage : %0.2f %%", bus_cov.get_coverage());
      $display("   Transaction coverage : %0.2f %%", txn_cov.get_coverage());
      $display("   Config combo covered : %0.2f %%", cfg_cov.get_coverage());
      $display("   (merge multiple runs' .ucdb to close Config coverage)");
      $display("================================================");
    endfunction
  endclass

  //=====================================================================
  // Test
  //=====================================================================
  class ahb_test;
    ahb_environment env;

    function new(virtual ahb_if vif);
      env = new(vif);
    endfunction

    task run(int master_busy = 0, int slave_wait = 0, int use_bfm = 0);
      env.run(master_busy, slave_wait, use_bfm);
    endtask
  endclass

endpackage

`endif // AHB_PKG_SV
