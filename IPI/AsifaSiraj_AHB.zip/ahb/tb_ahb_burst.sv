`timescale 1ns/1ps
module tb_ahb_burst;

  // ---- configuration: flip these to observe stalls ----
  parameter MASTER_BUSY = 0;   // 1 => master inserts BUSY between burst beats
  parameter SLAVE_WAIT  = 0;   // n => n wait states per data phase
  parameter USE_BFM     = 0;   // 1 => use behavioral BFM instead of RTL slave

  reg         HCLK, HRESETn;
  wire        HREADY, HREADY_rtl, HREADY_bfm;
  wire [1:0]  HRESP,  HRESP_rtl,  HRESP_bfm;
  wire [31:0] HRDATA, HRDATA_rtl, HRDATA_bfm;
  wire [1:0]  HTRANS; wire [2:0] HBURST; wire HWRITE;
  wire [31:0] HADDR, HWDATA;

  reg         start_i, write_i, burst_i;
  reg  [31:0] addr_i, wdata_i;
  wire        ready_o; wire [31:0] rdata_o;

  assign HREADY = (USE_BFM!=0) ? HREADY_bfm : HREADY_rtl;
  assign HRDATA = (USE_BFM!=0) ? HRDATA_bfm : HRDATA_rtl;
  assign HRESP  = (USE_BFM!=0) ? HRESP_bfm  : HRESP_rtl;

  ahb_master_burst #(.ENABLE_BUSY(MASTER_BUSY)) u_master (
    .HCLK(HCLK), .HRESETn(HRESETn), .HREADY(HREADY), .HRESP(HRESP), .HRDATA(HRDATA),
    .start_i(start_i), .write_i(write_i), .burst_i(burst_i),
    .addr_i(addr_i), .wdata_i(wdata_i), .ready_o(ready_o), .rdata_o(rdata_o),
    .HTRANS(HTRANS), .HBURST(HBURST), .HWRITE(HWRITE), .HADDR(HADDR), .HWDATA(HWDATA)
  );

  ahb_slave_burst #(.DELAY_READY(SLAVE_WAIT)) u_slave (
    .HCLK(HCLK), .HRESETn(HRESETn), .HSEL(USE_BFM==0),
    .HADDR(HADDR), .HWRITE(HWRITE), .HTRANS(HTRANS), .HWDATA(HWDATA),
    .HREADY(HREADY), .HREADYOut(HREADY_rtl), .HRESP(HRESP_rtl), .HRDATA(HRDATA_rtl)
  );

  ahb_slave_bfm #(.DELAY_READY(SLAVE_WAIT)) u_bfm (
    .HCLK(HCLK), .HRESETn(HRESETn), .HSEL(USE_BFM!=0),
    .HADDR(HADDR), .HWRITE(HWRITE), .HTRANS(HTRANS), .HWDATA(HWDATA),
    .HREADY(HREADY), .HREADYOut(HREADY_bfm), .HRESP(HRESP_bfm), .HRDATA(HRDATA_bfm)
  );

  initial HCLK = 1'b0;
  always #5 HCLK = ~HCLK;

  initial begin $dumpfile("ahb_burst.vcd"); $dumpvars(0,tb_ahb_burst); end

  integer pass_count, fail_count;

  // 1-stage read-beat capture: latch HRDATA on the HREADY edge that ends
  // each read data phase (works with waits and with BUSY).
  reg        mp1;
  reg [31:0] beat_data [0:3];
  integer    beat_wr_idx;
  always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin mp1<=0; beat_wr_idx<=0; end
    else if (HREADY) begin
      if (mp1 && beat_wr_idx < 4) begin
        beat_data[beat_wr_idx] <= HRDATA;
        beat_wr_idx <= beat_wr_idx + 1;
      end
      mp1 <= (HTRANS[1] && !HWRITE);
    end
  end

  initial begin
    HRESETn=0; start_i=0; write_i=0; burst_i=0; addr_i=0; wdata_i=0;
    pass_count=0; fail_count=0;
    $display("================================================");
    $display("   AHB BURST TB  BUSY=%0d WAIT=%0d BFM=%0d", MASTER_BUSY, SLAVE_WAIT, USE_BFM);
    $display("================================================");
    repeat (4) @(posedge HCLK); HRESETn=1;
    $display("[%0t] Reset Released", $time);
    repeat (2) @(posedge HCLK);

    $display("\n[%0t] === TEST 1: INCR4 Burst Write ===", $time);
    do_write_burst(32'h10, 32'hAA); repeat (2) @(posedge HCLK);
    check_mem(4,32'hAA,"T1-Beat0"); check_mem(5,32'hAB,"T1-Beat1");
    check_mem(6,32'hAC,"T1-Beat2"); check_mem(7,32'hAD,"T1-Beat3");

    $display("\n[%0t] === TEST 2: INCR4 Burst Read ===", $time);
    clear_beat_buf(); do_read_burst(32'h10); repeat (1) @(posedge HCLK);
    check_beat(0,32'hAA,"T2-B0"); check_beat(1,32'hAB,"T2-B1");
    check_beat(2,32'hAC,"T2-B2"); check_beat(3,32'hAD,"T2-B3");
    check_rdata(32'hAD,"T2-Last ");

    $display("\n[%0t] === TEST 3: Single Write ===", $time);
    do_write_single(32'h20,32'hDEADBEEF); repeat (2) @(posedge HCLK);
    check_mem(8,32'hDEADBEEF,"T3-Single");

    $display("\n[%0t] === TEST 4: Single Read ===", $time);
    clear_beat_buf(); do_read_single(32'h20); repeat (1) @(posedge HCLK);
    check_rdata(32'hDEADBEEF,"T4-SingRd");

    $display("\n[%0t] === TEST 5: INCR4 Burst Write #2 ===", $time);
    do_write_burst(32'h00,32'hA); repeat (2) @(posedge HCLK);
    check_mem(0,32'hA,"T5-Beat0"); check_mem(1,32'hB,"T5-Beat1");
    check_mem(2,32'hC,"T5-Beat2"); check_mem(3,32'hD,"T5-Beat3");

    $display("\n[%0t] === TEST 6: INCR4 Burst Read #2 ===", $time);
    clear_beat_buf(); do_read_burst(32'h00); repeat (1) @(posedge HCLK);
    check_beat(0,32'hA,"T6-B0"); check_beat(1,32'hB,"T6-B1");
    check_beat(2,32'hC,"T6-B2"); check_beat(3,32'hD,"T6-B3");
    check_rdata(32'hD,"T6-Last ");

    repeat (3) @(posedge HCLK);
    $display("\n================================================");
    $display("   PASSED : %0d", pass_count);
    $display("   FAILED : %0d", fail_count);
    $display(fail_count==0 ? "   STATUS : ALL TESTS PASSED ***"
                           : "   STATUS : SOME TESTS FAILED !!!");
    $display("================================================");
    $finish;
  end

  task clear_beat_buf; integer i; begin
    @(negedge HCLK); beat_wr_idx=0;
    for (i=0;i<4;i=i+1) beat_data[i]=32'hx;
  end endtask

  task do_write_burst; input [31:0] a,d; begin
    @(negedge HCLK); start_i=1; write_i=1; burst_i=1; addr_i=a; wdata_i=d;
    @(posedge HCLK); #1 start_i=0; wait(ready_o===1'b1);
  end endtask
  task do_read_burst; input [31:0] a; begin
    @(negedge HCLK); start_i=1; write_i=0; burst_i=1; addr_i=a; wdata_i=0;
    @(posedge HCLK); #1 start_i=0; wait(ready_o===1'b1);
  end endtask
  task do_write_single; input [31:0] a,d; begin
    @(negedge HCLK); start_i=1; write_i=1; burst_i=0; addr_i=a; wdata_i=d;
    @(posedge HCLK); #1 start_i=0; wait(ready_o===1'b1);
  end endtask
  task do_read_single; input [31:0] a; begin
    @(negedge HCLK); start_i=1; write_i=0; burst_i=0; addr_i=a; wdata_i=0;
    @(posedge HCLK); #1 start_i=0; wait(ready_o===1'b1);
  end endtask

  task check_mem; input [3:0] idx; input [31:0] exp; input [79:0] label;
    reg [31:0] m; begin
      m = (USE_BFM!=0) ? u_bfm.memory[idx] : u_slave.memory[idx];
      if (m===exp) begin $display("[%0t] PASS %s | mem[%0d]=0x%08h",$time,label,idx,m); pass_count=pass_count+1; end
      else begin $display("[%0t] FAIL %s | mem[%0d]=0x%08h Expected=0x%08h",$time,label,idx,m,exp); fail_count=fail_count+1; end
  end endtask

  task check_rdata; input [31:0] exp; input [79:0] label; begin
    if (rdata_o===exp) begin $display("[%0t] PASS %s | rdata_o=0x%08h",$time,label,rdata_o); pass_count=pass_count+1; end
    else begin $display("[%0t] FAIL %s | rdata_o=0x%08h Expected=0x%08h",$time,label,rdata_o,exp); fail_count=fail_count+1; end
  end endtask

  task check_beat; input integer idx; input [31:0] exp; input [79:0] label; begin
    if (beat_data[idx]===exp) begin $display("[%0t] PASS %s | beat[%0d]=0x%08h",$time,label,idx,beat_data[idx]); pass_count=pass_count+1; end
    else begin $display("[%0t] FAIL %s | beat[%0d]=0x%08h Expected=0x%08h",$time,label,idx,beat_data[idx],exp); fail_count=fail_count+1; end
  end endtask

  always @(posedge HCLK) begin
    if (HRESETn && (HTRANS!=2'b00 || !HREADY))
      $display("[MON %0t] HREADY=%0b HTRANS=%0d(%s) HBURST=%0d HWRITE=%0b HADDR=0x%08h HWDATA=0x%08h HRDATA=0x%08h",
               $time, HREADY, HTRANS,
               (HTRANS==2'b10)?"NONSEQ":(HTRANS==2'b11)?"SEQ   ":
               (HTRANS==2'b01)?"BUSY  ":"IDLE  ",
               HBURST, HWRITE, HADDR, HWDATA, HRDATA);
  end

  initial begin #100000; $display("[ERROR] TIMEOUT"); $finish; end
endmodule