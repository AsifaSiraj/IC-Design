`timescale 1ns/1ps
//=======================================================================
// Compile guard
//=======================================================================
`ifndef TB_TOP_SV
`define TB_TOP_SV

import ahb_pkg::*;

module tb_top;

  //---------------------------------------------------------------------
  // Configuration knobs (override at simulation launch, e.g.
  //   vsim -GMASTER_BUSY=1 -GSLAVE_WAIT=2 -GUSE_BFM=0 work.tb_top
  //---------------------------------------------------------------------
  parameter MASTER_BUSY = 0;   // 1 => master inserts HTRANS=BUSY between burst beats
  parameter SLAVE_WAIT  = 0;   // n => n wait-states inserted per data phase by slave
  parameter USE_BFM     = 1;   // 1 => use behavioral slave BFM instead of RTL slave

  //---------------------------------------------------------------------
  // Clock / reset
  //---------------------------------------------------------------------
  logic HCLK, HRESETn;

  initial HCLK = 1'b0;
  always #5 HCLK = ~HCLK;

  initial begin
    HRESETn = 1'b0;
    repeat (4) @(posedge HCLK);
    HRESETn = 1'b1;
  end

  //---------------------------------------------------------------------
  // Bundled interface
  //---------------------------------------------------------------------
  ahb_if bus_if (.HCLK(HCLK), .HRESETn(HRESETn));

  //---------------------------------------------------------------------
  // Slave output mux (RTL slave vs behavioral BFM), identical scheme to
  // the flat testbench you already validated.
  //---------------------------------------------------------------------
  wire        HREADY_rtl, HREADY_bfm;
  wire [1:0]  HRESP_rtl,  HRESP_bfm;
  wire [31:0] HRDATA_rtl, HRDATA_bfm;

  assign bus_if.HREADY = (USE_BFM != 0) ? HREADY_bfm : HREADY_rtl;
  assign bus_if.HRDATA = (USE_BFM != 0) ? HRDATA_bfm : HRDATA_rtl;
  assign bus_if.HRESP  = (USE_BFM != 0) ? HRESP_bfm  : HRESP_rtl;

  //---------------------------------------------------------------------
  // DUT : master
  //---------------------------------------------------------------------
  ahb_master_burst #(.ENABLE_BUSY(MASTER_BUSY)) u_master (
    .HCLK    (HCLK),
    .HRESETn (HRESETn),
    .HREADY  (bus_if.HREADY),
    .HRESP   (bus_if.HRESP),
    .HRDATA  (bus_if.HRDATA),
    .start_i (bus_if.start_i),
    .write_i (bus_if.write_i),
    .burst_i (bus_if.burst_i),
    .addr_i  (bus_if.addr_i),
    .wdata_i (bus_if.wdata_i),
    .ready_o (bus_if.ready_o),
    .rdata_o (bus_if.rdata_o),
    .HTRANS  (bus_if.HTRANS),
    .HBURST  (bus_if.HBURST),
    .HWRITE  (bus_if.HWRITE),
    .HADDR   (bus_if.HADDR),
    .HWDATA  (bus_if.HWDATA)
  );

  //---------------------------------------------------------------------
  // DUT : RTL slave
  //---------------------------------------------------------------------
  ahb_slave_burst #(.DELAY_READY(SLAVE_WAIT)) u_slave (
    .HCLK      (HCLK),
    .HRESETn   (HRESETn),
    .HSEL      (USE_BFM == 0),
    .HADDR     (bus_if.HADDR),
    .HWRITE    (bus_if.HWRITE),
    .HTRANS    (bus_if.HTRANS),
    .HWDATA    (bus_if.HWDATA),
    .HREADY    (bus_if.HREADY),
    .HREADYOut (HREADY_rtl),
    .HRESP     (HRESP_rtl),
    .HRDATA    (HRDATA_rtl)
  );

  //---------------------------------------------------------------------
  // DUT : behavioral slave BFM
  //---------------------------------------------------------------------
  ahb_slave_bfm #(.DELAY_READY(SLAVE_WAIT)) u_bfm (
    .HCLK      (HCLK),
    .HRESETn   (HRESETn),
    .HSEL      (USE_BFM != 0),
    .HADDR     (bus_if.HADDR),
    .HWRITE    (bus_if.HWRITE),
    .HTRANS    (bus_if.HTRANS),
    .HWDATA    (bus_if.HWDATA),
    .HREADY    (bus_if.HREADY),
    .HREADYOut (HREADY_bfm),
    .HRESP     (HRESP_bfm),
    .HRDATA    (HRDATA_bfm)
  );

  //---------------------------------------------------------------------
  // Bus monitor print (optional visual aid, same style as flat TB)
  //---------------------------------------------------------------------
  always @(posedge HCLK) begin
    if (HRESETn && (bus_if.HTRANS != 2'b00 || !bus_if.HREADY))
      $display("[MON %0t] HREADY=%0b HTRANS=%0d(%s) HBURST=%0d HWRITE=%0b HADDR=0x%08h HWDATA=0x%08h HRDATA=0x%08h",
                $time, bus_if.HREADY, bus_if.HTRANS,
                (bus_if.HTRANS==2'b10)?"NONSEQ":(bus_if.HTRANS==2'b11)?"SEQ   ":
                (bus_if.HTRANS==2'b01)?"BUSY  ":"IDLE  ",
                bus_if.HBURST, bus_if.HWRITE, bus_if.HADDR, bus_if.HWDATA, bus_if.HRDATA);
  end

  //---------------------------------------------------------------------
  // Test invocation
  //---------------------------------------------------------------------
  ahb_test t;

  initial begin
    $display("================================================");
    $display("  LAYERED AHB TB : MASTER_BUSY=%0d SLAVE_WAIT=%0d USE_BFM=%0d",
              MASTER_BUSY, SLAVE_WAIT, USE_BFM);
    $display("================================================");

    wait (HRESETn === 1'b1);
    bus_if.wait_clocks(2);

    t = new(bus_if);
    t.run(MASTER_BUSY, SLAVE_WAIT, USE_BFM);

    bus_if.wait_clocks(5);
    $display("TESTBENCH COMPLETE");
    $finish;
  end

  //---------------------------------------------------------------------
  // Global watchdog
  //---------------------------------------------------------------------
  initial begin
    #100000;
    $display("[ERROR] GLOBAL TIMEOUT - forcing finish");
    $finish;
  end

endmodule

`endif // TB_TOP_SV
