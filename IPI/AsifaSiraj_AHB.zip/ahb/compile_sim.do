
# ============================================================
# compile_sim.do  -  ModelSim Intel FPGA Starter Edition 10.5b
# ============================================================
quit -sim
vlib work
vmap work work

# ---- RTL (note: .sv extension per your project) ----
vlog -sv -work work +cover=bcesf ahb_master_burst.sv
vlog -sv -work work +cover=bcesf ahb_slave_burst.sv
vlog -sv -work work +cover=bcesf ahb_slave_bfm.sv

# ---- Layered TB + coverage (all inline now, no .svh needed) ----
vlog -sv -work work ahb_if.sv
vlog -sv -work work +cover=bcesf ahb_pkg.sv
vlog -sv -work work tb_top.sv

# ---- Run with functional + code coverage enabled ----
vsim -voptargs=+acc -coverage work.tb_top -GMASTER_BUSY=0 -GSLAVE_WAIT=0 -GUSE_BFM=0

add wave -radix hex sim:/tb_top/bus_if/*
run -all

coverage save -onexit -directory covdb run_default.ucdb
vcover report covdb/run_default.ucdb -details -all