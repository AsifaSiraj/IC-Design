`timescale 1ns/1ps
module ahb_slave_burst #(
  parameter integer DELAY_READY = 0   // wait states inserted in every data phase
)(
  input  wire        HCLK, HRESETn, HSEL,
  input  wire [31:0] HADDR,
  input  wire        HWRITE,
  input  wire [1:0]  HTRANS,
  input  wire [31:0] HWDATA,
  input  wire        HREADY,
  output wire        HREADYOut,
  output wire [1:0]  HRESP,
  output reg  [31:0] HRDATA
);
  reg [31:0] memory [0:15];
  reg        reg_active, reg_write;
  reg [3:0]  reg_addr, wait_cnt;

  assign HRESP     = 2'b00;
  assign HREADYOut = (wait_cnt == 0);

  wire addr_phase = HSEL && HTRANS[1];   // NONSEQ/SEQ only
  // HTRANS==2'b01 (BUSY) is deliberately ignored: it merely extends the
  // previous transfer's data phase, which the registered pipeline below
  // completes naturally on the next HREADY edge.

  always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin
      reg_active<=0; reg_write<=0; reg_addr<=0; HRDATA<=0; wait_cnt<=0;
    end else begin
      if (wait_cnt != 0)
        wait_cnt <= wait_cnt - 1;
      else if (HREADY && addr_phase && (DELAY_READY > 0))
        wait_cnt <= DELAY_READY;

      if (HREADY) begin                  // pipeline advances only when accepted
        reg_active <= addr_phase;
        reg_write  <= HWRITE;
        reg_addr   <= HADDR[5:2];
        if (addr_phase && !HWRITE)
          HRDATA <= memory[HADDR[5:2]];  // held stable through wait states
      end
    end
  end

  always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin
    end else if (HREADY && reg_active && reg_write) begin
      memory[reg_addr] <= HWDATA;
    end
  end
endmodule