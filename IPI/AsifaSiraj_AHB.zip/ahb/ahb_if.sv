`timescale 1ns/1ps
//=======================================================================
// Compile guard
//=======================================================================
`ifndef AHB_IF_SV
`define AHB_IF_SV

//-----------------------------------------------------------------------
// ahb_if : bundles (a) the simplified master control interface exposed
// by ahb_master_burst, and (b) the actual AHB bus signals, so the
// verification layers only need ONE handle to talk to the DUT.
//-----------------------------------------------------------------------
interface ahb_if (input logic HCLK, input logic HRESETn);

  // ---- Simplified request interface into ahb_master_burst ----
  logic        start_i;
  logic        write_i;
  logic        burst_i;
  logic [31:0] addr_i;
  logic [31:0] wdata_i;
  logic        ready_o;
  logic [31:0] rdata_o;

  // ---- AHB bus signals ----
  logic [1:0]  HTRANS;
  logic [2:0]  HBURST;
  logic        HWRITE;
  logic [31:0] HADDR;
  logic [31:0] HWDATA;
  logic        HREADY;
  logic [1:0]  HRESP;
  logic [31:0] HRDATA;

  // Convenience task usable from any class holding a virtual handle to
  // this interface: block until N clean posedges have elapsed.
  task automatic wait_clocks(input int n);
    repeat (n) @(posedge HCLK);
  endtask

endinterface

`endif // AHB_IF_SV
