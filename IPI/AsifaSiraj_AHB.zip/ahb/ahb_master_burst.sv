`timescale 1ns/1ps
module ahb_master_burst #(
  parameter ENABLE_BUSY = 0      // 1 => insert one HTRANS=BUSY cycle between burst beats
)(
  input  wire        HCLK, HRESETn, HREADY,
  input  wire [1:0]  HRESP,
  input  wire [31:0] HRDATA,
  input  wire        start_i, write_i, burst_i,
  input  wire [31:0] addr_i, wdata_i,
  output reg         ready_o,
  output reg  [31:0] rdata_o,
  output reg  [1:0]  HTRANS,
  output reg  [2:0]  HBURST,
  output reg         HWRITE,
  output reg  [31:0] HADDR,
  output reg  [31:0] HWDATA
);
  localparam [1:0] IDLE=2'd0, ADDR=2'd1, BUSY_ST=2'd2, DONE=2'd3;
  reg [1:0]  state;
  reg        is_write, is_burst;
  reg [31:0] base_addr;
  reg [2:0]  total, beat;
  reg [31:0] wbuf [0:3];

  // Read-data-phase flag: asserted on the HREADY edge that accepts a read
  // address phase; HRDATA is latched on the next HREADY edge (end of the
  // data phase). Gated by HREADY => correct with wait states and BUSY.
  reg        rd_dphase;
  wire       rd_ap = HTRANS[1] && !HWRITE;   // read addr phase on bus now

  always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin
      state<=IDLE; ready_o<=1'b1; rdata_o<=0; rd_dphase<=0;
      HTRANS<=0; HBURST<=0; HWRITE<=0; HADDR<=0; HWDATA<=0;
      is_write<=0; is_burst<=0; base_addr<=0; total<=0; beat<=0;
      wbuf[0]<=0; wbuf[1]<=0; wbuf[2]<=0; wbuf[3]<=0;
    end else if (HREADY) begin          // <-- delayed-ready support: freeze on HREADY=0
      if (rd_dphase) rdata_o <= HRDATA; // sample at end of data phase
      rd_dphase <= rd_ap;

      case (state)
        IDLE: begin
          ready_o <= 1'b1;
          HTRANS <= 2'b00; HBURST <= 3'd0; HWRITE <= 1'b0; HWDATA <= 32'h0;
          beat <= 0;
          if (start_i) begin
            is_write  <= write_i;  is_burst  <= burst_i;
            base_addr <= addr_i;   total     <= burst_i ? 3'd4 : 3'd1;
            wbuf[0] <= wdata_i;    wbuf[1] <= wdata_i+32'd1;
            wbuf[2] <= wdata_i+32'd2; wbuf[3] <= wdata_i+32'd3;
            HADDR <= addr_i; HWRITE <= write_i;
            HBURST <= burst_i ? 3'd3 : 3'd0;   // INCR4 / SINGLE
            HTRANS <= 2'b10;                   // NONSEQ
            ready_o <= 1'b0; beat <= 1; state <= ADDR;
          end
        end

        // Address phase of beat[beat-1] is on the bus this cycle.
        ADDR: begin
          if (beat < total) begin
            if (is_write) HWDATA <= wbuf[beat-1]; // data phase of beat-1 next cycle
            if (ENABLE_BUSY && is_burst) begin
              HTRANS <= 2'b01;                    // BUSY bubble (HADDR/HWDATA held)
              state  <= BUSY_ST;
            end else begin
              HADDR  <= base_addr + (beat<<2);    // pipelined next addr phase
              HTRANS <= 2'b11;
              beat   <= beat + 1;
            end
          end else begin
            if (is_write) HWDATA <= wbuf[beat-1]; // last data phase happens in DONE
            HTRANS <= 2'b00;
            state  <= DONE;
          end
        end

        // BUSY was on the bus; data phase of beat[beat-1] ended at this edge.
        BUSY_ST: begin
          HADDR  <= base_addr + (beat<<2);
          HTRANS <= 2'b11;                        // now issue the SEQ we owed
          beat   <= beat + 1;
          state  <= ADDR;
        end

        // Data phase of the last beat ended at this edge.
        DONE: begin
          HWDATA <= 32'h0; HBURST <= 3'd0;
          ready_o <= 1'b1;
          state <= IDLE;
        end
        default: state <= IDLE;
      endcase
    end
  end
endmodule