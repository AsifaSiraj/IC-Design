`timescale 1ns/1ps
// Behavioral slave BFM: single + INCR4, optional delayed HREADY,
// explicitly tolerates HTRANS=BUSY.
module ahb_slave_bfm #(
  parameter integer DELAY_READY = 0
)(
  input  wire        HCLK, HRESETn, HSEL,
  input  wire [31:0] HADDR,
  input  wire        HWRITE,
  input  wire [1:0]  HTRANS,
  input  wire [31:0] HWDATA,
  input  wire        HREADY,
  output wire        HREADYOut,
  output wire [1:0]  HRESP,
  output reg  [31:0] HRDATA
);
  reg [31:0] memory [0:15];
  reg [3:0]  wait_cnt;
  reg        pend_valid, pend_write;
  reg [3:0]  pend_addr;

  integer i;
  initial for (i=0;i<16;i++) memory[i] = 32'h0;

  assign HRESP     = 2'b00;
  assign HREADYOut = (wait_cnt == 0);

  wire addr_phase = HSEL && (HTRANS==2'b10 || HTRANS==2'b11);
  wire busy_phase = HSEL && (HTRANS==2'b01);   // observed, not a new transfer

  always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin
      wait_cnt<=0; pend_valid<=0; pend_write<=0; pend_addr<=0; HRDATA<=0;
    end else begin
      if (wait_cnt != 0)
        wait_cnt <= wait_cnt - 1;
      else if (HREADY && addr_phase && (DELAY_READY > 0))
        wait_cnt <= DELAY_READY;

      if (HREADY) begin
        // End of the outstanding data phase (may be a BUSY cycle - same rule).
        if (pend_valid && pend_write)
          memory[pend_addr] <= HWDATA;
        // New address phase?
        pend_valid <= addr_phase;
        pend_write <= HWRITE;
        pend_addr  <= HADDR[5:2];
        if (addr_phase && !HWRITE)
          HRDATA <= memory[HADDR[5:2]];
      end
    end
  end
endmodule
