# LAB2 — Data Types and Format Specifiers

## What is this folder about?

LAB2 is a **single-purpose lab**: it isolates one C concept — *the five fundamental data types and their
`scanf` / `printf` format specifiers* — so you can be sure you understand it before moving on to bigger
programs.

The topic is the same one demonstrated in `../LAB1/adder.c`, but LAB2 is the dedicated, graded exercise for
it. The program is a short "read five values, double them, print them back" routine.

## What is in this folder?

| File | Description |
| --- | --- |
| `lab2.c` | The program. Reads a `char`, `int`, `long`, `float` and `double` from the user, multiplies each by 2, and prints them with the matching format specifier. |
| `Makefile` | Build rule for `lab2` plus a `clean` target. |
| `lab2.s` | GCC assembly listing of `lab2.c` — the low-level translation, for reading later. |
| `lab2.exe` | Compiled Windows binary (MinGW-w64 GCC). Build artefact, safe to delete. |

## What the program actually does

1. Prints a prompt and reads **one character** into `char letter` using `scanf(" %c", &letter)`.
2. Prints a prompt and reads an **integer** into `int integer_num` with `%d`.
3. Reads a **large integer** into `long long_num` with `%ld`.
4. Reads a **decimal number** into `float float_num` with `%f`.
5. Reads a **precise decimal number** into `double double_num` with `%lf`.
6. Doubles every value (`*= 2`, `2.0f`, `2.0`).
7. Prints all five back using `%c`, `%d`, `%ld`, `%f`, `%lf`.

## How to build and run

```sh
make          # gcc -Wall -o lab2 lab2.c
./lab2        # lab2.exe on Windows

make clean    # remove *.exe
```

Or manually:

```sh
gcc -Wall -o lab2 lab2.c
./lab2
```

Note: the `clean` target uses `rm -rf *.exe`, so it only works in a Unix-like shell (Git Bash, MSYS2,
WSL). In PowerShell/cmd use `Remove-Item *.exe`.

## Sample run

```
Enter a single character (char): A
Enter an integer (int): 21
Enter a large integer (long): 123456
Enter a decimal number (float): 3.5
Enter a precise decimal number (double): 2.718281828
Character entered : A
Processed int (%d) : 42
Processed long (%ld) : 246912
Processed float (%f) : 7.000000
Processed double (%lf) : 5.436563656
```

## The two things this lab is really testing

### 1. The leading space in `scanf(" %c", ...)`

`scanf`'s `%c` is the **only** specifier that does not skip leading whitespace. Every other specifier
(`%d`, `%f`, `%lf`, `%s`) automatically ignores spaces, tabs and newlines before reading.

So on the very first `scanf` here it does not matter, but the pattern matters. If you had written
`scanf("%c", &letter)` *after* reading a number, the leftover `'\n'` from the Enter key would be consumed
as the character and everything after would be shifted by one.

`scanf(" %c", ...)` works because the space tells `scanf` "skip any whitespace, then read one char".

### 2. `%lf` is mandatory for `double` inside `scanf`

This asymmetry trips up almost everyone:

| Context | `float` | `double` |
| --- | --- | --- |
| `scanf` | `%f` | **`%lf`** |
| `printf` | `%f` | `%f` or `%lf` (both fine) |

`printf` *promotes* `float` to `double` when passing arguments, so `%f` already does the right thing and
`%lf` is redundant but harmless. `scanf` takes a **pointer**, and the size of the object that pointer
points to must match the specifier exactly. Writing `scanf("%f", &double_num)` tells the function to write
4 bytes into an 8-byte `double`, silently corrupting the stack and the adjacent variable.

## Other notes

- `2.0f` vs `2.0` — the `f` suffix tells the compiler to keep the operation in single precision. On a
  `float` variable it barely matters, but it is the correct habit.
- `printf("Processed int (%%d) : %d\n", ...)` — the `%%` is an escaped literal percent sign. Inside a
  format string a single `%d` would be interpreted as a conversion, so `%%` is how you print the
  characters `%d` on screen.
- The `.exe`/`.s` files are outputs, not source. Only `lab2.c` and `Makefile` need to be in version
  control.
