#include <stdio.h>
int main()
{
char letter;
int integer_num;
long long_num;
float float_num;
double double_num;
printf("Enter a single character (char): ");
scanf(" %c", &letter); // Space before %c clears the input buffer newline
printf("Enter an integer (int): ");
scanf("%d", &integer_num);
printf("Enter a large integer (long): ");
scanf("%ld", &long_num);
printf("Enter a decimal number (float): ");
scanf("%f", &float_num);
printf("Enter a precise decimal number (double): ");
scanf("%lf", &double_num); // %lf is mandatory for double in scanf
integer_num *= 2;
long_num *= 2;
float_num *= 2.0f;
double_num *= 2.0;
printf("Character entered : %c\n", letter);
printf("Processed int (%%d) : %d\n", integer_num);
printf("Processed long (%%ld) : %ld\n", long_num);
printf("Processed float (%%f) : %f\n", float_num);
printf("Processed double (%%lf) : %lf\n", double_num);
return 0; }

