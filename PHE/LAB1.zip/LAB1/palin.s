	.file	"palin.c"
	.text
	.section .rdata,"dr"
.LC0:
	.ascii "Enter a string: \0"
.LC1:
	.ascii "%s\0"
.LC2:
	.ascii "Palindrome String\0"
.LC3:
	.ascii "Not a Palindrome String\0"
	.text
	.globl	main
	.def	main;	.scl	2;	.type	32;	.endef
	.seh_proc	main
main:
	pushq	%rbp
	.seh_pushreg	%rbp
	movq	%rsp, %rbp
	.seh_setframe	%rbp, 0
	subq	$144, %rsp
	.seh_stackalloc	144
	.seh_endprologue
	call	__main
	movl	$1, -8(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	-112(%rbp), %rax
	leaq	.LC1(%rip), %rcx
	movq	%rax, %rdx
	call	scanf
	leaq	-112(%rbp), %rax
	movq	%rax, %rcx
	call	strlen
	movl	%eax, -12(%rbp)
	movl	$0, -4(%rbp)
	jmp	.L2
.L5:
	movl	-4(%rbp), %eax
	cltq
	movzbl	-112(%rbp,%rax), %edx
	movl	-12(%rbp), %eax
	subl	$1, %eax
	subl	-4(%rbp), %eax
	cltq
	movzbl	-112(%rbp,%rax), %eax
	cmpb	%al, %dl
	je	.L3
	movl	$0, -8(%rbp)
	jmp	.L4
.L3:
	addl	$1, -4(%rbp)
.L2:
	movl	-12(%rbp), %eax
	movl	%eax, %edx
	shrl	$31, %edx
	addl	%edx, %eax
	sarl	%eax
	cmpl	%eax, -4(%rbp)
	jl	.L5
.L4:
	cmpl	$0, -8(%rbp)
	je	.L6
	leaq	.LC2(%rip), %rax
	movq	%rax, %rcx
	call	puts
	jmp	.L7
.L6:
	leaq	.LC3(%rip), %rax
	movq	%rax, %rcx
	call	puts
.L7:
	movl	$0, %eax
	addq	$144, %rsp
	popq	%rbp
	ret
	.seh_endproc
	.def	__main;	.scl	2;	.type	32;	.endef
	.ident	"GCC: (Rev1, Built by MSYS2 project) 15.1.0"
	.def	printf;	.scl	2;	.type	32;	.endef
	.def	scanf;	.scl	2;	.type	32;	.endef
	.def	strlen;	.scl	2;	.type	32;	.endef
	.def	puts;	.scl	2;	.type	32;	.endef
