#include <stdio.h>

void insert(int arr[], int *size, int pos, int value) {
    int i;

    for(i = *size; i > pos; i--)
        arr[i] = arr[i - 1];

    arr[pos] = value;
    (*size)++;
}

void deleteElement(int arr[], int *size, int pos) {
    int i;

    for(i = pos; i < *size - 1; i++)
        arr[i] = arr[i + 1];

    (*size)--;
}

int search(int arr[], int size, int value) {
    int i;

    for(i = 0; i < size; i++) {
        if(arr[i] == value)
            return i;
    }

    return -1;
}

int main() {
    int arr[100], size, i;
    int pos, value;

    printf("Enter size: ");
    scanf("%d", &size);

    printf("Enter elements:\n");
    for(i = 0; i < size; i++)
        scanf("%d", &arr[i]);

    printf("Enter position and value to insert: ");
    scanf("%d%d", &pos, &value);
    insert(arr, &size, pos, value);

    printf("Array after insertion:\n");
    for(i = 0; i < size; i++)
        printf("%d ", arr[i]);

    printf("\nEnter position to delete: ");
    scanf("%d", &pos);
    deleteElement(arr, &size, pos);

    printf("Array after deletion:\n");
    for(i = 0; i < size; i++)
        printf("%d ", arr[i]);

    printf("\nEnter value to search: ");
    scanf("%d", &value);

    int result = search(arr, size, value);

    if(result != -1)
        printf("Found at index %d\n", result);
    else
        printf("Not Found\n");

    return 0;
}