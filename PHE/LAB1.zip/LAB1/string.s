	.file	"string.c"
	.text
	.section .rdata,"dr"
.LC0:
	.ascii "Enter first string: \0"
.LC1:
	.ascii "%s\0"
.LC2:
	.ascii "Enter second string: \0"
.LC3:
	.ascii "Reversed String: %s\12\0"
.LC4:
	.ascii "Strings are equal\0"
.LC5:
	.ascii "Strings are not equal\0"
.LC6:
	.ascii "Concatenated String: %s\12\0"
	.text
	.globl	main
	.def	main;	.scl	2;	.type	32;	.endef
	.seh_proc	main
main:
	pushq	%rbp
	.seh_pushreg	%rbp
	subq	$368, %rsp
	.seh_stackalloc	368
	leaq	128(%rsp), %rbp
	.seh_setframe	%rbp, 128
	.seh_endprologue
	call	__main
	leaq	.LC0(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	128(%rbp), %rax
	leaq	.LC1(%rip), %rcx
	movq	%rax, %rdx
	call	scanf
	leaq	.LC2(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	16(%rbp), %rax
	leaq	.LC1(%rip), %rcx
	movq	%rax, %rdx
	call	scanf
	leaq	128(%rbp), %rax
	movq	%rax, %rcx
	call	strlen
	movl	%eax, 232(%rbp)
	movl	$0, 236(%rbp)
	jmp	.L2
.L3:
	movl	232(%rbp), %eax
	subl	$1, %eax
	subl	236(%rbp), %eax
	cltq
	movzbl	128(%rbp,%rax), %edx
	movl	236(%rbp), %eax
	cltq
	movb	%dl, -96(%rbp,%rax)
	addl	$1, 236(%rbp)
.L2:
	movl	236(%rbp), %eax
	cmpl	232(%rbp), %eax
	jl	.L3
	movl	232(%rbp), %eax
	cltq
	movb	$0, -96(%rbp,%rax)
	leaq	-96(%rbp), %rax
	leaq	.LC3(%rip), %rcx
	movq	%rax, %rdx
	call	printf
	leaq	16(%rbp), %rdx
	leaq	128(%rbp), %rax
	movq	%rax, %rcx
	call	strcmp
	testl	%eax, %eax
	jne	.L4
	leaq	.LC4(%rip), %rax
	movq	%rax, %rcx
	call	puts
	jmp	.L5
.L4:
	leaq	.LC5(%rip), %rax
	movq	%rax, %rcx
	call	puts
.L5:
	leaq	16(%rbp), %rdx
	leaq	128(%rbp), %rax
	movq	%rax, %rcx
	call	strcat
	leaq	128(%rbp), %rax
	leaq	.LC6(%rip), %rcx
	movq	%rax, %rdx
	call	printf
	movl	$0, %eax
	addq	$368, %rsp
	popq	%rbp
	ret
	.seh_endproc
	.def	__main;	.scl	2;	.type	32;	.endef
	.ident	"GCC: (Rev1, Built by MSYS2 project) 15.1.0"
	.def	printf;	.scl	2;	.type	32;	.endef
	.def	scanf;	.scl	2;	.type	32;	.endef
	.def	strlen;	.scl	2;	.type	32;	.endef
	.def	strcmp;	.scl	2;	.type	32;	.endef
	.def	puts;	.scl	2;	.type	32;	.endef
	.def	strcat;	.scl	2;	.type	32;	.endef
