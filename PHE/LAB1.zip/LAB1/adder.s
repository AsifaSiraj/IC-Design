	.file	"adder.c"
	.text
	.section .rdata,"dr"
	.align 8
.LC0:
	.ascii "Enter a single character (char): \0"
.LC1:
	.ascii " %c\0"
.LC2:
	.ascii "Enter an integer (int): \0"
.LC3:
	.ascii "%d\0"
	.align 8
.LC4:
	.ascii "Enter a large integer (long): \0"
.LC5:
	.ascii "%ld\0"
	.align 8
.LC6:
	.ascii "Enter a decimal number (float): \0"
.LC7:
	.ascii "%f\0"
	.align 8
.LC8:
	.ascii "Enter a precise decimal number (double): \0"
.LC9:
	.ascii "%lf\0"
.LC10:
	.ascii "Character entered : %c\12\0"
.LC11:
	.ascii "Processed int (%%d) : %d\12\0"
.LC12:
	.ascii "Processed long (%%ld) : %ld\12\0"
.LC13:
	.ascii "Processed float (%%f) : %f\12\0"
	.align 8
.LC14:
	.ascii "Processed double (%%lf) : %lf\12\0"
	.text
	.globl	main
	.def	main;	.scl	2;	.type	32;	.endef
	.seh_proc	main
main:
	pushq	%rbp
	.seh_pushreg	%rbp
	movq	%rsp, %rbp
	.seh_setframe	%rbp, 0
	subq	$64, %rsp
	.seh_stackalloc	64
	.seh_endprologue
	call	__main
	leaq	.LC0(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	-1(%rbp), %rax
	leaq	.LC1(%rip), %rcx
	movq	%rax, %rdx
	call	scanf
	leaq	.LC2(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	-8(%rbp), %rax
	leaq	.LC3(%rip), %rcx
	movq	%rax, %rdx
	call	scanf
	leaq	.LC4(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	-12(%rbp), %rax
	leaq	.LC5(%rip), %rcx
	movq	%rax, %rdx
	call	scanf
	leaq	.LC6(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	-16(%rbp), %rax
	leaq	.LC7(%rip), %rcx
	movq	%rax, %rdx
	call	scanf
	leaq	.LC8(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	-24(%rbp), %rax
	leaq	.LC9(%rip), %rcx
	movq	%rax, %rdx
	call	scanf
	movl	-8(%rbp), %eax
	addl	%eax, %eax
	movl	%eax, -8(%rbp)
	movl	-12(%rbp), %eax
	addl	%eax, %eax
	movl	%eax, -12(%rbp)
	movss	-16(%rbp), %xmm0
	addss	%xmm0, %xmm0
	movss	%xmm0, -16(%rbp)
	movsd	-24(%rbp), %xmm0
	addsd	%xmm0, %xmm0
	movsd	%xmm0, -24(%rbp)
	movzbl	-1(%rbp), %eax
	movsbl	%al, %eax
	leaq	.LC10(%rip), %rcx
	movl	%eax, %edx
	call	printf
	movl	-8(%rbp), %eax
	leaq	.LC11(%rip), %rcx
	movl	%eax, %edx
	call	printf
	movl	-12(%rbp), %eax
	leaq	.LC12(%rip), %rcx
	movl	%eax, %edx
	call	printf
	movss	-16(%rbp), %xmm0
	cvtss2sd	%xmm0, %xmm0
	movapd	%xmm0, %xmm1
	movapd	%xmm1, %xmm0
	movq	%xmm1, %rdx
	leaq	.LC13(%rip), %rax
	movapd	%xmm0, %xmm1
	movq	%rax, %rcx
	call	printf
	movsd	-24(%rbp), %xmm0
	movapd	%xmm0, %xmm1
	movapd	%xmm1, %xmm0
	movq	%xmm1, %rdx
	leaq	.LC14(%rip), %rax
	movapd	%xmm0, %xmm1
	movq	%rax, %rcx
	call	printf
	movl	$0, %eax
	addq	$64, %rsp
	popq	%rbp
	ret
	.seh_endproc
	.def	__main;	.scl	2;	.type	32;	.endef
	.ident	"GCC: (Rev1, Built by MSYS2 project) 15.1.0"
	.def	printf;	.scl	2;	.type	32;	.endef
	.def	scanf;	.scl	2;	.type	32;	.endef
