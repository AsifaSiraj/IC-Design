# LAB1 — C Fundamentals Practice

## What is this folder about?

LAB1 is the **first C programming lab** in the PHE (Programming for Hardware Engineers) series. It is a
collection of small, self-contained C programs that each demonstrate one fundamental concept:

- Reading user input with `scanf` and the correct format specifiers
- Using `printf` format specifiers
- The basic control-flow statements: `for`, `while`, `if`/`else`, `switch`
- Working with `char`, `int`, `long`, `float`, `double`
- Manipulating integers (digits, factorial, Fibonacci, prime, reverse)
- Working with strings and the `<string.h>` library
- Writing and calling your own functions in C

Every program is standalone — you compile and run one at a time. There is no driver or `main` that ties
them together.

## What is in this folder?

| File | What it demonstrates |
| --- | --- |
| `lab1.c` | A simple calculator. Reads `a op b` and evaluates it with a `switch`. Guards division by zero. |
| `adder.c` | Every C data type in one program: `char`, `int`, `long`, `float`, `double`. Shows the correct `scanf` specifier for each (`%d`, `%ld`, `%f`, **`%lf`** for double) and doubles each value. |
| `arrfunc.c` | Arrays passed to user-defined functions. Implements `insert()`, `deleteElement()` and `search()` over a fixed `int arr[100]`, passing `size` **by pointer** so the functions can modify the array length. |
| `convert.c` | Number-system conversion using only `printf`: decimal to octal (`%o`) and hexadecimal (`%X`). |
| `count.c` | Counts the number of digits in a number using a `while` loop and repeated integer division by 10. |
| `fac.c` | Computes a factorial with a `for` loop, stored in a `long long` so it does not overflow quickly. |
| `fibonacci.c` | Prints the Fibonacci series iteratively using a rolling `a`/`b`/`c` triple — no array needed. |
| `palin.c` | Palindrome check on a string. Uses `strlen()` and compares `str[i]` against `str[len-1-i]` for the first half only. |
| `prime.c` | Primality test. Rejects `n <= 1`, then trial-divides up to `n / 2` and breaks early on the first factor found. |
| `reverse.c` | Reverses an integer digit-by-digit: `reverse = reverse * 10 + (n % 10)`. |
| `string.c` | String operations with `<string.h>`: manual character-by-character reversal, `strcmp()` for comparison, and `strcat()` for concatenation. |
| `Makefile` | Build recipe for `lab1` only. |

### The `.exe` and `.s` files

- **`*.exe`** — Windows binaries produced by MinGW-w64 GCC. Compiled output, safe to delete.
- **`*.s`** — GCC assembly output. These are the *low-level translation of the corresponding `.c` file*,
  kept so you can see what the compiler actually generated for each program (register allocation, the
  `scanf`/`printf` call setup, stack frames in `.seh_proc`, string literals in `.rdata`).
  Useful when you move on to the assembly/MIPS-oriented parts of this course.
- All 11 `.c` files have a matching `.s`. Of the binaries, only `lab1.exe` is missing (its Makefile target
  was never built) — build it with the command below.

## How to build and run

### Using the Makefile (only builds `lab1`)

```sh
make          # gcc -Wall -o lab1 lab1.c
./lab1        # or lab1.exe on Windows
```

### Building any program by hand (GCC / MinGW)

```sh
gcc -Wall -o convert convert.c
./convert
```

On Windows with MinGW-w64 the output is `convert.exe`.

### Also generating the assembly listing

```sh
gcc -Wall -S -o convert.s convert.c
```

## Things worth noticing while you study these files

1. **`scanf(" %c", ...)` vs `scanf("%c", ...)`** — `adder.c` deliberately puts a space before `%c`.
   `scanf` skips leading *whitespace* for most specifiers, but **not** for `%c`. Without that space, a
   leftover newline from the previous input is read as your character.
2. **`%lf` is mandatory for `double` in `scanf`.** In `printf`, `%f` and `%lf` are interchangeable, but
   in `scanf` `%f` means `float *` and `%lf` means `double *`. Getting this wrong corrupts the stack.
3. **`float` vs `double`** — `float` is ~7 significant digits, `double` ~15. `2.0f` vs `2.0` is a hint to
   the compiler to keep the arithmetic in single precision.
4. **Passing arrays and sizes to functions** — `arrfunc.c` passes `int arr[]` (decays to a pointer) and
   `int *size`. Without the pointer, `insert()` could add an element but the caller's `size` would never
   change, so the program would keep printing the old length.
5. **`break` in the prime loop** — once a factor is found there is no reason to keep dividing, so the
   worst case is only reached for actual primes.
6. **Buffer sizes** — all string buffers are `char str[100]` and every input is read with `%s`, which
   does **not** bound-check. Typing more than 99 characters overflows the buffer.
