#include <stdio.h>
#include <string.h>

int main() {
    char str1[100], str2[100], rev[100];
    int i, len;

    printf("Enter first string: ");
    scanf("%s", str1);

    printf("Enter second string: ");
    scanf("%s", str2);

    len = strlen(str1);

    for(i = 0; i < len; i++)
        rev[i] = str1[len - 1 - i];

    rev[len] = '\0';

    printf("Reversed String: %s\n", rev);

    if(strcmp(str1, str2) == 0)
        printf("Strings are equal\n");
    else
        printf("Strings are not equal\n");

    strcat(str1, str2);
    printf("Concatenated String: %s\n", str1);

    return 0;
}