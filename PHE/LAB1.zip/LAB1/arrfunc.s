	.file	"arrfunc.c"
	.text
	.globl	insert
	.def	insert;	.scl	2;	.type	32;	.endef
	.seh_proc	insert
insert:
	pushq	%rbp
	.seh_pushreg	%rbp
	movq	%rsp, %rbp
	.seh_setframe	%rbp, 0
	subq	$16, %rsp
	.seh_stackalloc	16
	.seh_endprologue
	movq	%rcx, 16(%rbp)
	movq	%rdx, 24(%rbp)
	movl	%r8d, 32(%rbp)
	movl	%r9d, 40(%rbp)
	movq	24(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -4(%rbp)
	jmp	.L2
.L3:
	movl	-4(%rbp), %eax
	cltq
	salq	$2, %rax
	leaq	-4(%rax), %rdx
	movq	16(%rbp), %rax
	addq	%rdx, %rax
	movl	-4(%rbp), %edx
	movslq	%edx, %rdx
	leaq	0(,%rdx,4), %rcx
	movq	16(%rbp), %rdx
	addq	%rcx, %rdx
	movl	(%rax), %eax
	movl	%eax, (%rdx)
	subl	$1, -4(%rbp)
.L2:
	movl	-4(%rbp), %eax
	cmpl	32(%rbp), %eax
	jg	.L3
	movl	32(%rbp), %eax
	cltq
	leaq	0(,%rax,4), %rdx
	movq	16(%rbp), %rax
	addq	%rax, %rdx
	movl	40(%rbp), %eax
	movl	%eax, (%rdx)
	movq	24(%rbp), %rax
	movl	(%rax), %eax
	leal	1(%rax), %edx
	movq	24(%rbp), %rax
	movl	%edx, (%rax)
	nop
	addq	$16, %rsp
	popq	%rbp
	ret
	.seh_endproc
	.globl	deleteElement
	.def	deleteElement;	.scl	2;	.type	32;	.endef
	.seh_proc	deleteElement
deleteElement:
	pushq	%rbp
	.seh_pushreg	%rbp
	movq	%rsp, %rbp
	.seh_setframe	%rbp, 0
	subq	$16, %rsp
	.seh_stackalloc	16
	.seh_endprologue
	movq	%rcx, 16(%rbp)
	movq	%rdx, 24(%rbp)
	movl	%r8d, 32(%rbp)
	movl	32(%rbp), %eax
	movl	%eax, -4(%rbp)
	jmp	.L5
.L6:
	movl	-4(%rbp), %eax
	cltq
	addq	$1, %rax
	leaq	0(,%rax,4), %rdx
	movq	16(%rbp), %rax
	addq	%rdx, %rax
	movl	-4(%rbp), %edx
	movslq	%edx, %rdx
	leaq	0(,%rdx,4), %rcx
	movq	16(%rbp), %rdx
	addq	%rcx, %rdx
	movl	(%rax), %eax
	movl	%eax, (%rdx)
	addl	$1, -4(%rbp)
.L5:
	movq	24(%rbp), %rax
	movl	(%rax), %eax
	subl	$1, %eax
	cmpl	%eax, -4(%rbp)
	jl	.L6
	movq	24(%rbp), %rax
	movl	(%rax), %eax
	leal	-1(%rax), %edx
	movq	24(%rbp), %rax
	movl	%edx, (%rax)
	nop
	addq	$16, %rsp
	popq	%rbp
	ret
	.seh_endproc
	.globl	search
	.def	search;	.scl	2;	.type	32;	.endef
	.seh_proc	search
search:
	pushq	%rbp
	.seh_pushreg	%rbp
	movq	%rsp, %rbp
	.seh_setframe	%rbp, 0
	subq	$16, %rsp
	.seh_stackalloc	16
	.seh_endprologue
	movq	%rcx, 16(%rbp)
	movl	%edx, 24(%rbp)
	movl	%r8d, 32(%rbp)
	movl	$0, -4(%rbp)
	jmp	.L8
.L11:
	movl	-4(%rbp), %eax
	cltq
	leaq	0(,%rax,4), %rdx
	movq	16(%rbp), %rax
	addq	%rdx, %rax
	movl	(%rax), %eax
	cmpl	%eax, 32(%rbp)
	jne	.L9
	movl	-4(%rbp), %eax
	jmp	.L10
.L9:
	addl	$1, -4(%rbp)
.L8:
	movl	-4(%rbp), %eax
	cmpl	24(%rbp), %eax
	jl	.L11
	movl	$-1, %eax
.L10:
	addq	$16, %rsp
	popq	%rbp
	ret
	.seh_endproc
	.section .rdata,"dr"
.LC0:
	.ascii "Enter size: \0"
.LC1:
	.ascii "%d\0"
.LC2:
	.ascii "Enter elements:\0"
	.align 8
.LC3:
	.ascii "Enter position and value to insert: \0"
.LC4:
	.ascii "%d%d\0"
.LC5:
	.ascii "Array after insertion:\0"
.LC6:
	.ascii "%d \0"
.LC7:
	.ascii "\12Enter position to delete: \0"
.LC8:
	.ascii "Array after deletion:\0"
.LC9:
	.ascii "\12Enter value to search: \0"
.LC10:
	.ascii "Found at index %d\12\0"
.LC11:
	.ascii "Not Found\0"
	.text
	.globl	main
	.def	main;	.scl	2;	.type	32;	.endef
	.seh_proc	main
main:
	pushq	%rbp
	.seh_pushreg	%rbp
	subq	$464, %rsp
	.seh_stackalloc	464
	leaq	128(%rsp), %rbp
	.seh_setframe	%rbp, 128
	.seh_endprologue
	call	__main
	leaq	.LC0(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	-84(%rbp), %rax
	leaq	.LC1(%rip), %rcx
	movq	%rax, %rdx
	call	scanf
	leaq	.LC2(%rip), %rax
	movq	%rax, %rcx
	call	puts
	movl	$0, 332(%rbp)
	jmp	.L13
.L14:
	leaq	-80(%rbp), %rax
	movl	332(%rbp), %edx
	movslq	%edx, %rdx
	salq	$2, %rdx
	addq	%rax, %rdx
	leaq	.LC1(%rip), %rax
	movq	%rax, %rcx
	call	scanf
	addl	$1, 332(%rbp)
.L13:
	movl	-84(%rbp), %eax
	cmpl	%eax, 332(%rbp)
	jl	.L14
	leaq	.LC3(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	-92(%rbp), %rdx
	leaq	-88(%rbp), %rax
	leaq	.LC4(%rip), %rcx
	movq	%rdx, %r8
	movq	%rax, %rdx
	call	scanf
	movl	-92(%rbp), %r8d
	movl	-88(%rbp), %ecx
	leaq	-84(%rbp), %rdx
	leaq	-80(%rbp), %rax
	movl	%r8d, %r9d
	movl	%ecx, %r8d
	movq	%rax, %rcx
	call	insert
	leaq	.LC5(%rip), %rax
	movq	%rax, %rcx
	call	puts
	movl	$0, 332(%rbp)
	jmp	.L15
.L16:
	movl	332(%rbp), %eax
	cltq
	movl	-80(%rbp,%rax,4), %eax
	leaq	.LC6(%rip), %rcx
	movl	%eax, %edx
	call	printf
	addl	$1, 332(%rbp)
.L15:
	movl	-84(%rbp), %eax
	cmpl	%eax, 332(%rbp)
	jl	.L16
	leaq	.LC7(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	-88(%rbp), %rax
	leaq	.LC1(%rip), %rcx
	movq	%rax, %rdx
	call	scanf
	movl	-88(%rbp), %ecx
	leaq	-84(%rbp), %rdx
	leaq	-80(%rbp), %rax
	movl	%ecx, %r8d
	movq	%rax, %rcx
	call	deleteElement
	leaq	.LC8(%rip), %rax
	movq	%rax, %rcx
	call	puts
	movl	$0, 332(%rbp)
	jmp	.L17
.L18:
	movl	332(%rbp), %eax
	cltq
	movl	-80(%rbp,%rax,4), %eax
	leaq	.LC6(%rip), %rcx
	movl	%eax, %edx
	call	printf
	addl	$1, 332(%rbp)
.L17:
	movl	-84(%rbp), %eax
	cmpl	%eax, 332(%rbp)
	jl	.L18
	leaq	.LC9(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	-92(%rbp), %rax
	leaq	.LC1(%rip), %rcx
	movq	%rax, %rdx
	call	scanf
	movl	-92(%rbp), %ecx
	movl	-84(%rbp), %edx
	leaq	-80(%rbp), %rax
	movl	%ecx, %r8d
	movq	%rax, %rcx
	call	search
	movl	%eax, 328(%rbp)
	cmpl	$-1, 328(%rbp)
	je	.L19
	movl	328(%rbp), %eax
	leaq	.LC10(%rip), %rcx
	movl	%eax, %edx
	call	printf
	jmp	.L20
.L19:
	leaq	.LC11(%rip), %rax
	movq	%rax, %rcx
	call	puts
.L20:
	movl	$0, %eax
	addq	$464, %rsp
	popq	%rbp
	ret
	.seh_endproc
	.def	__main;	.scl	2;	.type	32;	.endef
	.ident	"GCC: (Rev1, Built by MSYS2 project) 15.1.0"
	.def	printf;	.scl	2;	.type	32;	.endef
	.def	scanf;	.scl	2;	.type	32;	.endef
	.def	puts;	.scl	2;	.type	32;	.endef
