	.file	"lab1.c"
	.text
	.section .rdata,"dr"
	.align 8
.LC0:
	.ascii "Enter expression (e.g. 5 + 3): \0"
.LC1:
	.ascii "%f %c %f\0"
.LC2:
	.ascii "Result = %.2f\12\0"
.LC4:
	.ascii "Division by zero not allowed.\0"
.LC5:
	.ascii "Invalid operator.\0"
	.text
	.globl	main
	.def	main;	.scl	2;	.type	32;	.endef
	.seh_proc	main
main:
	pushq	%rbp
	.seh_pushreg	%rbp
	movq	%rsp, %rbp
	.seh_setframe	%rbp, 0
	subq	$48, %rsp
	.seh_stackalloc	48
	.seh_endprologue
	call	__main
	leaq	.LC0(%rip), %rax
	movq	%rax, %rcx
	call	printf
	leaq	-8(%rbp), %r8
	leaq	-9(%rbp), %rdx
	leaq	-4(%rbp), %rax
	leaq	.LC1(%rip), %rcx
	movq	%r8, %r9
	movq	%rdx, %r8
	movq	%rax, %rdx
	call	scanf
	movzbl	-9(%rbp), %eax
	movsbl	%al, %eax
	cmpl	$47, %eax
	je	.L2
	cmpl	$47, %eax
	jg	.L3
	cmpl	$45, %eax
	je	.L4
	cmpl	$45, %eax
	jg	.L3
	cmpl	$42, %eax
	je	.L5
	cmpl	$43, %eax
	jne	.L3
	movss	-4(%rbp), %xmm1
	movss	-8(%rbp), %xmm0
	addss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	movapd	%xmm0, %xmm1
	movapd	%xmm1, %xmm0
	movq	%xmm1, %rdx
	leaq	.LC2(%rip), %rax
	movapd	%xmm0, %xmm1
	movq	%rax, %rcx
	call	printf
	jmp	.L6
.L4:
	movss	-4(%rbp), %xmm0
	movss	-8(%rbp), %xmm1
	subss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	movapd	%xmm0, %xmm1
	movapd	%xmm1, %xmm0
	movq	%xmm1, %rdx
	leaq	.LC2(%rip), %rax
	movapd	%xmm0, %xmm1
	movq	%rax, %rcx
	call	printf
	jmp	.L6
.L5:
	movss	-4(%rbp), %xmm1
	movss	-8(%rbp), %xmm0
	mulss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	movapd	%xmm0, %xmm1
	movapd	%xmm1, %xmm0
	movq	%xmm1, %rdx
	leaq	.LC2(%rip), %rax
	movapd	%xmm0, %xmm1
	movq	%rax, %rcx
	call	printf
	jmp	.L6
.L2:
	movss	-8(%rbp), %xmm0
	pxor	%xmm1, %xmm1
	ucomiss	%xmm1, %xmm0
	jp	.L11
	pxor	%xmm1, %xmm1
	ucomiss	%xmm1, %xmm0
	je	.L7
.L11:
	movss	-4(%rbp), %xmm0
	movss	-8(%rbp), %xmm1
	divss	%xmm1, %xmm0
	cvtss2sd	%xmm0, %xmm0
	movapd	%xmm0, %xmm1
	movapd	%xmm1, %xmm0
	movq	%xmm1, %rdx
	leaq	.LC2(%rip), %rax
	movapd	%xmm0, %xmm1
	movq	%rax, %rcx
	call	printf
	jmp	.L6
.L7:
	leaq	.LC4(%rip), %rax
	movq	%rax, %rcx
	call	puts
	jmp	.L6
.L3:
	leaq	.LC5(%rip), %rax
	movq	%rax, %rcx
	call	puts
.L6:
	movl	$0, %eax
	addq	$48, %rsp
	popq	%rbp
	ret
	.seh_endproc
	.def	__main;	.scl	2;	.type	32;	.endef
	.ident	"GCC: (Rev1, Built by MSYS2 project) 15.1.0"
	.def	printf;	.scl	2;	.type	32;	.endef
	.def	scanf;	.scl	2;	.type	32;	.endef
	.def	puts;	.scl	2;	.type	32;	.endef
