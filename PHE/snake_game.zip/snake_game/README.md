# snake_game — DE1-SoC Hardware Snake Game

## What is this folder about?

`snake_game` is the **capstone project** of the PHE course. It is a complete System-on-Chip design that
runs a playable Snake game on a **Terasic DE1-SoC** FPGA board (Cyclone V `5CSEMA5F31C6`).

It is the first folder in PHE that is genuinely **hardware**: the earlier labs (LAB1–LAB3) are host
software exercises, while this one is split into two halves of an embedded system:

- **Hardware (Verilog RTL)** — a DMA video pipeline that continuously streams a framebuffer out of
  SDRAM over the Avalon-MM bus and drives the VGA connector at 720p.
- **Software (C, bare-metal Linux)** — a userspace Snake game that renders into that same framebuffer in
  SDRAM via `/dev/mem`, and reads the keyboard from the terminal.

The game logic lives in **software**, the pixel output lives in **hardware**. That split is the whole
point of the project.

## Folder layout

```
snake_game/
├── qsf/   de1_soc_snake_pins.qsf     Quartus pin/IO assignments
├── rtl/   7 Verilog modules          All synthesizable hardware
├── sw/    snake.c                    Linux userspace game program
└── tb/    tb_vga_dma_master.sv       Testbench for the DMA engine
```

Each subfolder has its own README with the detailed breakdown.

## The data path — how a frame gets to the monitor

This is the central idea of the design, and every module exists to serve one step of it:

```
  [sw/snake.c]                 [RTL, CLOCK_50 domain]        [RTL, pixel_clk domain]
  draws blocks into
  SDRAM framebuffer
  0x3800_0000 (320x240, 8bpp)
            |
            v
  vga_dma_master  -------->  async_fifo_dc  -------->  byte-unpack FSM  -------->  VGA pins
  Avalon-MM read             512 x 32-bit, CDC-safe      32b word -> 4 pixels     R/G/B + HS/VS
  4 bytes/beat               dual-clock, Gray-coded      one pixel per pixel_clk
  up to 8 in flight
```

1. **Software writes pixels to SDRAM.** `snake.c` maps physical memory at `0x3800_0000` and writes
   `0x1C`/`0xE0` blocks for the snake. A 320x240 8-bit frame is 76,800 bytes, tiled to 921,600 bytes
   of DMA reads.
2. **The DMA master streams it out.** `vga_dma_master` issues Avalon-MM reads from the framebuffer,
   incrementing the address by 4 and wrapping back to the base address at the end of the frame — so the
   frame loops forever without any CPU involvement.
3. **A dual-clock FIFO bridges the domains.** SDRAM arrives at 50 MHz; VGA must be clocked at exactly
   74.25 MHz for 720p. `async_fifo_dc` is clock-crossing-safe (Gray-coded pointers, 2-FF synchronisers)
   and absorbs the bandwidth mismatch.
4. **A byte-unpack FSM feeds the pixel pipeline.** Each 32-bit FIFO word is split into four 8-bit pixels
   that are emitted one per `pixel_clk` during `active_video`.
5. **A DE1-SoC-compatible colour mapper drives the pins.** The 8-bit pixel value is bit-sliced into the
   board's 8/8/8 VGA DAC. Outside `active_video` the outputs are forced to black.

## Modules at a glance

| Module | File | Clock | Role |
| --- | --- | --- | --- |
| `de1_soc_snake_top` | `rtl/de1_soc_snake_top.v` | both | Top level. Instantiates and wires everything. |
| `vga_dma_master` | `rtl/vga_dma_master.v` | `CLOCK_50` | Avalon-MM read engine with back-pressure. |
| `async_fifo_dc` | `rtl/async_fifo_dc.v` | dual | Gray-coded asynchronous FIFO, 512 x 32-bit. |
| `video_timing_720p` | `rtl/video_timing_720p.v` | `pixel_clk` | 1280x720 @ 60 Hz sync generator. |
| `uart_rx` | `rtl/uart_rx.v` | `CLOCK_50` | 115200-baud UART receiver. |
| `uart_tx` | `rtl/uart_tx.v` | `CLOCK_50` | 115200-baud UART transmitter. |
| `uart_protocol` | `rtl/uart_protocol.v` | `CLOCK_50` | Command framing + checksum + ACK. |
| `pll_74p25` | `rtl/pll_74p25_stub.v` | — | 50 MHz -> 74.25 MHz PLL. **Stub — see notes.** |

## The framebuffer contract

Software and hardware must agree, or you get garbage on screen. The numbers are hard-coded in both halves:

| Property | Value | Where it appears |
| --- | --- | --- |
| Framebuffer base address | `0x3800_0000` | `vga_dma_master.BASE_ADDR` param |
| Resolution | 320 x 240 (software grid) | `sw/snake.c` `WIDTH` / `HEIGHT` |
| Pixel format | 8 bits per pixel | pixel-unpack FSM in the top module |
| Colour depth per channel | 8 bits (24-bit VGA DAC) | top module's R/G/G bit-slicing |
| `FRAME_BYTES` | 921,600 | `vga_dma_master` param |
| Grid block size | 20 x 20 px | `sw/snake.c` `BLOCK_SIZE` |
| VGA output timing | 1280 x 720 @ 60 Hz | `video_timing_720p` |
| Pixel clock | 74.25 MHz | `pll_74p25` |
| System clock | 50 MHz | `CLOCK_50` port |

## The UART command channel (optional)

Alongside the framebuffer, `uart_protocol` implements a small framed command protocol for sending
direction changes to the hardware over a USB-UART adapter on the GPIO header. This is an *alternative* to
the terminal-driven software input path.

**Packet format (host -> FPGA), 4 bytes:**

| Byte | Value | Meaning |
| --- | --- | --- |
| 0 | `0x55` | `PKT_START` sync byte |
| 1 | `cmd` | `0x01`=W, `0x02`=D, `0x03`=S, `0x04`=A |
| 2 | `payload` | Reserved / data |
| 3 | `0x55 ^ cmd ^ payload` | Checksum |

**ACK (FPGA -> host), 4 bytes:** `0xAA`, `cmd`, `payload`, `0xAA ^ cmd ^ payload`.

If the checksum byte does not match, the packet is silently dropped and the parser returns to the
`PKT_START` search state.

## Build and run

### 1. Synthesise in Quartus

1. Create a new Quartus project with the Cyclone V device `5CSEMA5F31C6`.
2. Add every `.v` file in `rtl/` to the project, top entity `de1_soc_snake_top`.
3. Add `qsf/de1_soc_snake_pins.qsf` to the project (it supplies the pin assignments).
4. Compile and Program.

> **The PLL is a stub.** See the note below — you must generate the real IP before this will drive a
> monitor at the right rate.

### 2. Run the software (on the board, under Linux)

```sh
gcc -O2 -o snake snake.c
./snake
```

Controls: `W` / `A` / `S` / `D`. `Ctrl+C` to exit.

## Known issues in the current state of the project

These are real gaps in the code as it stands. Be aware of them if you try to run this.

### 1. `pll_74p25_stub.v` is a pass-through, not a PLL

```verilog
assign outclk_0 = refclk;   // still 50 MHz, not 74.25 MHz
assign locked    = ~rst;
```

At 50 MHz the `video_timing_720p` counters run at 2/3 speed, so the output would be ~1000x500 instead of
1280x720 — most monitors will show a distorted or out-of-range image.

**Fix:** generate an `altera_pll` IP in Quartus named `pll_74p25`, input 50 MHz, output `outclk_0` at
74.25 MHz, and delete/replace the stub. The module name and port list in the stub were chosen to match the
IP's expected interface exactly, so nothing else needs to change.

### 2. `sw/snake.c` will not compile as-is

`FB_SIZE` and `FB_BASE_PHYS` are used on lines 79, 86, 90 and 161 but are **never defined**. You must add
them, e.g.:

```c
#define FB_BASE_PHYS 0x38000000
#define FB_SIZE      (WIDTH * HEIGHT)
```

`FPGA_ONCHIP_BASE` (`0xC8000000`) is also defined at the top but currently unused.

### 3. The software and hardware both drive input

`snake.c` reads `W`/`A`/`S`/`D` from stdin, *and* the hardware has a UART direction input. The two paths
are not arbitrated — pick one. Using the UART path is the natural fit for this design (that is likely why
`uart_protocol` exists), in which case the keyboard handling in `snake.c` becomes dead code.

### 4. 720p timing vs 320x240 content

The DMA streams 921,600 bytes per frame while 720p at 60 Hz needs 1280x720 = 921,600 pixels. The
arithmetic is consistent, but the software only fills 320x240 = 76,800 of those pixels. The remaining
84,800 bytes are whatever is in SDRAM, and they will be displayed stretched across the rest of the screen.
The top module's unpack FSM has no notion of scaling, so **the frame is not scaled** — this needs a
replication stage, or the video timing should be switched to a 320x240 mode (640x480 with 2x pixel
replication would be the conventional choice).

### 5. The colour mapping is coarse

```verilog
assign VGA_R = {pixel_index[7:5], pixel_index[7:5], pixel_index[7:5], pixel_index[7:6]};
```

The 8-bit pixel value is bit-sliced directly, so a single byte becomes 24-bit colour using only 3/3/2
bits per channel. The values `0x1C` and `0xE0` chosen in the software map to dark blue-ish and pale
yellow-ish on that scheme. It works, but the palette is not intuitive.

### 6. `tb/` only covers the DMA engine

There is one testbench, for `vga_dma_master`. The FIFO, video timing and UART modules have no testbenches.

## Design decisions worth understanding

- **Why a FIFO?** The SDRAM read path and the VGA output path are asynchronous and can never be
  phase-locked to each other. The FIFO is what makes it legal to cross the clock boundary.
- **Why Gray-coded pointers?** Binary counters increment by one, so several bits change at once during
  the transition. Sampling such a value through a flip-flop can land on a value that never existed — a
  metastable, phantom intermediate state. Gray code guarantees exactly one bit changes per increment, so
  any sample is either the old or the new value.
- **Why `MAX_OUTSTANDING`?** Avalon-MM allows multiple reads in flight, which hides SDRAM latency. The
  counter bounds that at 8 so the bridge is not swamped.
- **Why `fifo_has_room` reserves 16 entries?** A conservative margin so the DMA stops issuing well before
  the FIFO is actually full, giving the write side time to drain.
- **Why a `usedw` output?** The write pointer in Gray code cannot be subtracted to get a count. The FIFO
  converts the *synchronised* read Gray pointer back to binary, then subtracts — that is what
  `wr_usedw` reports and what `vga_dma_master` thresholds on.
