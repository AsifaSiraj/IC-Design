# sw/ — Snake Game Software

## What is this folder about?

`sw/` holds the **software half** of the snake_game project: `snake.c`, a Snake game written for Linux
userspace on the DE1-SoC. It contains the entire game — state, movement, collision, and rendering.

The division of labour with the hardware is deliberate and is the interesting part of this design:

| Concern | Where it lives |
| --- | --- |
| Game logic (movement, growth, collision) | **Software — this file** |
| Drawing pixels into SDRAM | **Software — this file** |
| Streaming SDRAM to the monitor | Hardware — `../rtl/vga_dma_master.v` |
| Video timing and sync | Hardware — `../rtl/video_timing_720p.v` |

The CPU never touches the VGA pins. It only writes bytes into a memory region; the hardware reads them
back and displays them.

## Files

| File | Description |
| --- | --- |
| `snake.c` | The entire game program. |

## The framebuffer mapping

```c
#define FPGA_ONCHIP_BASE 0xC8000000
#define WIDTH  320
#define HEIGHT 240
#define BLOCK_SIZE   20
#define MAX_SEGMENTS 512
```

The game renders onto a **320x240 8-bit-per-pixel framebuffer** in the FPGA's SDRAM, addressed as
`py * WIDTH + px`. Each snake segment is a solid `BLOCK_SIZE` x `BLOCK_SIZE` (20x20 px) block, so the
playable grid is 16 x 12 cells.

The framebuffer is accessed by mapping **physical** memory directly — the DE1-SoC's SDRAM sits at
`0x3800_0000` in the physical address space:

```c
fd = open("/dev/mem", O_RDWR | O_SYNC);
...
fb = (uint8_t *)mmap(NULL, FB_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, FB_BASE_PHYS);
memset((void *)fb, 0x00, FB_SIZE);
```

`O_SYNC` on the open and `MAP_SHARED` on the map are what guarantee the writes are actually visible to
the hardware DMA engine rather than sitting in a dirty CPU cache.

> **`FPGA_ONCHIP_BASE` (0xC8000000) is defined but never used.** It looks like a leftover from an
> earlier on-chip-RAM version of the design.

## Game constants

| Constant | Value | Meaning |
| --- | --- | --- |
| `WIDTH` | 320 | Framebuffer width in pixels |
| `HEIGHT` | 240 | Framebuffer height in pixels |
| `BLOCK_SIZE` | 20 | Size of one snake segment, in pixels |
| `MAX_SEGMENTS` | 512 | Static array bound for the snake body |
| initial `length` | 8 | Starting body length |
| `tick` | 83,333,333 ns | ~12 FPS via `nanosleep` |

`struct timespec tick = {0, 83333333};` is 83.3 ms, giving roughly **12 frames per second**. Every loop
iteration moves the snake one block and redraws, then sleeps for this duration.

## Data structures

```c
typedef struct {
    int x;
    int y;
} point_t;

point_t snake[MAX_SEGMENTS];
int length = 8;
```

A flat, statically allocated array of coordinates. `snake[0]` is always the head, `snake[length-1]` the
tail. The body is never resized — `MAX_SEGMENTS` is a compile-time cap, so there is no dynamic memory
allocation anywhere in the program.

## Movement

The body is shifted toward the head each tick, one element at a time from the back:

```c
for (i = length - 1; i > 0; i--) {
    snake[i] = snake[i - 1];
}
```

Then the head moves by one `BLOCK_SIZE` step in the current direction:

```c
snake[0].x += dir_x;
snake[0].y += dir_y;
```

Direction is stored as a step vector, which is why only 0 or `BLOCK_SIZE` ever appears:

```c
int dir_x = BLOCK_SIZE;   // moving right
int dir_y = 0;
```

## Input handling

The terminal is put into **raw, non-blocking** mode so the game can poll for keystrokes without `Enter`
and without blocking:

```c
rawt.c_lflag &= ~(ICANON | ECHO);   // no line buffering, no echo
rawt.c_cc[VMIN]  = 0;
rawt.c_cc[VTIME] = 0;
tcsetattr(STDIN_FILENO, TCSANOW, &rawt);

flags = fcntl(STDIN_FILENO, F_GETFL, 0);
fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);
```

Each tick does a single-byte `read()` and interprets `W`/`A`/`S`/`D` (both cases accepted):

```c
ssize_t n = read(STDIN_FILENO, &c, 1);
if (n > 0) {
    if ((c == 'w' || c == 'W') && dir_y == 0) { dir_x = 0; dir_y = -BLOCK_SIZE; }
    ...
}
```

### 180-degree reversal guard

Each branch also requires the **perpendicular** axis to be zero, which prevents the snake from folding
back on itself:

- `W` requires `dir_y == 0` (currently moving horizontally, so up is legal)
- `A` requires `dir_x == 0` (currently moving vertically, so left is legal)
- etc.

The effect: moving right and pressing `A` is ignored, because reversing into your own neck is instant
death. But the guard does allow `W` then `A` in consecutive ticks — each is a 90-degree turn relative to
the direction one tick earlier.

## Collision detection

```c
if (new_head.x < 0 || new_head.x >= WIDTH ||
    new_head.y < 0 || new_head.y >= HEIGHT ||
    intersects_body(new_head, snake, length)) {
    puts("Game over: collision detected.");
    break;
}
```

`intersects_body()` deliberately **starts at index 1**, not 0:

```c
for (i = 1; i < length; i++) { ... }
```

Skipping index 0 skips the head itself — otherwise the new head would always "collide" with its own old
position on the very first tick. This is correct; the check should really be against `snake[i-1]`, but
starting at 1 is the standard formulation.

There is **no food and no growth logic** in this version — the snake never gets longer, and
`intersects_body` is purely a self-collision check against the fixed length of 8. `MAX_SEGMENTS` and the
length-growth path are set up but unused.

## Rendering

`draw_block()` paints a 20x20 square with bounds clipping:

```c
static void draw_block(uint8_t *fb, int x, int y, uint8_t color) {
    for (j = 0; j < BLOCK_SIZE; j++) {
        int py = y + j;
        if (py < 0 || py >= HEIGHT) continue;      // clip vertically
        for (i = 0; i < BLOCK_SIZE; i++) {
            int px = x + i;
            if (px < 0 || px >= WIDTH) continue;   // clip horizontally
            fb[py * WIDTH + px] = color;
        }
    }
}
```

The clipping is what lets the snake be one block off-centre at the start without a special case, and it
means a partially off-screen draw is safe rather than a buffer overrun.

**Partial redraw, not a full clear.** Each tick only touches the pixels that changed:

```c
draw_block(fb, old_tail.x, old_tail.y, 0x00);   // erase where the tail was
draw_block(fb, snake[0].x, snake[0].y, 0x1C);  // draw the head
for (i = 1; i < length; i++)
    draw_block(fb, snake[i].x, snake[i].y, 0xE0);  // redraw the body
```

This saves a 76,800-byte `memset` per frame. The full `memset(fb, 0, FB_SIZE)` happens once, at startup.

### Colours

| Value | Used for |
| --- | --- |
| `0x00` | Background, and erasing the old tail position |
| `0xE0` | Snake body |
| `0x1C` | Snake head (slightly different, to distinguish it) |

These 8-bit values are bit-sliced by the hardware as R=[7:5], G=[4:2], B=[1:0], so `0xE0` (1110_0000) is
full red and `0x1C` (0001_1100) is a dim green. The intent was clearly "body vs head" but the mapping
through the hardware's colour slicer is not intuitive.

## Frame pacing

```c
struct timespec tick = {0, 83333333};   // 83.3 ms
...
nanosleep(&tick, NULL);
```

Roughly **12 FPS**. Note the game speed is decoupled from the video refresh — the hardware reads the
same framebuffer ~60 times per second while the CPU only updates it 12 times. That works because the DMA
is continuous and the software never waits on it.

## Clean shutdown

A `SIGINT` handler sets a flag rather than exiting directly, so the cleanup path always runs:

```c
static volatile sig_atomic_t g_stop = 0;
static void handle_sigint(int sig) { (void)sig; g_stop = 1; }
...
while (!g_stop) { ... }
```

Then the terminal, mapping, and file descriptor are all restored:

```c
tcsetattr(STDIN_FILENO, TCSANOW, &oldt);              // restore cooked mode
fcntl(STDIN_FILENO, F_SETFL, flags);                  // clear O_NONBLOCK
munmap((void *)fb, FB_SIZE);
close(fd);
```

`volatile sig_atomic_t` is the correct type for a flag written from a signal handler — it is guaranteed
to be written and read atomically.

## Build and run

```sh
gcc -O2 -Wall -o snake snake.c
./snake
```

Controls: `W` `A` `S` `D`, `Ctrl+C` to quit.

Requires root, because `/dev/mem` is normally restricted:

```sh
sudo ./snake
```

## Known issues

### 1. It does not compile as it stands

`FB_SIZE` and `FB_BASE_PHYS` are used on lines 79, 86, 90 and 161 but are **never defined anywhere in
the file**. Add them before building:

```c
#define FB_BASE_PHYS 0x38000000
#define FB_SIZE      (WIDTH * HEIGHT)
```

### 2. Error path leaks the terminal

If `tcgetattr()` fails, the function returns immediately without closing `fd` (it does `munmap` and
`close` there, but if `mmap` had already failed, `fb` is not a valid pointer to pass around). More
importantly, if any early return happens after `tcsetattr()` but before the restore block, the
terminal is left in raw mode. The current `tcgetattr` failure path happens *before* `tcsetattr`, so it
is safe today, but the ordering is fragile.

### 3. Duplicate input paths

The game reads `W`/`A`/`S`/`D` from stdin, while the hardware also has a UART direction input
(`../rtl/uart_protocol.v` produces a `dir` signal). These are **not arbitrated**. Choose one. Using the
UART path is the more natural fit for this design — that is likely why `uart_protocol` exists — in which
case the terminal key handling here becomes dead code and the software only needs to render.

### 4. No food, no growth, no score

`MAX_SEGMENTS` is 512 but `length` is fixed at 8 and never incremented. The snake can only die, never
win. Growth logic (spawn food, detect head-over-food, increment `length`) would go between the
`intersects_body` check and the redraw.

### 5. Slow polling wastes CPU

`read()` with `O_NONBLOCK` is called once per tick and returns `EAGAIN` on most iterations. Polling this
way burns a syscall per frame; a `select()`/`poll()` on stdin, or an `epoll` timer, would be cleaner.

### 6. Resolution mismatch with the video timing

The framebuffer is 320x240, but the hardware's `video_timing_720p` produces 1280x720. The DMA reads
`FRAME_BYTES = 921600` per frame — exactly 1280x720x1 — so the extra 84,800 bytes of unread SDRAM get
displayed too. Nothing scales the 320x240 image up. See "Known issues" in `../README.md`.
