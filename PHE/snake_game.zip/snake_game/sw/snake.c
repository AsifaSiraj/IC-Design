#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

#define FPGA_ONCHIP_BASE 0xC8000000
#define WIDTH 320
#define HEIGHT 240
#define BLOCK_SIZE 20
#define MAX_SEGMENTS 512

typedef struct {
    int x;
    int y;
} point_t;

static volatile sig_atomic_t g_stop = 0;

static void handle_sigint(int sig) {
    (void)sig;
    g_stop = 1;
}

static void draw_block(uint8_t *fb, int x, int y, uint8_t color) {
    int i, j;
    for (j = 0; j < BLOCK_SIZE; j++) {
        int py = y + j;
        if (py < 0 || py >= HEIGHT) {
            continue;
        }
        for (i = 0; i < BLOCK_SIZE; i++) {
            int px = x + i;
            if (px < 0 || px >= WIDTH) {
                continue;
            }
            fb[py * WIDTH + px] = color;
        }
    }
}

static int intersects_body(point_t head, point_t *body, int length) {
    int i;
    for (i = 1; i < length; i++) {
        if (head.x == body[i].x && head.y == body[i].y) {
            return 1;
        }
    }
    return 0;
}

int main(void) {
    int fd = -1;
    uint8_t *fb = NULL;
    struct termios oldt;
    struct termios rawt;
    int flags;
    point_t snake[MAX_SEGMENTS];
    int length = 8;
    int dir_x = BLOCK_SIZE;
    int dir_y = 0;
    int i;
    struct timespec tick = {0, 83333333};

    signal(SIGINT, handle_sigint);

    fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (fd < 0) {
        perror("open /dev/mem failed");
        return 1;
    }

    fb = (uint8_t *)mmap(NULL, FB_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, FB_BASE_PHYS);
    if (fb == MAP_FAILED) {
        perror("mmap failed");
        close(fd);
        return 1;
    }

    memset((void *)fb, 0x00, FB_SIZE);

    if (tcgetattr(STDIN_FILENO, &oldt) != 0) {
        perror("tcgetattr failed");
        munmap((void *)fb, FB_SIZE);
        close(fd);
        return 1;
    }

    rawt = oldt;
    rawt.c_lflag &= ~(ICANON | ECHO);
    rawt.c_cc[VMIN] = 0;
    rawt.c_cc[VTIME] = 0;
    tcsetattr(STDIN_FILENO, TCSANOW, &rawt);

    flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);

    for (i = 0; i < length; i++) {
        snake[i].x = WIDTH / 2 - i * BLOCK_SIZE;
        snake[i].y = HEIGHT / 2;
        draw_block(fb, snake[i].x, snake[i].y, 0xE0);
    }

    puts("Snake started. Use W/A/S/D. Press Ctrl+C to exit.");

    while (!g_stop) {
        char c;
        point_t old_tail = snake[length - 1];
        point_t new_head;
        ssize_t n = read(STDIN_FILENO, &c, 1);

        if (n > 0) {
            if ((c == 'w' || c == 'W') && dir_y == 0) {
                dir_x = 0;
                dir_y = -BLOCK_SIZE;
            } else if ((c == 's' || c == 'S') && dir_y == 0) {
                dir_x = 0;
                dir_y = BLOCK_SIZE;
            } else if ((c == 'a' || c == 'A') && dir_x == 0) {
                dir_x = -BLOCK_SIZE;
                dir_y = 0;
            } else if ((c == 'd' || c == 'D') && dir_x == 0) {
                dir_x = BLOCK_SIZE;
                dir_y = 0;
            }
        }

        for (i = length - 1; i > 0; i--) {
            snake[i] = snake[i - 1];
        }

        snake[0].x += dir_x;
        snake[0].y += dir_y;
        new_head = snake[0];

        if (new_head.x < 0 || new_head.x >= WIDTH || new_head.y < 0 || new_head.y >= HEIGHT ||
            intersects_body(new_head, snake, length)) {
            puts("Game over: collision detected.");
            break;
        }

        draw_block(fb, old_tail.x, old_tail.y, 0x00);
        draw_block(fb, snake[0].x, snake[0].y, 0x1C);
        for (i = 1; i < length; i++) {
            draw_block(fb, snake[i].x, snake[i].y, 0xE0);
        }

        nanosleep(&tick, NULL);
    }

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, flags);

    if (fb && fb != MAP_FAILED) {
        munmap((void *)fb, FB_SIZE);
    }
    if (fd >= 0) {
        close(fd);
    }

    return 0;
}
