# qsf/ — Quartus Pin Assignments

## What is this folder about?

`qsf/` holds the **Quartus Settings File** for the snake_game project: a plain-text file that tells
Quartus which physical pins on the Cyclone V device each HDL signal should drive, and what electrical
standard to use.

This is the **physical-to-logical mapping layer**. The RTL declares ports like `VGA_R[0]`; the QSF says
that `VGA_R[0]` is really pin `A13` on the package. Without this file, Quartus compiles but the design
goes nowhere when you program the board.

## Files

| File | Description |
| --- | --- |
| `de1_soc_snake_pins.qsf` | All pin locations and IO standards for the DE1-SoC. |

## Target device

```tcl
set_global_assignment -name FAMILY "Cyclone V"
set_global_assignment -name DEVICE 5CSEMA5F31C6
```

That is the Cyclone V SoC on the **Terasic DE1-SoC** board — an `5CSEMA5` with a hard ARM Cortex-A9
system-on-chip and 1 GB of SDRAM.

## Contents of the file

### 1. Clock — `PIN_AF14`

```tcl
set_location_assignment PIN_AF14 -to CLOCK_50
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to CLOCK_50
```

The board's 50 MHz oscillator. Everything in the design is either in this domain or derived from it
through `pll_74p25`.

### 2. Reset — `KEY[0]` on `PIN_AA14`

```tcl
set_location_assignment PIN_AA14 -to KEY[0]
```

Active-low reset, matching `wire reset_n = KEY[0];` in the top module. KEY[0] is the bottom button on
the DE1-SoC.

### 3. VGA control signals

| Signal | Pin |
| --- | --- |
| `VGA_HS` | `PIN_B11` |
| `VGA_VS` | `PIN_D11` |
| `VGA_BLANK_N` | `PIN_F10` |
| `VGA_SYNC_N` | `PIN_C10` |
| `VGA_CLK` | `PIN_A11` |

Individually assigned with explicit `IO_STANDARD` lines, rather than a wildcard. The four colour buses
below use wildcards instead — this file is slightly inconsistent in style, but both work.

### 4. VGA colour — 24 bits, 8 per channel

| Channel | Pins |
| --- | --- |
| `VGA_R[0..7]` | `A13 C13 E13 B12 C12 D12 E12 F13` |
| `VGA_G[0..7]` | `J9 J10 H12 G10 G11 G12 F11 E11` |
| `VGA_B[0..7]` | `B13 G13 H13 F14 H14 F15 G15 J14` |

Note the bit ordering: `VGA_R[0]` is `PIN_A13`, `VGA_R[7]` is `PIN_F13`, and so on. **These are not
sequential across the connector** — the FPGA side is a packed bus while the DE1-SoC's VGA DAC is
4:2:2 encoded. Getting this table wrong is the single most common DE1-SoC error, and the comments in the
file (lines 35, 47, 59) flag that these were cross-checked against Manual Table 3-16.

The colour buses use wildcard IO standards:

```tcl
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to VGA_R[*]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to VGA_G[*]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to VGA_B[*]
```

### 5. UART — commented out

```tcl
# GPIO_0[0]
# set_location_assignment PIN_AC18 -to UART_TXD

# GPIO_0[1]
# set_location_assignment PIN_Y17 -to UART_RXD
```

The UART pins are present but **disabled by default**, with wiring notes explaining the hookup through a
USB-UART adapter:

```
# FPGA TX ---> Adapter RX
# FPGA RX <--- Adapter TX
```

This is deliberate — the pins are on the GPIO header rather than a dedicated connector, so enabling them
is a choice. Uncomment all four lines to activate the UART command channel.

## Signals NOT in this file

Two notable omissions:

- **The Avalon-MM signals** (`am_addr`, `am_read`, `am_waitrequest`, `am_readdata`,
  `am_readdatavalid`) have no assignments. In the full DE1-SoC design these would come from the
  `f2h_sdram` / `avalon` system interconnect modules via a `.qsys`/Platform Designer system, not from a
  hand-written QSF. **This project is only the custom logic half** — it assumes the SoC interconnect
  already exists in the overall design and drives the Avalon-MM port from it.

  Practically: to build this, either add the DE1-SoC default system (`DE1-SoC.qsys`) to the project and
  wire the port to it, or you must provide the Avalon-MM slave yourself.

- **SDRAM** — same reason. The SDRAM controller lives in the DE1-SoC's default Qsys system, not here.

This is why the folder is named `qsf/` rather than the project root: it holds *just the custom pin
assignments*, not a complete standalone Quartus project. There is no `.qpf` project file and no
`.sdc` timing constraints file.

## How to use it

### Option A — add to a full DE1-SoC Quartus project

1. Open the DE1-SoC default system project in Quartus.
2. **File → Settings → General → HDL Settings**, or simply add the `.qsf` via
   **Assignments → Import Assignments**.
3. Add all `.v` files from `../rtl/` and set `de1_soc_snake_top` as the top entity.

### Option B — import into a new project

Create a new Quartus project for `5CSEMA5F31C6`, add the RTL, then:

**Assignments → Import Assignments →** select `de1_soc_snake_pins.qsf`

or append the file contents to your project's own `.qsf`.

## How to verify

**Assignments → Pin Planner** shows a graphical view. Every signal in your design that is *not* assigned a
pin shows up in red as "Unassigned" — that list is the fastest way to spot a missing entry.

**Processing → Compilation Report → Fitter** gives the definitive answer: any I/O that could not be
placed appears under "Unplaced I/O", and the fit fails outright if the design does not fit the chosen
device.

## Verifying the VGA pin table against the board

If the colours come out swapped or garbled, the pin table is the first thing to re-check against
**DE1-SoC System User Manual, Table 3-16** (VGA connector pin assignment). Compare each
`set_location_assignment` line. The second commonest cause is an IO standard mismatch — everything here
must be `3.3-V LVTTL` to match the board.
