# tb/ — Testbench

## What is this folder about?

`tb/` holds **simulation testbenches** — simulation-only Verilog that instantiates a design, drives its
inputs, and checks its outputs. None of this code goes into the FPGA; it exists purely to verify the RTL
in a simulator before you commit to a Quartus compile.

This is the only folder in `snake_game` written in **SystemVerilog** (the `.sv` extension) rather than
Verilog, and the only one that is not synthesizable.

## Files

| File | Tests |
| --- | --- |
| `tb_vga_dma_master.sv` | `../rtl/vga_dma_master.v` — the Avalon-MM read engine |

## Coverage

One testbench exists, for one of the seven RTL modules:

| Module | Testbench |
| --- | --- |
| `vga_dma_master` | **`tb_vga_dma_master.sv`** |
| `async_fifo_dc` | none |
| `video_timing_720p` | none |
| `uart_rx` | none |
| `uart_tx` | none |
| `uart_protocol` | none |
| `de1_soc_snake_top` | none |

The FIFO is the most valuable missing one — dual-clock crossing is exactly the kind of logic that passes
eyeball review and fails in hardware.

---

## `tb_vga_dma_master.sv` — DMA Engine Testbench

### Approach

The testbench plays the role of the **SDRAM controller and the FIFO simultaneously** — it models both
sides of the DUT's interface so it can verify the protocol without needing real hardware.

The frame is shrunk to make simulation fast:

| Parameter | Real design | Testbench |
| --- | --- | --- |
| `BASE_ADDR` | `0x3800_0000` | `0x3800_0000` |
| `FRAME_BYTES` | 921,600 | **64** (16 reads) |
| `FIFO_ADDR_WIDTH` | 9 | 9 |
| `MAX_OUTSTANDING` | 8 | **4** |

With a 20 ns clock period and 200 cycles of run time, the whole test finishes in about 4 microseconds of
simulated time.

### Clock and reset

```systemverilog
always #10 clk = ~clk;    // 20 ns period = 50 MHz
```

Matching the real `CLOCK_50` domain. Reset is held for 5 cycles then released:

```systemverilog
repeat (5)  @(posedge clk);
rst_n = 1'b1;
repeat (200) @(posedge clk);
$display("TB PASS: DMA address stepping and am_read pulse behavior verified.");
$finish;
```

Note the pattern: **always `$display` the pass and then check the errors separately.** Failures call
`$fatal` immediately, so reaching the PASS line *is* the success condition.

### BFM 1 — The Avalon-MM slave (back-pressure model)

`am_waitrequest` is driven pseudo-randomly to exercise stalling:

```systemverilog
if (($time / 20) % 13 == 0 || ($time / 20) % 17 == 0)
    am_waitrequest <= 1'b1;
else
    am_waitrequest <= 1'b0;
```

Two coprime-ish periods (13 and 17) make the stall pattern irregular, so the DUT cannot pass by
accidentally fitting a fixed cadence.

The return data is generated with a three-stage pipeline, which is a deliberate **non-zero-latency
Avalon-MM model** — real SDRAM bridges are not zero-latency, and a DUT that assumes they are will fail
here even if it "works" on simple hardware:

```systemverilog
valid_pipe[0] <= am_read && !am_waitrequest;
am_readdatavalid <= valid_pipe[2];      // 3 cycles later
am_readdata     <= data_pipe[2];
```

`data_pipe[0] <= am_addr ^ 32'hA5A5_5A5A;` makes the returned data a deterministic function of the
address, so data integrity can be checked if desired.

### BFM 2 — The FIFO (occupancy model)

The testbench tracks FIFO occupancy itself so the `fifo_wr_usedw` input to the DUT is realistic — and
critically, it **drains** so occupancy does not monotonically rise and starve the DMA:

```systemverilog
if (fifo_wr_en && !fifo_wr_full)
    fifo_wr_usedw <= fifo_wr_usedw + 10'd1;

if (($time / 20) % 9 == 0 && fifo_wr_usedw != 0)
    fifo_wr_usedw <= fifo_wr_usedw - 10'd1;   // the read side consuming
```

Without that drain, `fifo_wr_usedw` would climb until `fifo_has_room` goes false, the DMA would stop
issuing, and the run would be uninteresting.

### Checker 1 — Address sequence

Mirrors the DUT's expected behaviour and compares on every accepted read:

```systemverilog
if (am_read && !am_waitrequest) begin
    if (am_addr !== expected_addr) begin
        $error("Address mismatch. expected=%h got=%h", expected_addr, am_addr);
        $fatal;
    end

    if (expected_addr == (BASE_ADDR + FRAME_BYTES - 4))
        expected_addr <= BASE_ADDR;          // must wrap
    else
        expected_addr <= expected_addr + 32'd4;
end
```

This verifies the three properties that matter for a video DMA:

1. **Addresses step by exactly 4** (one 32-bit word per read).
2. **The address does not move on a stalled read** — it is only checked when `am_read && !am_waitrequest`,
   so an incorrect advance during back-pressure would desynchronise the reference and fail here.
3. **The frame wraps** back to `BASE_ADDR` at the last word, which is what makes the video loop forever
   with no CPU involvement.

### Checker 2 — `am_read` pulse behaviour

The most important protocol check, and the one most likely to catch a real bug:

```systemverilog
accepted_d1 <= am_read && !am_waitrequest;

if (accepted_d1 && am_read) begin
    $error("am_read must deassert in the cycle after acceptance");
    $fatal;
end
```

`am_read` must be a **one-cycle pulse per accepted read**. Asserting it continuously would mean
re-requesting the same address, which on real Avalon-MM would be interpreted as multiple reads of the
same word — the frame would be drawn with the same pixel repeated 8 times.

## How to run it

### Icarus Verilog

```sh
iverilog -g2012 -o tb_dma.out tb/tb_vga_dma_master.sv rtl/vga_dma_master.v
vvp tb_dma.out
```

### ModelSim / Questa

```sh
vlog -sv rtl/vga_dma_master.v tb/tb_vga_dma_master.sv
vsim -voptargs=+acc work.tb_vga_dma_master
run -all
```

### Quartus NativeLink

Add both files to the project, set the testbench as the top-level entity, and use
**Tools → Run Simulation Tool → RTL Simulation**.

## What this testbench does *not* check

Worth knowing before you trust a "TB PASS":

- **Data integrity.** `data_pipe` is computed but the `fifo_wr_data` output is never compared against
  what was requested. A DUT that returned the wrong word would still pass.
- **Outstanding-read limits.** `MAX_OUTSTANDING` is set to 4, but nothing asserts that
  `outstanding_reads` ever stays at or below it.
- **The `fifo_has_room` threshold.** Occupancy is modelled loosely; the specific
  `FIFO_DEPTH - 16` margin is never verified.
- **Address wrap timing.** The checker verifies wrap *order* but not that the frame restarts at a
  plausible period.
- **Reset behaviour mid-operation.** Reset is only applied at time 0.

## Testbenches worth writing next

In rough priority order:

1. **`tb_async_fifo_dc.sv`** — the highest-value one. Needs two clocks, random write/read enable
   patterns, and a scoreboard that compares FIFO contents against a reference queue. Should also test
   the `wr_full` and `rd_empty` boundaries, since a wrong `wr_full` comparator is the classic bug in
   this design (the two-inverted-bits trick is easy to get off by one).
2. **`tb_video_timing_720p.sv`** — check that `hs` pulses for 40 clocks every 1650, `vs` for 5 lines every
   750, and that `active_video` is high for exactly 1280x720 of the 1650x750 total. Purely arithmetic,
   quick to write, catches off-by-one porch errors immediately.
3. **`tb_uart_rx.sv` / `tb_uart_tx.sv`** — drive a serial bit stream at 115200 baud and check the
   assembled byte. A loopback test (`uart_tx` output fed into `uart_rx` input) covers both at once.
4. **`tb_de1_soc_snake_top.sv`** — an integration test instantiating the whole design with a simplified
   memory model on the Avalon-MM side, checking that the VGA outputs follow the intended pixel order.
