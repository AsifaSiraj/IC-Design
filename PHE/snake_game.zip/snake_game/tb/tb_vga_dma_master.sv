`timescale 1ns/1ps

module tb_vga_dma_master;

    localparam BASE_ADDR = 32'h3800_0000;
    localparam FRAME_BYTES = 64;

    reg clk;
    reg rst_n;

    wire [31:0] am_addr;
    wire am_read;
    reg am_waitrequest;
    reg [31:0] am_readdata;
    reg am_readdatavalid;

    wire [31:0] fifo_wr_data;
    wire fifo_wr_en;
    reg fifo_wr_full;
    reg [9:0] fifo_wr_usedw;

    reg [31:0] expected_addr;
    reg accepted_d1;

    reg [2:0] valid_pipe;
    reg [31:0] data_pipe [0:2];

    vga_dma_master #(
        .BASE_ADDR(BASE_ADDR),
        .FRAME_BYTES(FRAME_BYTES),
        .FIFO_ADDR_WIDTH(9),
        .MAX_OUTSTANDING(4)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .am_addr(am_addr),
        .am_read(am_read),
        .am_waitrequest(am_waitrequest),
        .am_readdata(am_readdata),
        .am_readdatavalid(am_readdatavalid),
        .fifo_wr_data(fifo_wr_data),
        .fifo_wr_en(fifo_wr_en),
        .fifo_wr_full(fifo_wr_full),
        .fifo_wr_usedw(fifo_wr_usedw)
    );

    always #10 clk = ~clk;

    initial begin
        clk = 1'b0;
        rst_n = 1'b0;
        am_waitrequest = 1'b0;
        am_readdata = 32'd0;
        am_readdatavalid = 1'b0;
        fifo_wr_full = 1'b0;
        fifo_wr_usedw = 10'd0;
        expected_addr = BASE_ADDR;
        accepted_d1 = 1'b0;
        valid_pipe = 3'b000;
        data_pipe[0] = 32'd0;
        data_pipe[1] = 32'd0;
        data_pipe[2] = 32'd0;

        repeat (5) @(posedge clk);
        rst_n = 1'b1;

        repeat (200) @(posedge clk);
        $display("TB PASS: DMA address stepping and am_read pulse behavior verified.");
        $finish;
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            am_waitrequest <= 1'b0;
        end else begin
            // Create periodic back-pressure to verify stall behavior.
            if (($time / 20) % 13 == 0 || ($time / 20) % 17 == 0) begin
                am_waitrequest <= 1'b1;
            end else begin
                am_waitrequest <= 1'b0;
            end
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            valid_pipe <= 3'b000;
            data_pipe[0] <= 32'd0;
            data_pipe[1] <= 32'd0;
            data_pipe[2] <= 32'd0;
        end else begin
            valid_pipe[2] <= valid_pipe[1];
            valid_pipe[1] <= valid_pipe[0];
            valid_pipe[0] <= am_read && !am_waitrequest;

            data_pipe[2] <= data_pipe[1];
            data_pipe[1] <= data_pipe[0];
            data_pipe[0] <= am_addr ^ 32'hA5A5_5A5A;
        end
    end

    always @(posedge clk) begin
        am_readdatavalid <= valid_pipe[2];
        am_readdata <= data_pipe[2];
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            expected_addr <= BASE_ADDR;
            accepted_d1 <= 1'b0;
        end else begin
            accepted_d1 <= am_read && !am_waitrequest;

            if (am_read && !am_waitrequest) begin
                if (am_addr !== expected_addr) begin
                    $error("Address mismatch. expected=%h got=%h", expected_addr, am_addr);
                    $fatal;
                end

                if (expected_addr == (BASE_ADDR + FRAME_BYTES - 4)) begin
                    expected_addr <= BASE_ADDR;
                end else begin
                    expected_addr <= expected_addr + 32'd4;
                end
            end

            // Requirement check: read should drop after a successful handshake.
            if (accepted_d1 && am_read) begin
                $error("am_read must deassert in the cycle after acceptance");
                $fatal;
            end
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            fifo_wr_usedw <= 10'd0;
        end else begin
            if (fifo_wr_en && !fifo_wr_full) begin
                fifo_wr_usedw <= fifo_wr_usedw + 10'd1;
            end

            if (($time / 20) % 9 == 0 && fifo_wr_usedw != 0) begin
                fifo_wr_usedw <= fifo_wr_usedw - 10'd1;
            end
        end
    end

endmodule
