`timescale 1ns/1ps

module uart_tx #(
    parameter integer CLK_FREQ_HZ = 50000000,
    parameter integer BAUD        = 115200
) (
    input  wire      clk,
    input  wire      rst_n,
    input  wire [7:0] data,
    input  wire      data_valid,
    output reg       tx,
    output reg       busy
);

    localparam integer BAUD_DIV = CLK_FREQ_HZ / BAUD;

    reg [15:0] baud_cnt;
    reg [3:0]  bit_idx;
    reg [9:0]  frame;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx <= 1'b1;
            busy <= 1'b0;
            baud_cnt <= 16'd0;
            bit_idx <= 4'd0;
            frame <= 10'h3FF;
        end else begin
            if (!busy) begin
                tx <= 1'b1;
                if (data_valid) begin
                    frame <= {1'b1, data, 1'b0};
                    busy <= 1'b1;
                    bit_idx <= 4'd1;
                    baud_cnt <= BAUD_DIV[15:0] - 1'b1;
                    tx <= 1'b0;
                end
            end else begin
                if (baud_cnt == 16'd0) begin
                    baud_cnt <= BAUD_DIV[15:0] - 1'b1;
                    if (bit_idx == 4'd9) begin
                        busy <= 1'b0;
                        tx <= 1'b1;
                    end else begin
                        tx <= frame[bit_idx];
                        bit_idx <= bit_idx + 1'b1;
                    end
                end else begin
                    baud_cnt <= baud_cnt - 1'b1;
                end
            end
        end
    end

endmodule
