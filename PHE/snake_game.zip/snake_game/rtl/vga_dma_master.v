`timescale 1ns/1ps

module vga_dma_master #(
    parameter [31:0] BASE_ADDR       = 32'h3800_0000,
    parameter integer FRAME_BYTES    = 921600,
    parameter integer FIFO_ADDR_WIDTH = 9,
    parameter integer MAX_OUTSTANDING = 8
) (
    input  wire                     clk,
    input  wire                     rst_n,

    output reg  [31:0]              am_addr,
    output reg                       am_read,
    input  wire                     am_waitrequest,
    input  wire [31:0]              am_readdata,
    input  wire                     am_readdatavalid,

    output wire [31:0]              fifo_wr_data,
    output wire                     fifo_wr_en,
    input  wire                     fifo_wr_full,
    input  wire [FIFO_ADDR_WIDTH:0] fifo_wr_usedw
);

    localparam integer FIFO_DEPTH = (1 << FIFO_ADDR_WIDTH);
    localparam [31:0] FRAME_LAST_ADDR = BASE_ADDR + FRAME_BYTES - 4;

    reg [4:0] outstanding_reads;

    wire fifo_has_room;
    wire can_issue;
    wire accepted;

    assign fifo_has_room = (fifo_wr_usedw < (FIFO_DEPTH - 16));
    assign can_issue = fifo_has_room && (outstanding_reads < MAX_OUTSTANDING);
    assign accepted = am_read && !am_waitrequest;

    assign fifo_wr_data = am_readdata;
    assign fifo_wr_en = am_readdatavalid && !fifo_wr_full;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            am_addr <= BASE_ADDR;
            am_read <= 1'b0;
            outstanding_reads <= 5'd0;
        end else begin
            if (accepted) begin
                am_read <= 1'b0;
                if (am_addr == FRAME_LAST_ADDR) begin
                    am_addr <= BASE_ADDR;
                end else begin
                    am_addr <= am_addr + 32'd4;
                end
            end else if (!am_read && can_issue) begin
                am_read <= 1'b1;
            end

            case ({accepted, am_readdatavalid})
                2'b10: outstanding_reads <= outstanding_reads + 1'b1;
                2'b01: begin
                    if (outstanding_reads != 0) begin
                        outstanding_reads <= outstanding_reads - 1'b1;
                    end
                end
                default: outstanding_reads <= outstanding_reads;
            endcase
        end
    end

endmodule
