`timescale 1ns/1ps

// Replace this stub with a Quartus-generated PLL IP that converts 50 MHz -> 74.25 MHz.
module pll_74p25 (
    input  wire refclk,
    input  wire rst,
    output wire outclk_0,
    output wire locked
);

    assign outclk_0 = refclk;
    assign locked = ~rst;

endmodule
