`timescale 1ns/1ps

module de1_soc_snake_top (
    input  wire        CLOCK_50,
    input  wire [0:0]  KEY,

    // Avalon-MM master read port to f2h_sdram bridge.
    output wire [31:0] am_addr,
    output wire        am_read,
    input  wire        am_waitrequest,
    input  wire [31:0] am_readdata,
    input  wire        am_readdatavalid,

    // VGA output signals.
    output wire [7:0]  VGA_R,
    output wire [7:0]  VGA_G,
    output wire [7:0]  VGA_B,
    output wire        VGA_HS,
    output wire        VGA_VS,
    output wire        VGA_BLANK_N,
    output wire        VGA_SYNC_N,
    output wire        VGA_CLK,

    // Optional UART command channel.
    input  wire        UART_RXD,
    output wire        UART_TXD
);

    wire reset_n = KEY[0];

    wire pixel_clk;
    wire pll_locked;

    wire [11:0] px;
    wire [10:0] py;
    wire active_video;

    wire [31:0] fifo_rd_data;
    wire fifo_rd_empty;
    reg  fifo_rd_en;

    wire [31:0] fifo_wr_data;
    wire fifo_wr_en;
    wire fifo_wr_full;
    wire [9:0] fifo_wr_usedw;

    reg [31:0] cur_word;
    reg [31:0] next_word;
    reg [1:0]  byte_sel;
    reg        cur_valid;
    reg        next_valid;
    reg        rd_pending;
    reg [7:0]  pixel_index;

    wire [1:0] uart_dir;

    // Generate 74.25 MHz pixel clock from CLOCK_50 using Quartus IP.
    pll_74p25 u_pll (
        .refclk   (CLOCK_50),
        .rst      (~reset_n),
        .outclk_0 (pixel_clk),
        .locked   (pll_locked)
    );

    video_timing_720p u_timing (
        .pixel_clk(pixel_clk),
        .rst_n(reset_n & pll_locked),
        .x(px),
        .y(py),
        .active_video(active_video),
        .hs(VGA_HS),
        .vs(VGA_VS)
    );

    vga_dma_master #(
        .BASE_ADDR(32'h3800_0000),
        .FRAME_BYTES(921600),
        .FIFO_ADDR_WIDTH(9),
        .MAX_OUTSTANDING(8)
    ) u_dma (
        .clk(CLOCK_50),
        .rst_n(reset_n & pll_locked),
        .am_addr(am_addr),
        .am_read(am_read),
        .am_waitrequest(am_waitrequest),
        .am_readdata(am_readdata),
        .am_readdatavalid(am_readdatavalid),
        .fifo_wr_data(fifo_wr_data),
        .fifo_wr_en(fifo_wr_en),
        .fifo_wr_full(fifo_wr_full),
        .fifo_wr_usedw(fifo_wr_usedw)
    );

    async_fifo_dc #(
        .DATA_WIDTH(32),
        .ADDR_WIDTH(9)
    ) u_fifo (
        .wr_clk(CLOCK_50),
        .wr_rst_n(reset_n & pll_locked),
        .wr_en(fifo_wr_en),
        .wr_data(fifo_wr_data),
        .wr_full(fifo_wr_full),
        .wr_usedw(fifo_wr_usedw),

        .rd_clk(pixel_clk),
        .rd_rst_n(reset_n & pll_locked),
        .rd_en(fifo_rd_en),
        .rd_data(fifo_rd_data),
        .rd_empty(fifo_rd_empty)
    );

    uart_protocol #(
        .CLK_FREQ_HZ(50000000),
        .BAUD(115200)
    ) u_uart (
        .clk(CLOCK_50),
        .rst_n(reset_n),
        .rx(UART_RXD),
        .tx(UART_TXD),
        .dir(uart_dir)
    );

    always @(posedge pixel_clk or negedge reset_n) begin
        if (!reset_n) begin
            fifo_rd_en <= 1'b0;
            rd_pending <= 1'b0;
            cur_word <= 32'd0;
            next_word <= 32'd0;
            byte_sel <= 2'd0;
            cur_valid <= 1'b0;
            next_valid <= 1'b0;
            pixel_index <= 8'd0;
        end else begin
            fifo_rd_en <= 1'b0;

            if (!rd_pending && !next_valid && !fifo_rd_empty) begin
                fifo_rd_en <= 1'b1;
                rd_pending <= 1'b1;
            end else if (rd_pending) begin
                next_word <= fifo_rd_data;
                next_valid <= 1'b1;
                rd_pending <= 1'b0;
            end

            if (active_video) begin
                if (!cur_valid && next_valid) begin
                    cur_word <= next_word;
                    next_valid <= 1'b0;
                    cur_valid <= 1'b1;
                    byte_sel <= 2'd0;
                end

                if (cur_valid) begin
                    case (byte_sel)
                        2'd0: pixel_index <= cur_word[7:0];
                        2'd1: pixel_index <= cur_word[15:8];
                        2'd2: pixel_index <= cur_word[23:16];
                        default: pixel_index <= cur_word[31:24];
                    endcase

                    if (byte_sel == 2'd3) begin
                        byte_sel <= 2'd0;
                        cur_valid <= 1'b0;
                    end else begin
                        byte_sel <= byte_sel + 1'b1;
                    end
                end else begin
                    pixel_index <= 8'h00;
                end
            end else begin
                pixel_index <= 8'h00;
            end
        end
    end

    assign VGA_R = active_video ? {pixel_index[7:5], pixel_index[7:5], pixel_index[7:6]} : 8'h00;
    assign VGA_G = active_video ? {pixel_index[4:2], pixel_index[4:2], pixel_index[4:3]} : 8'h00;
    assign VGA_B = active_video ? {pixel_index[1:0], pixel_index[1:0], pixel_index[1:0], pixel_index[1:0]} : 8'h00;
    assign VGA_BLANK_N = active_video;
    assign VGA_SYNC_N = 1'b1;
    assign VGA_CLK = pixel_clk;

endmodule
