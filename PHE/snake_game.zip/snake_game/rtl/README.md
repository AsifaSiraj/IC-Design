# rtl/ — Verilog RTL Modules

## What is this folder about?

`rtl/` holds every **synthesizable Verilog module** in the snake_game project — the hardware half of the
design. Seven files, all instantiating or supporting `de1_soc_snake_top`.

All modules use `` `timescale 1ns/1ps `` and are written in **Verilog-2001** style (with one SystemVerilog
testbench in `../tb/`). There are no `always_ff`/`always_comb` blocks, no interfaces, no packages.

## Files

| File | Module | Summary |
| --- | --- | --- |
| `de1_soc_snake_top.v` | `de1_soc_snake_top` | Top-level entity. Instantiates and connects every other module. |
| `vga_dma_master.v` | `vga_dma_master` | Avalon-MM read engine that streams the framebuffer out of SDRAM. |
| `async_fifo_dc.v` | `async_fifo_dc` | Dual-clock FIFO with Gray-coded pointers. Bridges 50 MHz to 74.25 MHz. |
| `video_timing_720p.v` | `video_timing_720p` | 1280x720 @ 60 Hz horizontal/vertical sync generator. |
| `uart_rx.v` | `uart_rx` | Asynchronous serial receiver, 115200 baud. |
| `uart_tx.v` | `uart_tx` | Asynchronous serial transmitter, 115200 baud. |
| `uart_protocol.v` | `uart_protocol` | Command packet parser, checksum, and ACK generator. |
| `pll_74p25_stub.v` | `pll_74p25` | **Stub.** Passes 50 MHz through unchanged. Replace with Quartus PLL IP. |

## Module dependency graph

```
de1_soc_snake_top
├── pll_74p25               (50 MHz -> 74.25 MHz, STUB)
├── video_timing_720p       (pixel_clk domain)
├── vga_dma_master          (CLOCK_50 domain)
│   └── drives async_fifo_dc's write side
├── async_fifo_dc           (write: CLOCK_50, read: pixel_clk)
├── uart_protocol           (CLOCK_50 domain)
│   ├── uart_rx
│   └── uart_tx
└── pixel-unpack FSM + RGB bit-slice logic  (inline in the top module)
```

---

## `de1_soc_snake_top.v` — Top Level

The board-facing entity. Its ports map 1:1 onto the DE1-SoC's physical interfaces:

**Clock and reset**
- `CLOCK_50` — the board's 50 MHz oscillator
- `KEY[0]` — active-low reset. `wire reset_n = KEY[0];` and every sequential block uses
  `or negedge reset_n` for asynchronous reset.

**Avalon-MM slave port** (to the SoC's SDRAM controller through the `f2h_sdram` bridge)
- `am_addr`, `am_read`, `am_waitrequest`, `am_readdata`, `am_readdatavalid`

**VGA output**
- `VGA_R/G/B[7:0]`, `VGA_HS`, `VGA_VS`, `VGA_BLANK_N`, `VGA_SYNC_N`, `VGA_CLK`

**UART** (optional, via the GPIO header)
- `UART_RXD`, `UART_TXD`

### The pixel-unpack FSM

The most interesting logic in the top module, because it is written inline rather than factored out.
It runs on `pixel_clk` and manages three pieces of state:

- `cur_word` / `cur_valid` — the 32-bit word currently being consumed
- `next_word` / `next_valid` — the word being prefetched from the FIFO
- `rd_pending` — a read has been issued to the FIFO and the data has not arrived yet
- `byte_sel[1:0]` — which of the four bytes of `cur_word` is being output
- `pixel_index[7:0]` — the current pixel value

**The fetch half** issues a FIFO read when there is nothing buffered:

```verilog
if (!rd_pending && !next_valid && !fifo_rd_empty) begin
    fifo_rd_en <= 1'b1;      // request next word
    rd_pending <= 1'b1;
end else if (rd_pending) begin
    next_word  <= fifo_rd_data;  // data arrived
    next_valid <= 1'b1;
    rd_pending <= 1'b0;
end
```

The `rd_pending` flag models the FIFO's **one-cycle read latency**. Because `fifo_rd_data` is registered
inside `async_fifo_dc`, a `rd_en` pulse in cycle N produces data in cycle N+1 — without the flag the FSM
would latch stale data.

**The consume half** unpacks one byte per pixel clock:

```verilog
case (byte_sel)
    2'd0: pixel_index <= cur_word[7:0];
    2'd1: pixel_index <= cur_word[15:8];
    2'd2: pixel_index <= cur_word[23:16];
    default: pixel_index <= cur_word[31:24];
endcase
```

Little-endian byte ordering, so byte 0 is the **leftmost** pixel. `byte_sel` wraps at 3, and
`cur_valid` drops so the next word can be swapped in.

**Colour mapping** — the 8-bit value is bit-sliced straight into the 24-bit DAC:

```verilog
assign VGA_R = active_video ? {pixel_index[7:5], pixel_index[7:5], pixel_index[7:5], pixel_index[7:6]} : 8'h00;
assign VGA_G = active_video ? {pixel_index[4:2], pixel_index[4:2], pixel_index[4:2], pixel_index[4:3]} : 8'h00;
assign VGA_B = active_video ? {pixel_index[1:0], pixel_index[1:0], pixel_index[1:0], pixel_index[1:0]} : 8'h00;
assign VGA_BLANK_N = active_video;
```

R gets bits [7:5] (3 bits), G gets [4:2] (3 bits), B gets [1:0] (2 bits). Outside `active_video` every
channel is forced to black, which prevents garbage appearing during blanking intervals. `VGA_SYNC_N` is
tied high and `VGA_CLK` is just the pixel clock forwarded to the connector.

---

## `vga_dma_master.v` — Avalon-MM Read Engine

Streams the framebuffer from SDRAM into the FIFO. Fully parameterised so the testbench in `../tb/` can
shrink it down.

| Parameter | Default | Meaning |
| --- | --- | --- |
| `BASE_ADDR` | `0x3800_0000` | Framebuffer start in SDRAM |
| `FRAME_BYTES` | 921600 | Frame size; address wraps back to base at the end |
| `FIFO_ADDR_WIDTH` | 9 | 512-entry FIFO |
| `MAX_OUTSTANDING` | 8 | Cap on in-flight reads |

### Address generation

```verilog
localparam [31:0] FRAME_LAST_ADDR = BASE_ADDR + FRAME_BYTES - 4;
```

The address only advances **on an accepted transfer** (`am_read && !am_waitrequest`), so back-pressure
from the SDRAM bridge holds the address perfectly still:

```verilog
if (accepted) begin
    am_read <= 1'b0;                                  // deassert: one read per cycle
    if (am_addr == FRAME_LAST_ADDR)
        am_addr <= BASE_ADDR;                         // wrap -> frame loops forever
    else
        am_addr <= am_addr + 32'd4;                   // 4 bytes = 1 pixel per beat
end else if (!am_read && can_issue) begin
    am_read <= 1'b1;                                  // assert and hold until accepted
end
```

Note `am_read` is deasserted for a full cycle after every acceptance, so at most one read is issued per
cycle. This is a deliberate simplicity trade-off — the pipeline is still full because the outstanding-read
counter keeps up to 8 requests in flight.

### Flow control

```verilog
assign fifo_has_room = (fifo_wr_usedw < (FIFO_DEPTH - 16));
assign can_issue     = fifo_has_room && (outstanding_reads < MAX_OUTSTANDING);
```

`fifo_has_room` stops issuing with **16 entries of headroom** rather than waiting for `wr_full`, which
would mean the FIFO is already backed up. `outstanding_reads` is a 5-bit counter incremented on
acceptance and decremented on `am_readdatavalid` — this is what hides SDRAM latency.

Write enable to the FIFO is simply gated on validity and not-full:

```verilog
assign fifo_wr_data = am_readdata;
assign fifo_wr_en   = am_readdatavalid && !fifo_wr_full;
```

---

## `async_fifo_dc.v` — Dual-Clock FIFO

A textbook Clifford Cummings style asynchronous FIFO. **This is the module that makes the whole design
legal**, because it is the only thing standing between the 50 MHz SDRAM domain and the 74.25 MHz pixel
domain.

| Parameter | Default | Meaning |
| --- | --- | --- |
| `DATA_WIDTH` | 32 | Matches `am_readdata` |
| `ADDR_WIDTH` | 9 | 512 words = 2 KB |

### Gray-coded pointers

The core trick. Counters are kept in **both** binary and Gray form:

```verilog
assign wr_ptr_bin_next  = wr_ptr_bin + ((wr_en && !wr_full) ? 1'b1 : 1'b0);
assign wr_ptr_gray_next = bin2gray(wr_ptr_bin_next);
```

with

```verilog
function [ADDR_WIDTH:0] bin2gray;
    input [ADDR_WIDTH:0] bin;
    begin
        bin2gray = (bin >> 1) ^ bin;
    end
endfunction
```

Binary incrementing flips many bits at once. If a synchroniser samples such a counter mid-transition, it
can capture an intermediate value that never existed as a valid state. Gray code changes **exactly one
bit per step**, so any sample is unambiguously either the old or the new value.

### Full and empty detection

Empty is simple — the pointers are equal:

```verilog
assign rd_empty = (rd_ptr_gray == wr_ptr_gray_sync2);
```

Full is the classic two-bit-invert trick, comparing the **next** write pointer against the synchronised
read pointer with the top two Gray bits inverted:

```verilog
assign wr_full = (wr_ptr_gray_next == {~rd_ptr_gray_sync2[ADDR_WIDTH:ADDR_WIDTH-1],
                                        rd_ptr_gray_sync2[ADDR_WIDTH-2:0]});
```

In Gray code the MSB and MSB-1 together encode a full wrap; inverting them detects it. Comparing
`wr_ptr_gray_**next**` (not the current one) makes the full flag self-clearing.

### Crossing the domains

Each pointer crosses through a two-flop synchroniser chain, with `(* async_reg = "true" *)`-style intent
expressed structurally:

```verilog
always @(posedge wr_clk or negedge wr_rst_n) begin
    if (!wr_rst_n) begin
        rd_ptr_gray_sync1 <= 0;
        rd_ptr_gray_sync2 <= 0;
    end else begin
        rd_ptr_gray_sync1 <= rd_ptr_gray;   // read side pointer -> write domain
        rd_ptr_gray_sync2 <= rd_ptr_gray_sync1;
    end
end
```

and the mirror image for `wr_ptr_gray` crossing into the read domain. Two flops give the metastability
time to resolve before the value is used.

### Occupancy count

```verilog
assign rd_ptr_bin_sync = gray2bin(rd_ptr_gray_sync2);
assign wr_usedw = wr_ptr_bin - rd_ptr_bin_sync;
```

You cannot subtract Gray codes meaningfully, so the synchronised read pointer is converted back to binary
and subtracted in the write domain. `wr_usedw` is what `vga_dma_master` thresholds on for flow control.

### Read behaviour

`rd_data` is a **registered** output with a one-cycle latency after `rd_en` — the top-level FSM's
`rd_pending` flag exists specifically to model this.

### Storage

```verilog
reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];
```

Written on `wr_clk`, read on `rd_clk`. This infers a dual-port block RAM. For synthesis it is best to
add vendor attributes so it maps to on-chip RAM rather than flip-flops.

---

## `video_timing_720p.v` — 720p Sync Generator

Generates the standard 1280x720 @ 60 Hz (CEA-861 / VESA) timing. Pixel clock is supplied externally
(it must be 74.25 MHz for these numbers to be correct).

| Horizontal | Pixels | | Vertical | Lines |
| --- | --- | --- | --- | --- |
| `H_ACTIVE` | 1280 | | `V_ACTIVE` | 720 |
| `H_FP` (front porch) | 110 | | `V_FP` | 5 |
| `H_SYNC` | 40 | | `V_SYNC` | 5 |
| `H_BP` (back porch) | 220 | | `V_BP` | 20 |
| **`H_TOTAL`** | **1650** | | **`V_TOTAL`** | **750** |

Sanity check: 1650 x 750 x 60 Hz = **74.25 MHz**. That is exactly the PLL's target frequency — the two
modules are designed as a pair.

The counters are simple free-running up-counters that wrap at `H_TOTAL - 1` and `V_TOTAL - 1`. The
derived signals are pure combinational comparisons on the current count:

```verilog
assign active_video = (h_cnt < H_ACTIVE) && (v_cnt < V_ACTIVE);

assign hs = (h_cnt >= (H_ACTIVE + H_FP)) &&
            (h_cnt <  (H_ACTIVE + H_FP + H_SYNC));

assign vs = (v_cnt >= (V_ACTIVE + V_FP)) &&
            (v_cnt <  (V_ACTIVE + V_FP + V_SYNC));
```

`x` and `y` are registered copies of the counters, exposed for debug or for a future scaling stage.
720p uses **positive** sync polarity, which the comment on line 58 flags explicitly.

---

## `uart_rx.v` — UART Receiver

A standard shift-register UART, parameterised by `CLK_FREQ_HZ` and `BAUD` (both 50 MHz / 115200 in this
design, giving `BAUD_DIV = 434`).

```
localparam integer BAUD_DIV      = CLK_FREQ_HZ / BAUD;   // 434
localparam integer HALF_BAUD_DIV = BAUD_DIV / 2;          // 217
```

### Start-bit detection with mid-bit sampling

The receiver waits for `rx` to go low, then waits **half a bit time** before sampling. This centres the
sample point in the middle of each bit, which is what makes the receiver tolerant of clock mismatch
between sender and receiver.

```verilog
if (!busy) begin
    if (!rx) begin
        busy     <= 1'b1;
        baud_cnt <= HALF_BAUD_DIV[15:0];   // half a bit to the middle of the start bit
        bit_idx  <= 4'd0;
    end
end
```

Then each subsequent `BAUD_DIV` clocks shifts in one bit:

```verilog
if (bit_idx < 4'd8)
    shift_reg[bit_idx] <= rx;      // 8 data bits, LSB first
```

### Stop-bit validation

```verilog
end else begin
    busy <= 1'b0;
    if (rx) begin                   // stop bit is normally 1
        data       <= shift_reg;
        data_valid <= 1'b1;         // only pulse if framing was OK
    end
end
```

If the stop bit reads `0`, the byte is silently discarded — this is **framing-error detection**, and it
is what lets the protocol layer above resynchronise on `PKT_START`.

`data_valid` is a single-cycle pulse, cleared at the top of every cycle.

---

## `uart_tx.v` — UART Transmitter

The mirror image, and simpler. The whole frame is packed into a 10-bit shift register up front:

```verilog
frame <= {1'b1, data, 1'b0};    // stop bit : data : start bit
busy  <= 1'b1;
bit_idx <= 4'd1;                // start bit already driven
baud_cnt <= BAUD_DIV[15:0] - 1'b1;
tx <= 1'b0;                     // start bit is a 0
```

Bits are then shifted out `frame[bit_idx]` every `BAUD_DIV` clocks until `bit_idx == 9`, at which point
`tx` returns to the idle high level and `busy` drops. `busy` is the handshake the protocol layer waits on
between the four ACK bytes.

Idle state is `tx = 1`, matching the UART convention of a logic-high idle line.

---

## `uart_protocol.v` — Command Protocol

Sits on top of `uart_rx`/`uart_tx` and adds framing, a checksum, and acknowledgement. Note it is
currently **not connected to the pixel pipeline** — see the "Known issues" in the parent README.

### Framing constants

```verilog
localparam [7:0] PKT_START = 8'h55;
localparam [7:0] ACK_START = 8'hAA;
```

### The 4-byte receive state machine

A 2-bit `parser_state` walks a four-state machine:

| State | Action |
| --- | --- |
| 0 | Hunt for `0x55`; ignore everything else (this is how it resynchronises) |
| 1 | Latch `cmd` |
| 2 | Latch `payload` |
| 3 | Verify checksum, then act |

### Checksum

```verilog
if (rx_data == (PKT_START ^ cmd ^ payload)) begin
    case (cmd)
        8'h01: dir <= 2'd0;   // W
        8'h02: dir <= 2'd1;   // D
        8'h03: dir <= 2'd2;   // S
        8'h04: dir <= 2'd3;   // A
        default: dir <= dir;  // unknown command: no change
    endcase
    ack_checksum <= ACK_START ^ cmd ^ payload;
    ack_state    <= 3'd1;
end
parser_state <= 2'd0;   // always reset, pass or fail
```

XOR is a cheap, order-independent checksum — good enough to catch transmission errors, not good enough
against deliberate corruption. A failed packet falls back to state 0 and hunts for the next `0x55`.

`dir` is a 2-bit output, but the top module leaves it unconnected — this is the loose end noted in the
parent README.

### The 4-byte ACK state machine

A separate 3-bit `ack_state` FSM serialises four bytes, each gated on `!tx_busy` so the transmitter is
never overrun:

| State | Sends |
| --- | --- |
| 1 | `0xAA` (ACK sync) |
| 2 | `cmd` (echo) |
| 3 | `payload` (echo) |
| default | `ack_checksum`, then back to idle |

`tx_valid` is a single-cycle pulse, cleared at the top of each clock.

---

## `pll_74p25_stub.v` — Clock Generator Stub

```verilog
// Replace this stub with a Quartus-generated PLL IP that converts 50 MHz -> 74.25 MHz.
module pll_74p25 (
    input  wire refclk,
    input  wire rst,
    output wire outclk_0,
    output wire locked
);
    assign outclk_0 = refclk;   // NOT a real PLL - passes 50 MHz through
    assign locked   = ~rst;
endmodule
```

This exists so the design **compiles and elaborates** without Quartus IP being present. It lets you
work on the logic in a simulator, where a real `altera_pll` primitive would not simulate at all.

The module name and port list are deliberately chosen to match Quartus's standard `altera_pll` wrapper
so it can be swapped out with no other changes.

### Why this matters

With a pass-through clock, the `video_timing_720p` counters run at 50 MHz instead of 74.25 MHz, so the
generated timing is 2/3 speed: roughly **1000x500** instead of 1280x720. Almost no monitor will lock onto
that. You must generate real PLL IP before driving a physical display.

---

## Synthesis notes

- All modules are `rtl/` root files — add all 8 to the Quartus project.
- Top entity: `de1_soc_snake_top`.
- Consider adding `(* ram_style = "M9K" *)` or Quartus equivalents to `async_fifo_dc`'s `mem` array so it
  infers block RAM instead of flip-flops.
- Consider `(* altera_attribute = "-name SYNCHRONIZER_IDENTIFICATION FORCED" *)` on the four
  `*_sync1` registers so Quartus packs them into dedicated synchroniser cells.
- The inline pixel-unpack FSM in the top module is a natural candidate for extraction into
  `pixel_unpack.v` if you want to unit-test it.
