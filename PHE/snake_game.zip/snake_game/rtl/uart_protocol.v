`timescale 1ns/1ps

module uart_protocol #(
    parameter integer CLK_FREQ_HZ = 50000000,
    parameter integer BAUD        = 115200
) (
    input  wire      clk,
    input  wire      rst_n,
    input  wire      rx,
    output wire      tx,
    output reg [1:0] dir
);

    localparam [7:0] PKT_START = 8'h55;
    localparam [7:0] ACK_START = 8'hAA;

    reg [1:0] parser_state;
    reg [7:0] cmd;
    reg [7:0] payload;

    wire [7:0] rx_data;
    wire rx_valid;

    reg [7:0] tx_data;
    reg tx_valid;
    wire tx_busy;

    reg [2:0] ack_state;
    reg [7:0] ack_checksum;

    uart_rx #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ),
        .BAUD(BAUD)
    ) u_rx (
        .clk(clk),
        .rst_n(rst_n),
        .rx(rx),
        .data(rx_data),
        .data_valid(rx_valid)
    );

    uart_tx #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ),
        .BAUD(BAUD)
    ) u_tx (
        .clk(clk),
        .rst_n(rst_n),
        .data(tx_data),
        .data_valid(tx_valid),
        .tx(tx),
        .busy(tx_busy)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            parser_state <= 2'd0;
            cmd <= 8'd0;
            payload <= 8'd0;
            dir <= 2'd0;
            tx_data <= 8'd0;
            tx_valid <= 1'b0;
            ack_state <= 3'd0;
            ack_checksum <= 8'd0;
        end else begin
            tx_valid <= 1'b0;

            if (rx_valid) begin
                case (parser_state)
                    2'd0: begin
                        if (rx_data == PKT_START) begin
                            parser_state <= 2'd1;
                        end
                    end

                    2'd1: begin
                        cmd <= rx_data;
                        parser_state <= 2'd2;
                    end

                    2'd2: begin
                        payload <= rx_data;
                        parser_state <= 2'd3;
                    end

                    2'd3: begin
                        if (rx_data == (PKT_START ^ cmd ^ payload)) begin
                            case (cmd)
                                8'h01: dir <= 2'd0; // W
                                8'h02: dir <= 2'd1; // D
                                8'h03: dir <= 2'd2; // S
                                8'h04: dir <= 2'd3; // A
                                default: dir <= dir;
                            endcase

                            ack_checksum <= ACK_START ^ cmd ^ payload;
                            ack_state <= 3'd1;
                        end
                        parser_state <= 2'd0;
                    end
                endcase
            end

            case (ack_state)
                3'd0: begin
                    // idle
                end

                3'd1: begin
                    if (!tx_busy) begin
                        tx_data <= ACK_START;
                        tx_valid <= 1'b1;
                        ack_state <= 3'd2;
                    end
                end

                3'd2: begin
                    if (!tx_busy) begin
                        tx_data <= cmd;
                        tx_valid <= 1'b1;
                        ack_state <= 3'd3;
                    end
                end

                3'd3: begin
                    if (!tx_busy) begin
                        tx_data <= payload;
                        tx_valid <= 1'b1;
                        ack_state <= 3'd4;
                    end
                end

                default: begin
                    if (!tx_busy) begin
                        tx_data <= ack_checksum;
                        tx_valid <= 1'b1;
                        ack_state <= 3'd0;
                    end
                end
            endcase
        end
    end

endmodule
