`timescale 1ns/1ps

module video_timing_720p (
    input  wire        pixel_clk,
    input  wire        rst_n,
    output reg  [11:0] x,
    output reg  [10:0] y,
    output wire        active_video,
    output wire        hs,
    output wire        vs
);

    localparam H_ACTIVE = 12'd1280;
    localparam H_FP     = 12'd110;
    localparam H_SYNC   = 12'd40;
    localparam H_BP     = 12'd220;
    localparam H_TOTAL  = 12'd1650;

    localparam V_ACTIVE = 11'd720;
    localparam V_FP     = 11'd5;
    localparam V_SYNC   = 11'd5;
    localparam V_BP     = 11'd20;
    localparam V_TOTAL  = 11'd750;

    reg [11:0] h_cnt;
    reg [10:0] v_cnt;

    always @(posedge pixel_clk or negedge rst_n) begin
        if (!rst_n) begin
            h_cnt <= 12'd0;
            v_cnt <= 11'd0;
        end else begin
            if (h_cnt == H_TOTAL - 1'b1) begin
                h_cnt <= 12'd0;
                if (v_cnt == V_TOTAL - 1'b1) begin
                    v_cnt <= 11'd0;
                end else begin
                    v_cnt <= v_cnt + 1'b1;
                end
            end else begin
                h_cnt <= h_cnt + 1'b1;
            end
        end
    end

    always @(posedge pixel_clk or negedge rst_n) begin
        if (!rst_n) begin
            x <= 12'd0;
            y <= 11'd0;
        end else begin
            x <= h_cnt;
            y <= v_cnt;
        end
    end

    assign active_video = (h_cnt < H_ACTIVE) && (v_cnt < V_ACTIVE);

    // 720p uses positive polarity sync pulses.
    assign hs = (h_cnt >= (H_ACTIVE + H_FP)) &&
                (h_cnt <  (H_ACTIVE + H_FP + H_SYNC));

    assign vs = (v_cnt >= (V_ACTIVE + V_FP)) &&
                (v_cnt <  (V_ACTIVE + V_FP + V_SYNC));

endmodule
