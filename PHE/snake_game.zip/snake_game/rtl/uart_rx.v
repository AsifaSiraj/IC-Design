`timescale 1ns/1ps

module uart_rx #(
    parameter integer CLK_FREQ_HZ = 50000000,
    parameter integer BAUD        = 115200
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       rx,
    output reg [7:0]  data,
    output reg        data_valid
);

    localparam integer BAUD_DIV = CLK_FREQ_HZ / BAUD;
    localparam integer HALF_BAUD_DIV = BAUD_DIV / 2;

    reg [15:0] baud_cnt;
    reg [3:0]  bit_idx;
    reg [7:0]  shift_reg;
    reg        busy;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            baud_cnt <= 16'd0;
            bit_idx <= 4'd0;
            shift_reg <= 8'd0;
            busy <= 1'b0;
            data <= 8'd0;
            data_valid <= 1'b0;
        end else begin
            data_valid <= 1'b0;

            if (!busy) begin
                if (!rx) begin
                    busy <= 1'b1;
                    baud_cnt <= HALF_BAUD_DIV[15:0];
                    bit_idx <= 4'd0;
                end
            end else begin
                if (baud_cnt == 16'd0) begin
                    baud_cnt <= BAUD_DIV[15:0] - 1'b1;

                    if (bit_idx < 4'd8) begin
                        shift_reg[bit_idx] <= rx;
                        bit_idx <= bit_idx + 1'b1;
                    end else begin
                        busy <= 1'b0;
                        if (rx) begin
                            data <= shift_reg;
                            data_valid <= 1'b1;
                        end
                    end
                end else begin
                    baud_cnt <= baud_cnt - 1'b1;
                end
            end
        end
    end

endmodule
