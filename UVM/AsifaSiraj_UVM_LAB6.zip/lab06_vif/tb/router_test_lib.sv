`ifndef ROUTER_TEST_LIB_SV
`define ROUTER_TEST_LIB_SV

`include "uvm_macros.svh"
import uvm_pkg::*;
import yapp_pkg::*;

//------------------------------------------------------------------
// base_test
//------------------------------------------------------------------
class base_test extends uvm_test;

  `uvm_component_utils(base_test)

  router_tb tb0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    uvm_config_wrapper::set(this, "tb0.yapp.agent.sequencer.run_phase",
                             "default_sequence",
                             yapp_5_packets::get_type());

    tb0 = router_tb::type_id::create("tb0", this);
    `uvm_info("base_test", "Build phase of the test is executing", UVM_HIGH)
  endfunction : build_phase

  // Lab 6 addition: drain time so packets clear the router before end of test
  virtual task run_phase(uvm_phase phase);
    uvm_objection obj = phase.get_objection();
    obj.set_drain_time(this, 200ns);
  endtask : run_phase

  virtual function void end_of_elaboration_phase(uvm_phase phase);
    uvm_top.print_topology();
  endfunction : end_of_elaboration_phase

  // Report any unmatched/unused configuration settings
  virtual function void check_phase(uvm_phase phase);
    check_config_usage();
  endfunction : check_phase

endclass : base_test

//------------------------------------------------------------------
// test2 - extends base_test (kept from Lab 3)
//------------------------------------------------------------------
class test2 extends base_test;

  `uvm_component_utils(test2)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

endclass : test2

//------------------------------------------------------------------
// short_packet_test - factory type override (Lab 4)
//------------------------------------------------------------------
class short_packet_test extends base_test;

  `uvm_component_utils(short_packet_test)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  virtual function void build_phase(uvm_phase phase);
    set_type_override_by_type(yapp_packet::get_type(),
                               short_yapp_packet::get_type());
    super.build_phase(phase);
  endfunction : build_phase

endclass : short_packet_test

//------------------------------------------------------------------
// set_config_test - configuration override (Lab 4)
//------------------------------------------------------------------
class set_config_test extends base_test;

  `uvm_component_utils(set_config_test)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  virtual function void build_phase(uvm_phase phase);
    uvm_config_db#(uvm_active_passive_enum)::set(this, "tb0.yapp.agent",
                                                  "is_active", UVM_PASSIVE);
    super.build_phase(phase);
  endfunction : build_phase

endclass : set_config_test

//------------------------------------------------------------------
// incr_payload_test - Lab 5, Step 8
//------------------------------------------------------------------
class incr_payload_test extends base_test;

  `uvm_component_utils(incr_payload_test)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  virtual function void build_phase(uvm_phase phase);
    set_type_override_by_type(yapp_packet::get_type(),
                               short_yapp_packet::get_type());

    super.build_phase(phase);

    uvm_config_wrapper::set(this, "tb0.yapp.agent.sequencer.run_phase",
                             "default_sequence",
                             yapp_incr_payload_seq::get_type());
  endfunction : build_phase

endclass : incr_payload_test

//------------------------------------------------------------------
// exhaustive_seq_test - Lab 5, Step 10
//------------------------------------------------------------------
class exhaustive_seq_test extends base_test;

  `uvm_component_utils(exhaustive_seq_test)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  virtual function void build_phase(uvm_phase phase);
    set_type_override_by_type(yapp_packet::get_type(),
                               short_yapp_packet::get_type());

    super.build_phase(phase);

    uvm_config_wrapper::set(this, "tb0.yapp.agent.sequencer.run_phase",
                             "default_sequence",
                             yapp_exhaustive_seq::get_type());
  endfunction : build_phase

endclass : exhaustive_seq_test

//------------------------------------------------------------------
// yapp_012_test - Lab 6
// Sends packets to all three output channels for DUT connection testing.
//------------------------------------------------------------------
class yapp_012_test extends base_test;

  `uvm_component_utils(yapp_012_test)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    // Overrides the yapp_5_packets default set in base_test::build_phase()
    uvm_config_wrapper::set(this, "tb0.yapp.agent.sequencer.run_phase",
                             "default_sequence",
                             yapp_012_seq::get_type());
  endfunction : build_phase

endclass : yapp_012_test

`endif
