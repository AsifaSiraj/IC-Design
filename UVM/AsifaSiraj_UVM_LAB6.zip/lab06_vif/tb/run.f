// 64 bit option
-64

-uvmhome $UVMHOME
-timescale 1ns/1ns

-incdir sv
-incdir tb

sv/yapp_pkg.sv


sv/yapp_if.sv
tb/clkgen.sv
../router_rtl/yapp_router.sv
tb/hw_top.sv
tb/router_tb.sv
tb/router_test_lib.sv
tb/tb_top.sv

+UVM_TESTNAME=yapp_012_test
+UVM_VERBOSITY=UVM_LOW
