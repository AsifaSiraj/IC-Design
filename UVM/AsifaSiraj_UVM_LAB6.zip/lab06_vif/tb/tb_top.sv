/*-----------------------------------------------------------------
File name     : tb_top.sv
Description   : lab06_vif UVM top level module
Notes         : From the Cadence "SystemVerilog Accelerated Verification with UVM" training
-----------------------------------------------------------------*/
module tb_top;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import yapp_pkg::*;

  initial begin
    // Absolute path from uvm_test_top down to the yapp agent instance;
    // wildcard "*" so both monitor and driver pick up the vif in one call.
    yapp_vif_config::set(null, "uvm_test_top.tb0.yapp.agent.*", "vif", hw_top.in0);
    run_test();
  end
endmodule
