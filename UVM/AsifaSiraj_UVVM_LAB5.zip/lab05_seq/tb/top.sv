module top;

  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import yapp_pkg::*;      // existing YAPP package import

  `include "router_tb.sv"        // (a) include testbench
  `include "router_test_lib.sv"  // (b) include test — must come AFTER tb include

  // ... existing interface/DUT instantiation stays here ...

  // (c) Remove old yapp_packet randomization/print initial block

  // (d) Kick off UVM phasing
  initial begin
    run_test();
  end

endmodule
