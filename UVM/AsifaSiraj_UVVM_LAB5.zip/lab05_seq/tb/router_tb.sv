`ifndef ROUTER_TB_SV
`define ROUTER_TB_SV

`include "uvm_macros.svh"
import uvm_pkg::*;
import yapp_pkg::*;

class router_tb extends uvm_env;

  `uvm_component_utils(router_tb)

  // Handle for the YAPP UVC
  yapp_env yapp;

  // Constructor
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  // Build phase
  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    yapp = yapp_env::type_id::create("yapp", this);
    `uvm_info("router_tb", "Build phase of the testbench is executing", UVM_HIGH)
  endfunction : build_phase

endclass : router_tb

`endif
