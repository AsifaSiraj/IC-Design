/*-----------------------------------------------------------------
File name     : yapp_packet.sv
Description   : lab01_data YAPP UVC packet template file
Notes         : From the Cadence "SystemVerilog Advanced Verification with UVM" training
-------------------------------------------------------------------
Copyright Cadence Design Systems (c)2015
-----------------------------------------------------------------*/

// Define your enumerated type(s) 
typedef enum bit {GOOD_PARITY, BAD_PARITY} parity_type_e;

class yapp_packet extends uvm_sequence_item;

  // Packet properties
  rand bit [1:0] addr;
  rand bit [5:0] length;
  rand bit [7:0] payload[];
  bit      [7:0] parity;

  // Randomized control knobs
  rand parity_type_e parity_type;
  rand int packet_delay;

  // Constructor
  function new(string name = "yapp_packet");
    super.new(name);
  endfunction

  // UVM automation macros
  `uvm_object_utils_begin(yapp_packet)
    `uvm_field_int(addr,         UVM_ALL_ON)
    `uvm_field_int(length,       UVM_ALL_ON)
    `uvm_field_array_int(payload,UVM_ALL_ON)
    `uvm_field_int(parity,       UVM_ALL_ON | UVM_BIN)
    `uvm_field_enum(parity_type_e, parity_type, UVM_ALL_ON)
    `uvm_field_int(packet_delay, UVM_ALL_ON | UVM_NOCOMPARE)
  `uvm_object_utils_end

  // Calculate parity
  function bit [7:0] calc_parity();
    bit [7:0] result;

    result = 8'h00;

    foreach (payload[i])
      result ^= payload[i];

    return result;
  endfunction

  // Set parity based on parity_type
  function void set_parity();

    if (parity_type == GOOD_PARITY)
      parity = calc_parity();
    else
      parity = ~calc_parity();

  endfunction

  // Called automatically after randomization
  function void post_randomize();
    set_parity();
  endfunction

  // Valid address constraint
  constraint valid_addr {
    addr inside {[0:3]};
  }

  // Valid packet length
  constraint valid_length {
    length inside {[1:63]};
  }

  // Payload size must equal packet length
  constraint payload_size {
    payload.size() == length;
  }

  // Good parity should occur 5 times more often than bad parity
  constraint parity_distribution {
    parity_type dist {
      GOOD_PARITY := 5,
      BAD_PARITY  := 1
    };
  }

  // Packet delay from 1 to 20 clock cycles
  constraint packet_delay_range {
    packet_delay inside {[1:20]};
  }

// Follow the lab instructions to create the packet.
// Place the packet declarations in the following order:

  // Define protocol data

  // Define control knobs

  // Enable automation of the packet's fields

  // Define packet constraints

  // Add methods for parity calculation and class construction

endclass: yapp_packet
