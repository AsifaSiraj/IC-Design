/*-----------------------------------------------------------------
File name     : yapp_tx_seqs.sv
Developers    : Kathleen Meade, Brian Dickinson
Created       : 01/04/11
Description   : YAPP UVC simple TX test sequence for labs 2 to 5
Notes         : From the Cadence "SystemVerilog Advanced Verification with UVM" training
-------------------------------------------------------------------
Copyright Cadence Design Systems (c)2015
-----------------------------------------------------------------*/

//------------------------------------------------------------------------------
//
// SEQUENCE: base yapp sequence - base sequence with objections from which
// all sequences can be derived
//
//------------------------------------------------------------------------------
class yapp_base_seq extends uvm_sequence #(yapp_packet);
  // Required macro for sequences automation
  `uvm_object_utils(yapp_base_seq)
  // Constructor
  function new(string name="yapp_base_seq");
  super.new(name);
  endfunction
  task pre_body();
    uvm_phase phase;
    `ifdef UVM_VERSION_1_2
      // in UVM1.2, get starting phase from method
      phase = get_starting_phase();
    `else
      phase = starting_phase;
    `endif
    if (phase != null) begin
      phase.raise_objection(this, get_type_name());
      `uvm_info(get_type_name(), "raise objection", UVM_MEDIUM)
    end
  endtask : pre_body
  task post_body();
    uvm_phase phase;
    `ifdef UVM_VERSION_1_2
      // in UVM1.2, get starting phase from method
      phase = get_starting_phase();
    `else
     phase = starting_phase;
    `endif
    if (phase != null) begin
      phase.drop_objection(this, get_type_name());
      `uvm_info(get_type_name(), "drop objection", UVM_MEDIUM)
    end
  endtask : post_body
endclass : yapp_base_seq

//------------------------------------------------------------------------------
//
// SEQUENCE: yapp_5_packets
//
//  Configuration setting for this sequence
//    - update <path> to be hierarchial path to sequencer
//
//  uvm_config_wrapper::set(this, "<path>.run_phase",
//                                 "default_sequence",
//                                 yapp_5_packets::get_type());
//
//------------------------------------------------------------------------------
class yapp_5_packets extends yapp_base_seq;
  // Required macro for sequences automation
  `uvm_object_utils(yapp_5_packets)
  // Constructor
  function new(string name="yapp_5_packets");
    super.new(name);
  endfunction
  // Sequence body definition
  virtual task body();
    `uvm_info(get_type_name(), "Executing yapp_5_packets sequence", UVM_LOW)
     repeat(5)
      `uvm_do(req)
  endtask
endclass : yapp_5_packets

//------------------------------------------------------------------------------
//
// SEQUENCE: yapp_1_seq
//  Single packet to address 1 (addr == 1)
//
//------------------------------------------------------------------------------
class yapp_1_seq extends yapp_base_seq;

  `uvm_object_utils(yapp_1_seq)

  function new(string name="yapp_1_seq");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info(get_type_name(), "Executing yapp_1_seq sequence", UVM_LOW)
    `uvm_do_with(req, { req.addr == 1; })
  endtask

endclass : yapp_1_seq

//------------------------------------------------------------------------------
//
// SEQUENCE: yapp_012_seq
//  Three packets with incrementing addresses: addr==0, addr==1, addr==2
//
//------------------------------------------------------------------------------
class yapp_012_seq extends yapp_base_seq;

  `uvm_object_utils(yapp_012_seq)

  function new(string name="yapp_012_seq");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info(get_type_name(), "Executing yapp_012_seq sequence", UVM_LOW)
    `uvm_do_with(req, { req.addr == 0; })
    `uvm_do_with(req, { req.addr == 1; })
    `uvm_do_with(req, { req.addr == 2; })
  endtask

endclass : yapp_012_seq

//------------------------------------------------------------------------------
//
// SEQUENCE: yapp_111_seq
//  Nested sequence — three packets to address 1, by running
//  yapp_1_seq three times.
//
//------------------------------------------------------------------------------
class yapp_111_seq extends yapp_base_seq;

  `uvm_object_utils(yapp_111_seq)

  // Handle used by `uvm_do to create/start the nested sequence
  yapp_1_seq yapp_1_seq_h;

  function new(string name="yapp_111_seq");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info(get_type_name(), "Executing yapp_111_seq sequence", UVM_LOW)
    repeat(3)
      `uvm_do(yapp_1_seq_h)
  endtask

endclass : yapp_111_seq

//------------------------------------------------------------------------------
//
// SEQUENCE: yapp_repeat_addr_seq
//  Two packets to the same (random) address. Address cannot be 3.
//  A sequence-level random property picks the shared address once;
//  it gets randomized automatically when the sequence itself is
//  randomized (e.g. by the sequencer's automatic default-sequence
//  mechanism, or by `uvm_do/`uvm_do_with when started from a parent).
//
//------------------------------------------------------------------------------
class yapp_repeat_addr_seq extends yapp_base_seq;

  `uvm_object_utils(yapp_repeat_addr_seq)

  rand bit [1:0] seq_addr;

  constraint valid_seq_addr {
    seq_addr != 3;
  }

  function new(string name="yapp_repeat_addr_seq");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info(get_type_name(), $sformatf("Executing yapp_repeat_addr_seq sequence, seq_addr=%0d", seq_addr), UVM_LOW)
    repeat(2)
      `uvm_do_with(req, { req.addr == local::seq_addr; })
  endtask

endclass : yapp_repeat_addr_seq

//------------------------------------------------------------------------------
//
// SEQUENCE: yapp_incr_payload_seq
//  Single packet whose payload increments from 0 to (length - 1).
//  Uses `uvm_create / `uvm_send so the payload can be overwritten
//  and parity recalculated after randomize() but before the item
//  is sent to the driver.
//
//------------------------------------------------------------------------------
class yapp_incr_payload_seq extends yapp_base_seq;

  `uvm_object_utils(yapp_incr_payload_seq)

  function new(string name="yapp_incr_payload_seq");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info(get_type_name(), "Executing yapp_incr_payload_seq sequence", UVM_LOW)

    `uvm_create(req)
    if (!req.randomize())
      `uvm_error(get_type_name(), "req randomization failed")

    foreach (req.payload[i])
      req.payload[i] = i[7:0];

    req.set_parity();

    `uvm_send(req)
  endtask

endclass : yapp_incr_payload_seq

//------------------------------------------------------------------------------
//
// SEQUENCE: yapp_exhaustive_seq
//  Runs every user-defined sequence once, for regression-style
//  smoke testing of the whole sequence library.
//
//------------------------------------------------------------------------------
class yapp_exhaustive_seq extends yapp_base_seq;

  `uvm_object_utils(yapp_exhaustive_seq)

  yapp_1_seq            seq_1_h;
  yapp_012_seq          seq_012_h;
  yapp_111_seq          seq_111_h;
  yapp_repeat_addr_seq  seq_repeat_addr_h;
  yapp_incr_payload_seq seq_incr_payload_h;
  yapp_5_packets        seq_5_packets_h;

  function new(string name="yapp_exhaustive_seq");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info(get_type_name(), "Executing yapp_exhaustive_seq sequence", UVM_LOW)

    `uvm_do(seq_5_packets_h)
    `uvm_do(seq_1_h)
    `uvm_do(seq_012_h)
    `uvm_do(seq_111_h)
    `uvm_do(seq_repeat_addr_h)
    `uvm_do(seq_incr_payload_h)
  endtask

endclass : yapp_exhaustive_seq
