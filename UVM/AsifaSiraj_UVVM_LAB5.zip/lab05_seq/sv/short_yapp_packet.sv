class short_yapp_packet extends yapp_packet;

  `uvm_object_utils(short_yapp_packet)

  function new(string name = "short_yapp_packet");
    super.new(name);
  endfunction

  // Limit packet length to less than 15
  constraint valid_length_short {
    length < 15;
  }

  // Exclude address value of 2
  constraint valid_addr_short {
    addr != 2;
  }

endclass: short_yapp_packet
